#!/bin/bash

# 获取脚本当前路径
SOURCE="$0"
while [ -h "$SOURCE"  ]; do # resolve $SOURCE until the file is no longer a symlink
    ROOT="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /*  ]] && SOURCE="$ROOT/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
ROOT="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"

mkdir bin 2>/dev/null

# 编译compat_buildfly
cd $ROOT/compat_buildfly
make >$ROOT/compile.log 2>&1
echo -e "\n===================== compile compat_buildfly end =====================\n" >>$ROOT/compile.log

# 编译model
cd $ROOT/model
for dir in `ls .`
do
  if [ -d $dir ]
  then
    echo $dir >>$ROOT/compile.log
    cd $dir
    make V=true COMPAT_LIB_DIR=../../compat_buildfly BIN_NAME=lib$dir.so 2>&1 >>$ROOT/compile.log
    cd ..
    cp $dir/bin/release/* ../bin/
  fi
done 
echo -e "\n===================== compile model end =====================\n" >>$ROOT/compile.log

# 编译engine
cd $ROOT/engine
make THIRD_PARTY_DIR=/home/kl_files/third_party MODEL_DIR=../model V=true >>$ROOT/compile.log 2>&1
if [ $? -eq 0 ]; then
    echo "Compile success!"
else
    echo "Compile failed!"
    exit -1
fi

cp bin/release/demo ../bin/engine

