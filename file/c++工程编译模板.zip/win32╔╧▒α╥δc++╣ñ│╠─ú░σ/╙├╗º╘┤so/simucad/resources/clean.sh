#!/bin/bash

# 获取脚本当前路径
SOURCE="$0"
while [ -h "$SOURCE"  ]; do # resolve $SOURCE until the file is no longer a symlink
    ROOT="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /*  ]] && SOURCE="$ROOT/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
ROOT="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"

# 编译compat_buildfly
cd $ROOT/compat_buildfly
make clean

# 编译model
cd $ROOT/model
for dir in `ls .`
do
  if [ -d $dir ]
  then
    cd $dir
    make clean
  fi
done 

# 编译engine
cd $ROOT/engine
make clean

# 删除bin目录
rm $ROOT/bin -rf
