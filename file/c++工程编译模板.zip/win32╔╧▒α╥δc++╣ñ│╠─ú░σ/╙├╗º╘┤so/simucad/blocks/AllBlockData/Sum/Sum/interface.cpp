#include "RtxDllDemo.h"

#ifndef UNDER_RTSS
#include "userdef.h"
#else
#include "RTUserdef.h"
extern MESSGE_HANDLE SendUserMessage;
extern SHOWMESSAGE_PROC ShowMessage;
#endif


extern "C" int BUILDFLY_API UserInterface(DLLINFO *dllInfo)
{
	dllInfo->title="�ӷ�";
	dllInfo->text="�ӷ���";
	dllInfo->image=-1;  // no image 
	dllInfo->nVerMajor=1;        //ģ�Ͱ汾��
	dllInfo->nVerMinor=5;
	dllInfo->company="CSAC_TJL";

#ifdef UNDER_RTSS
	SendUserMessage=dllInfo->userMsgHandler;
	ShowMessage=dllInfo->ShowInfoHandler;
	ShowMessage("enter dll");
#endif
	return 0;
}