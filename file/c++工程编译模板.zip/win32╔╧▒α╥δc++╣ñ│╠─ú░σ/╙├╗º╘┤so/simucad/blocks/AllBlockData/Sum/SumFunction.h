#pragma once

#include <stdint.h>
#include <stddef.h>
#include <functional>
#include <iostream>
#include <dlfcn.h>
#include "compat_buildfly/userdef.h"


typedef int (*EntryFuncProtype)(int, void *, double, double, double *, double *, double *, double *);

template <typename ConfigType>
class BlockSumFunction {
public:
	BlockSumFunction(const ConfigType &cfg) : cfg_(cfg), lib_handle(NULL) {
        model = new MODEL();
    }
	
	~BlockSumFunction() {
        if (lib_handle != NULL)
        {
            dlclose(lib_handle);
            lib_handle = NULL;
        }
        if (model != nullptr)
        {
            delete model;
        }
    }
	
	bool init() {
        std::string lib_path = "libSum.dll";
        std::string interface_name = "SumFunction";
        lib_handle = dlopen(lib_path.c_str(), RTLD_NOW);
        if (lib_handle == NULL)
        {
            std::cout << "���ض�̬��ʧ��" << std::endl;
        }

        // ��ȡ��ں���
        entry_func = (EntryFuncProtype)dlsym(lib_handle, interface_name.c_str());
        if (!entry_func) {
            std::cout << lib_path << ":��ȡ��ں���ʧ��" << std::endl;
			dlclose(lib_handle);
            lib_handle = NULL;
            return false;
        }

        int ret = entry_func(SM_CREATE, model, cfg_.step_size, 0, x, u, y, f);
        if (ret != 0) {
            std::cout << lib_path << ":ִ��SM_CREATEʧ��" << std::endl;
            return false; 
        }

		ret = entry_func(SM_INITIALIZE, model, cfg_.step_size, 0, x, u, y, f);
        if (ret != 0) {
            std::cout << lib_path << ":ִ��SM_INITIALIZEʧ��" << std::endl;
            return false;
        }
        
		return true;
	}
	
	void output(uint64_t steps ,double p0,double p1,double u0,double u1,double *y0) {
        model->Data[0] = p0;
model->Data[1] = p1;

		u[0] = u0;
u[1] = u1;

		entry_func(SM_OUTPUT, model, steps * cfg_.step_size, steps, x, u, y, f);
		*y0 = y[0];

	}
	
	void terminate() {
		uint64_t steps = 1;
		entry_func(SM_STOP, model, steps * cfg_.step_size, steps, x, u, y, f);
	}

private:
	const ConfigType cfg_;
	MODEL *model;
    void *lib_handle;
    EntryFuncProtype entry_func;
	
	// ״̬����
	double x[0];
	
	// �������
	double u[2];
	
	// �������
	double y[1];
	
	// ����
	double f[0];
};
