#ifndef __MFCAPI_H__
#define __MFCAPI_H__

//#ifndef LPCSTR
  //#define LPCSTR char *
//#endif

#ifdef __cplusplus
extern "C" {
#endif

int  AddParam(char* name, int type, int dim, void *data);
int  AddOption(char* name, char* strOption);
void RemoveParam();

#ifdef __cplusplus
}
#endif

#endif
