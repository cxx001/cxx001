#ifndef INTERFACE_H
#define INTERFACE_H
#define _CRT_SECURE_NO_WARNINGS

#define SIMUNPS_API _declspec(dllexport)

#include "Basic/ElectricalSystemStruct.h"
//#include "Basic/Struct.h"
#include <complex>
#include <vector>
#include <map>
#include <set>

using namespace std;
class SIMUNPS_API IElectricalArithmetic {
public:
	static IElectricalArithmetic *Create();

	virtual bool InitSimulation() = 0;

	/**
	 * This method is used to run the one-step simulation.
	 * The user invokes this interface once,then invokes the Getxxx() to get the data you want;
	 */
	virtual void RunOneStep() = 0;

	/**
	 * Returns true if the simulation program can continue to run.
	 *
	 * This method is used to determine if NaN values occur during emulation.
	 */
	virtual bool IsContinue()=0;

	/**
	 * Returns a single step of all node voltages
	 *
	 * This method is used to get the voltage of all nodes in a single step.
	 *
	 * @return a single step of all node voltages
	 */
	virtual const vector<d_complex> GetNodeVoltage() = 0;

	/**
	 * Returns the current of the electrical element
	 *
	 * This method is used to get the current of the electrical element in a single step.
	 *
	 * @return the current of the electrical element(The index of the vector correspond to each electrical element).
	 */
	virtual const vector<d_complex> GetVoltageSourceCurrent() = 0;
	virtual const vector<d_complex> GetCapacitanceCurrent() = 0;
	virtual const vector<d_complex> GetInductanceCurrent() = 0;
	virtual const vector<d_complex> GetTransformerCurrent() = 0;
	virtual const vector<d_complex> GetTransmissionLineCurrent() = 0;
	virtual const vector<d_complex> GetSynchronousGeneratorCurrent() = 0;

	/**
	 * Returns the structure data of the electrical element
	 *
	 * This method is used to get the structure data of the electrical element in a single step.
	 *
	 * @return the structure data of the electrical element.
	 */
	virtual const vector<SynchronousGeneratorOutput>  GetSynchronousGeneratorData() = 0;
	virtual const vector<MultiMassOutput> GetMultiMassData() = 0;
	virtual const vector<DieselGeneratorOutput> GetDieselGeneratorData() = 0;
	virtual const vector<ExciterOutput> GetExciterData() = 0;
	virtual const vector<VoltageSourceConverterOutput> GetVoltageSourceConverterData() = 0;

	virtual void SetSettingsData(const map<string,string> &setting_map) = 0;
	virtual void SetElectricalElementTypes(const set<ELECTRICALELEMENT> &type_set) = 0;

	/**
	 * This method is used to set parameters of electrical elements .
	 *
	 * @param xx_list container containing such electrical elements.
	 */
	virtual void SetVoltageSourceData(const vector<Electromotance> &electromotance_list) = 0;
	virtual void SetCurrentSourceData(const vector<CurrentSource> &currentSource_list) = 0;
	virtual void SetResistanceData(const vector<Resistance> &resistance_list) = 0;
	virtual void SetCapacitanceData(const vector<Capacitance> &capacitance_list) = 0;
	virtual void SetInductanceData(const vector<Inductance> &inductance_list) = 0;
	virtual void SetTransformerData(const vector<TransformerCaseFile> &transformer_list) = 0;
	virtual void SetCircuitBreakerData(const vector<CircuitBreaker> &circuitBreaker_list) = 0;
	virtual void SetCircuitBreakerChangeData(const vector<CircuitBreakerChange> &circuitBreakerChange_list) = 0;
	virtual void SetTransmissionLineData(const vector<TransmissionLineCaseFile> &ln_list) = 0;
	virtual void SetSynchronousGeneratorData(const vector<SynchronousGeneratorCaseFile> &sg_list) = 0;
	virtual void SetMultiMassData(const vector<MultiMassCaseFile> &mm_list) = 0;
	virtual void SetDieselGeneratorData(const vector<DieselGeneratorCaseFile> &dieselGenerator_list) = 0;
	virtual void SetExciterData(const vector<ExciterCaseFile> &exciter_list) = 0;
	virtual void SetVoltageSourceConverterData(const vector<VoltageSourceConverterCaseFile> &vsc_list) = 0;

	virtual void SetSynchronousGenerator_IFexc(bool flag) = 0;
	virtual void SetSynchronousGenerator_IFgov(bool flag) = 0;
	virtual void SetSynchronousGenerator_IFmass(bool flag) = 0;

	virtual const vector<d_complex> &GetSynchronousGenerator_Efd_base() = 0;

	virtual void SetExciter_Efd(const vector<d_complex> &Efd_list) = 0; 
	virtual void SetGovernor_Tm_me(const vector<d_complex> &Tm_me_list) = 0; 
	/**
	 * This method is used to set Wr2 parameters of MultiMass.
	 *
	 * @param Wr2_list parameters of MultiMass.
	 */
	virtual void SetMultiMass_Wr2(const vector<d_complex> &Wr2_list) = 0; 
	virtual void SetMultiMass_th2(const vector<d_complex> &th2_list) = 0; 

	/**
	 * Returns  all of electrical elements fields name
	 * split by ','
	 *
	 * This method is used to get the electrical elements fields name.
	 *
	 * @param type electrical element type
	 * (now supports SYNCHRONOUSGENERATOR,MULTIMASS,DIESELGENERATOR and EXCITER)
	 * @return the current of the electrical element(The index of the vector correspond to each electrical element).
	 */
	static const map<string,string> &GetElectricalElementFieldName(ELECTRICALELEMENT type);
};

#endif