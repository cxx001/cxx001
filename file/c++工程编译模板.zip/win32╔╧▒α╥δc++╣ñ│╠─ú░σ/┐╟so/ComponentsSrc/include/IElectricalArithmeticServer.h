#ifndef IELECTRICALARITHMETICSERVER_H
#define IELECTRICALARITHMETICSERVER_H

#include "../3rdparty/ElectricalArithmeticLibrary/include/Basic/ElectricalSystemStruct.h"
#include <QVector>
#include <QSharedPointer>

//�����������
#define SERVER_GROUP_ELECTRICALARITHMETIC_NAME "ElectricalArithmetic"
//����ӿ�����
#define SERVER_INTERFACE_ELECTRICALARITHMETIC_NAME "IElectricalArithmeticServer"

using namespace std;
namespace Kcc { namespace ElectricalArithmetic {
class IElectricalArithmeticServer {
 public:
  virtual void StartSimulation() = 0;
  virtual void StopSimulation() = 0;

  virtual void GetNodeVoltageMatData(QVector<d_complex> &data, int &rows,int &cols) = 0;
  virtual void GetVoltageSourceMatData(QVector<d_complex> &data, int &rows,int &cols) = 0;
  virtual void GetCapacitanceMatData(QVector<d_complex> &data,int &rows, int &cols) = 0;
  virtual void GetInductanceMatData(QVector<d_complex> &data,int &rows, int &cols) = 0;
  virtual void GetTransformerMatData(QVector<d_complex> &data,int &rows,int &cols) = 0;
  virtual void GetSynchronousGeneratorMatData(QVector<d_complex> &data,int &rows, int &cols) = 0;
  virtual void GetSynchronousGeneratorData(QVector<vec_sg>& data) = 0;
  virtual void GetMultiMassData(QVector<vec_mm> &data) = 0;

  virtual void SetSettingsData(const QMap<QString,QString> &setting_map) = 0;

  virtual void SetVoltageSourceData(const QVector<Electromotance> &electromotance_list) = 0;
  virtual void SetCapacitanceData(const QVector<Capacitance> &capacitance_list) = 0;
  virtual void SetInductanceData(const QVector<Inductance> &inductance_list) = 0;
  virtual void SetTransformerData(const QVector<Transformer> &transformer_list) = 0;
  virtual void SetSynchronousGeneratorData(const QVector<SynchronousGeneratorCaseFile> &sg_list) = 0;
  virtual void SetMultiMassData(const QVector<MultiMassCaseFile> &mm_list) = 0;
  virtual void SetCircuitBreakerData(const QVector<CircuitBreaker> &circuitBreaker_list) = 0;
  virtual void SetCurrentSourceData(const QVector<CurrentSource> &currentSource_list) = 0;
  virtual void SetCircuitBreakerChangeData(const QVector<CircuitBreakerChange> &circuitBreakerChange_list) = 0;
  virtual void SetResistanceData(const QVector<Resistance> &resistance_list) = 0;
};

typedef QSharedPointer<IElectricalArithmeticServer> PIElectricalArithmeticServer;
}}

#endif //IELECTRICALARITHMETICSERVER_H
