#pragma once
//#ifndef ELECTRICALSYSTEM_H
//#define ELECTRICALSYSTEM_H

#include <complex>
#include <vector>

using namespace std;

typedef std::complex<double> d_complex;

struct ExciterInput {
	double Vref;
	double Tb;
	double Tc;
	double Ta;
	double Ka;
	double Vamax;
	double Vamin;
	double Vuel;
	double Voel;
	double Vrmax;
	double Vrmin;
	double TE;
	double Ke;
	double SE1;
	double Efd1;
	double SE2;
	double Efd2;
	double KF;
	double TF;
	double KD;
	double KC;
	double Ifd0;
	int IF_SG;
};

struct SynchronousGeneratorOutput {
	d_complex Va;
	d_complex Vb;
	d_complex Vc;
	d_complex Efd;
	d_complex Efd_base;
	d_complex Ia;
	d_complex Ib;
	d_complex Ic;
	d_complex Ifd;
	d_complex I1d;
	d_complex I1q;
	d_complex I2q;
	d_complex Vd;
	d_complex Vq;
	d_complex V0;
	d_complex Id;
	d_complex Iq;
	d_complex I0;
	d_complex th;
	d_complex Wr;
	d_complex Tm_me;
	d_complex Te_el;
	d_complex dY;
	d_complex dDelta;
	d_complex dW;
	d_complex speedVd;
	d_complex speedVq;
	d_complex Fia;
	d_complex Fib;
	d_complex Fic;
	vector<d_complex> Lss;
	vector<d_complex> Lsr;
	vector<d_complex> Lrs;
	vector<d_complex> Lssi_a;
	vector<d_complex> Lsr_a;
	vector<d_complex> Lrs_a;
	vector<d_complex> SG_Edd;
	vector<d_complex> SG_Eqq;
	vector<d_complex> iSG_injection;
};

struct MultiMassOutput {
	d_complex th1;
	d_complex th2;
	d_complex th3;
	d_complex th4;
	d_complex th5;
	d_complex th6;
	d_complex Wr1;
	d_complex Wr2;
	d_complex Wr3;
	d_complex Wr4;
	d_complex Wr5;
	d_complex Wr6;
	d_complex dDelta1;
	d_complex dDelta2;
	d_complex dDelta3;
	d_complex dDelta4;
	d_complex dDelta5;
	d_complex dDelta6;
	d_complex dW1;
	d_complex dW2;
	d_complex dW3;
	d_complex dW4;
	d_complex dW5;
	d_complex dW6;
	d_complex Tpa_pb;
	d_complex Tgen_exc;
	d_complex Texc;
};

struct ExciterOutput {
	d_complex Vc;
	d_complex VE;
	d_complex Efd;
	d_complex Vfe;
	d_complex Vf;
	d_complex Y1;
	d_complex Y11;
	d_complex Y2;
	d_complex Y22;
	d_complex Y3;
	d_complex Y4;
};



struct DieselGeneratorOutput{
	double x11;
	double x12;
	double x13;
	double y1;
	double y2;
	double y3;
	double y4;
	double y51;
};

typedef vector<SynchronousGeneratorOutput> sg_out;
typedef vector<MultiMassOutput> mm_out;
typedef vector<DieselGeneratorOutput> dg_out;
typedef vector<ExciterOutput> ex_out;