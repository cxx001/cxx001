﻿#pragma once
//#ifndef ELECTRICALSYSTEM_H
//#define ELECTRICALSYSTEM_H

#include <complex>
#include <vector>
#include <map>
#include <set>

using namespace std;

typedef std::complex<double> d_complex;

enum INITVAL { V = 0, iSG,iE, iL, iC, iS, iT,SG,Mmass };

enum ELECTRICALELEMENT {
	CAPACITANCE = 0,					/*!< 电容 */
	CIRCUITBREAK,						/*!< 断路器 */
	CIRCUITBREAKER_CHANGE,		/*!< 断路开关控制信号 */
	ELECTROMOTANCE,					/*!< 电压 */
	INDUCTANCE,							/*!< 电感 */
	RESISTANCE,							/*!< 电阻 */
	CURRENT_SOURCE,					/*!< 电流源 */
	TRANSFORMER,						/*!< 变压器 */
	SYNCHRONOUSGENERATOR,	/*!< 同步电机 */
	MULTIMASS,							/*!< 多质量 */
	DIESELGENERATOR,					/*!< 柴油电机 */
	EXCITER,									/*!< 励磁机 */
	GOVERNOR,								/*!< 调速器 */
	RL3,
	TRANSMISSIONLINE,				/*!< 传输线 */
	VOLTAGESOURCECONVERTER/*!< 换流器 */
};

/**
 * @brief 电容
 */
struct Capacitance {
  string NAME;		/*!< 名称 */
  int FBUS;			/*!< 开始节点 */
  int TBUS;			/*!< 终止节点 */
  double VAL;		/*!< 数值 */
  double WF;		/*!< 积分方法加权值 */
  int AC;				/*!< 是否交流 */
};

/**
 * @brief 断路器
 */
struct CircuitBreaker {
  string NAME;		/*!< 名称 */
  int FBUS;			/*!< 开始节点 */
  int TBUS;			/*!< 终止节点 */
  int STATUS;		/*!< 当前状态 */
  int OPENFLAG;	/*!< 是否电流过零点断开标志 */
};

/**
 * @brief 断路开关控制信号
 */
struct CircuitBreakerChange {
  int ICB;				/*!< 对应的断路器编号或序号 */
  int STATUS;		/*!< 状态 */
  double TIME;		/*!< 状态改变时间 */
};

/**
 * @brief 电阻
 */
struct Resistance {
  string NAME;		/*!< 名称 */
  int FBUS;			/*!< 开始节点 */
  int TBUS;			/*!< 终止节点 */
  double VAL;		/*!< 数值 */
};

/**
 * @brief 电压源
 */
struct Electromotance {
  string NAME;		/*!< 名称 */
  int FBUS;			/*!< 开始节点 */
  int TBUS;			/*!< 终止节点 */
  double M;			/*!< 幅值 */
  double PH;			/*!< 初相位 */
  double F;			/*!< 工频 */
  int AC;				/*!< 是否交流 */
};

/**
 * @brief 电感
 */
struct Inductance {
  string NAME;		/*!< 名称 */
  int FBUS;			/*!< 开始节点 */
  int TBUS;			/*!< 终止节点 */
  double VAL;		/*!< 数值 */
  double WF;		/*!< 积分方法加权值 */
  int AC;				/*!< 是否交流元件 */
};

/**
 * @brief 电流源
 */
struct CurrentSource {
  string NAME;		/*!< 名称 */
  int BUS;				/*!< 节点 */
  double M;			/*!< 幅值 */
  double PH;			/*!< 初相位 */
};

/**
 * @brief 变压器
 */
struct TransformerCaseFile {
  string NAME;		/*!< 名称 */
  int HFBUS;			/*!< 原边开始节点 */
  int HTBUS;			/*!< 原边终止节点 */
  int LFBUS;			/*!< 副边开始节点 */
  int LTBUS;			/*!< 副边终止节点 */
  double HV;			/*!< 双绕组变压器高压侧额定电压（kV） */
  double LV;			/*!< 双绕组变压器低压侧额定电压（kV） */
  double LS;			/*!< 双绕组变压器电感 */
  double WF;		/*!< 微分方程求解方法加权值 1:梯形 0:向后欧拉法 范围(0-1),例如0.5 交流1,直流0*/
};

struct TransmissionLineCaseFile{
	string NAME;	/*!< 名称 */
	int FBUS;			/*!< 开始节点 */
	int TBUS;			/*!< 终止节点 */
	double RP;		/*!< 输电线分布式电阻值 （Ω） */
	double LP;		/*!< 输电线分布式电感值 （H） */
	double CP;		/*!< 输电线分布式电容值 （F） */
	double LEN;		/*!< 输电线线路长度 （km） */
	int NR_place;	/*!< 输电线等效电阻分段数（取值2或者3） */
};

struct SynchronousGeneratorCaseFile {
	string NAME;	/*!< 名称 */
	int BUSA;
	int BUSB;
	int BUSC;
	int INIflag;		/*!< 发电机状态是否初始化（默认值为1）*/
	double INIiM;	/*!< 发电机端口初始化电流幅值（A）*/
	double INIiPH;	/*!< 发电机端口初始化电流相位值（deg）*/
	double INIvM;	/*!< 发电机端口初始化电压幅值（V）*/
	double INIvPH;/*!< 发电机端口初始化电压相位值（deg）*/	
	double Sbase;	/*!< 发电机额定容量（VA）*/	
	double Vbase;	/*!< 发电机端口额定电压（V）*/	
	double H;			/*!< 同步发电机惯量时间常数（s）*/
	double KD;		/*!< 同步发电机转子阻尼系数 */
	double T_e2f;	/*!< 磁链方程开始求解时刻（s）*/
	double T_f2m;	/*!< 转子运动方程开始求解时刻（s）*/
	double T_m2m;/*!< 多质量块方程开始求解时刻（s）*/
	double Rsd;		
	double TGi;		
	double Tt;		
	double Wref;	/*!< 转子转速参考值（rad/s）*/
	double Tm_ref;/*!< 机械转矩参考值（p.u.）*/
	double DTM;	/*!< 磁链方程求解积分方法加权值（0-1之间取值）*/
	double Xd;		/*!< 发电机同步电抗d轴（p.u.）*/
	double Xq;		/*!< 发电机同步电抗q轴（p.u.）*/
	double Xl;		/*!< 发电机电枢漏抗（p.u.）*/
	double X0;		/*!< 发电机零序电抗（p.u.）*/
	double Xdp;		/*!< 发电机暂态电抗d轴（p.u.）*/
	double Xqp;		/*!< 发电机暂态电抗q轴（p.u.）*/
	double Xdpp;	/*!< 发电机次暂态电抗d轴（p.u.）*/
	double Xqpp;	/*!< 发电机次暂态电抗q轴（p.u.）*/
	double Ra;		/*!< 发电机电枢电阻（p.u.）*/
	double Td0p;	/*!< 发电机暂态时间常数d轴（s）*/
	double Tq0p;	/*!< 发电机暂态时间常数q轴（s）*/
	double Td0pp;	/*!< 发电机次暂态时间常数d轴（s）*/
	double Tq0pp;	/*!< 发电机次暂态时间常数q轴（s）*/
	double Hybrid;	/*!< 采用的发电机模型类型（默认值0）*/
	int IF_exc;	/*!< 是否连接励磁机转子（默认值0）*/
	int IF_Gov;	/*!< 是否连接调速器转子（默认值0）*/
	int IF_mass;	/*!< 是否连接多质量块转子（默认值0）*/
};

struct SynchronousGeneratorOutput {
	d_complex Va;
	d_complex Vb;
	d_complex Vc;
	d_complex Efd;
	d_complex Efd_base;
	d_complex Ia;
	d_complex Ib;
	d_complex Ic;
	d_complex Ifd;
	d_complex I1d;
	d_complex I1q;
	d_complex I2q;
	d_complex Vd;
	d_complex Vq;
	d_complex V0;
	d_complex Id;
	d_complex Iq;
	d_complex I0;
	d_complex th;
	d_complex Wr;
	d_complex Tm_me;
	d_complex Te_el;
	d_complex dY;
	d_complex dDelta;
	d_complex dW;
	d_complex speedVd;
	d_complex speedVq;
	d_complex Fia;
	d_complex Fib;
	d_complex Fic;
	vector<d_complex> Lss;
	vector<d_complex> Lsr;
	vector<d_complex> Lrs;
	vector<d_complex> Lssi_a;
	vector<d_complex> Lsr_a;
	vector<d_complex> Lrs_a;
	vector<d_complex> SG_Edd;
	vector<d_complex> SG_Eqq;
	vector<d_complex> iSG_injection;
};

struct MultiMassCaseFile {
	string NAME;
	double N_mass;
	double H1;
	double H2;
	double H3;
	double H4;
	double H5;
	double H6;
	double k12;
	double k23;
	double k34;
	double k45;
	double k56;
	double D1;
	double D2;
	double D3;
	double D4;
	double D5;
	double D6;
	double FLpa;
	double FLpb;
	double FLIp;
	double FLHp;
	double Rexc;
	double DF;
};

struct MultiMassOutput {
	d_complex th1;
	d_complex th2;
	d_complex th3;
	d_complex th4;
	d_complex th5;
	d_complex th6;
	d_complex Wr1;
	d_complex Wr2;
	d_complex Wr3;
	d_complex Wr4;
	d_complex Wr5;
	d_complex Wr6;
	d_complex dDelta1;
	d_complex dDelta2;
	d_complex dDelta3;
	d_complex dDelta4;
	d_complex dDelta5;
	d_complex dDelta6;
	d_complex dW1;
	d_complex dW2;
	d_complex dW3;
	d_complex dW4;
	d_complex dW5;
	d_complex dW6;
	d_complex Tpa_pb;
	d_complex Tgen_exc;
	d_complex Texc;
};

struct DieselGeneratorCaseFile {
	string NAME;
	double T1;
	double T2;
	double T3;
	double K;
	double Ta1;
	double Ta2;
	double Ta3;
	double Tmax;
	double Tmin;
	double Td;
	double Pm0;
	double Wref;
};

struct DieselGeneratorOutput{
	double x11;
	double x12;
	double x13;
	double y1;
	double y2;
	double y3;
	double y4;
	double y51;
};

struct ExciterInput {
	double Vref;
	double Tb;
	double Tc;
	double Ta;
	double Ka;
	double Vamax;
	double Vamin;
	double Vuel;
	double Voel;
	double Vrmax;
	double Vrmin;
	double TE;
	double Ke;
	double SE1;
	double Efd1;
	double SE2;
	double Efd2;
	double KF;
	double TF;
	double KD;
	double KC;
	double Ifd0;
	int IF_SG;
};

struct ExciterCaseFile {
	string NAME;
	double Vref;
	double Tb;
	double Tc;
	double Ta;
	double Ka;
	double Vamax;
	double Vamin;
	double Vuel;
	double Voel;
	double Vrmax;
	double Vrmin;
	double TE;
	double Ke;
	double SE1;
	double Efd1;
	double SE2;
	double Efd2;
	double KF;
	double TF;
	double KD;
	double KC;
	double Ifd0;
	int IF_SG;
};

struct ExciterOutput {
	double Vc;
	double VE;
	int Flag;
	double Efd;
	double Vfe;
	double Vf;
	double Y1;
	double Y11;
	double Y2;
	double Y22;
	double Y3;
	double Y4;
};

struct VoltageSourceConverterCaseFile{
	string NAME;
	int BUSA;
	int BUSB;
	int BUSC;
	int BUSP;
	int BUSN;
	int MOD;
	double Vdc_ref;
	double VLL_ac;
	double car_F;
	double R_dc;
	double C_dc;
	double Idc0;
	double Rf;
	double Lf;
	int Cmod;
	double WF;
	int Para_auto;
	double Kiv;
	double Kpv;
	double Kii;
	double Kpi;
	double KiPe;
	double KpPe;
	double KiQe;
	double KpQe;
	double Pe_ref;
	double Qe_ref;
};

struct VSC_PLL{
	double theta;
	double Wmea;
	double PI_inh;
	double PI_outh_I;
	double theta_inh;
	double Pi;
	double Ti;
	double W0;
};

struct VoltageSourceConverterOutput{
	vector<d_complex> iL_f;
	vector<d_complex> vL_f;
	d_complex Vdc_P;
	d_complex idc_P;
	d_complex Vdc_N;
	d_complex idc_N;
	VSC_PLL PLL;
	d_complex YVdc;
	d_complex Vdc_err;
	d_complex YId;
	d_complex Id_err;
	d_complex Id;
	d_complex YIq;
	d_complex Iq_err;
	d_complex Iq;
	d_complex YPe;
	d_complex YQe;
	d_complex Ma;
	d_complex Mb;
	d_complex Mc;
	d_complex Pe;
	d_complex Qe;
	d_complex Vdc_eq;
	d_complex Irec;
};

typedef vector<SynchronousGeneratorOutput> sg_out;
typedef vector<MultiMassOutput> mm_out;
typedef vector<DieselGeneratorOutput> dg_out;
typedef vector<ExciterOutput> ex_out;
typedef vector<VoltageSourceConverterOutput> vsc_out;