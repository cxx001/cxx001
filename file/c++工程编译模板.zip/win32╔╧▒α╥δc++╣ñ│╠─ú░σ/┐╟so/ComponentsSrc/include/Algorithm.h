#pragma once

#include <type_traits>

#ifdef ALG_DLL
#define ALGORITHM_EXPORT extern "C" __declspec(dllexport)
#else
#define ALGORITHM_EXPORT extern "C" __declspec(dllimport)
#endif

typedef unsigned int size_t;

///GSL������
ALGORITHM_EXPORT void SetGSLErrorHandle();
///GSL������Ϣ
ALGORITHM_EXPORT const char *StrErrorNo(const int eno);
/// ��ʼ����typeΪ��ֵ���ͣ�����ֵ<0ʧ��
ALGORITHM_EXPORT int Interpolation_init(void **vpack, const double *x, const double *y, size_t size, int type);
/// 2d��ֵ��ʼ����typeΪ��ֵ���ͣ�����ֵ<0ʧ��
ALGORITHM_EXPORT int Interpolation2d_init(void **vpack, const double *x, const double *y, const double *z, size_t xsize,size_t ysize, int type);
/// ������ҳ�ʼ���ӿ�
ALGORITHM_EXPORT int Interpolation_inverse_init(void **vpack, const double *x, const double *y, size_t size, int type);
/// ��ֵ���㣬����ֵ<0����
ALGORITHM_EXPORT int Interpolation_run(void *vpack, double x, double *y, bool extType);
ALGORITHM_EXPORT int Interpolation2d_run(void *vpack, double x, double y, double *z, bool extType);
/// һ�׵�
ALGORITHM_EXPORT int Interpolation_deriv(void *vpack, double x, double *y, bool extType = true);
/// ���׵�
ALGORITHM_EXPORT int Interpolation_deriv2(void *vpack, double x, double *y, bool extType = true);
/// �ͷ��ڴ�
ALGORITHM_EXPORT void Interpolation_free(void *vpack);
ALGORITHM_EXPORT void Interpolation2d_free(void *vpack);
/// �������,y = a + b * x
ALGORITHM_EXPORT int Fit_linear_init(const double *x, const double *y, size_t n, double *a, double *b);
/// ��΢�ַ���
/// ��������㹫ʽ
typedef int (*pfunc)(double,const double*,double*,void*);
/// �ſɱȾ���
typedef int (*pjac)(double,const double*,double*,double*,void*);
/// ��ʼ��
ALGORITHM_EXPORT int Odeiv_init(void **vpack, pfunc pfc, pjac pjc, size_t dim, void *param, double hstep, int algtype = 0, double epsabs = 1e-3, double epsrel = 1e-3);
/// ����
ALGORITHM_EXPORT int Odeiv_run(void *vpack, double t, double hstep, double *y);
/// �ͷ�
ALGORITHM_EXPORT void Odeiv_free(void *vpack);

// �򵥵��㷨ֱ����������
ALGORITHM_EXPORT double Ln(double x);
ALGORITHM_EXPORT double Sqr(double x);
ALGORITHM_EXPORT double Mod(double x1, double x2);
ALGORITHM_EXPORT double Frac(double x);
ALGORITHM_EXPORT double PI();
ALGORITHM_EXPORT double TwoPI();
ALGORITHM_EXPORT double E();
ALGORITHM_EXPORT double Gain(double x, double a);
ALGORITHM_EXPORT double SineWave(double amp, double freq, double phase, double bias, double t);
template <typename T>
T Max(T a)
{
    return a;
}
template <typename T, typename... Args>
typename std::common_type<T, Args...>::type Max(T a, Args... args)
{
    auto b = Max(args...);
    return a > b ? a : b;
}
template <typename T>
T Min(T a)
{
    return a;
}
template <typename T, typename... Args>
typename std::common_type<T, Args...>::type Min(T a, Args... args)
{
    auto b = Min(args...);
    return a < b ? a : b;
}

/// DSL���⺯��
ALGORITHM_EXPORT double DSL_aflipflop(double yi, double set, double rst, double &yiS, bool &state, bool &initflg);
ALGORITHM_EXPORT double DSL_delay(double yi, double Tdelay, void *buf, double stepSize, bool &initflg);
ALGORITHM_EXPORT bool DSL_flipflop(double set, double rst, bool &state, bool &initflg);
ALGORITHM_EXPORT double DSL_gradlim_const(double yi, double min, double max, double stepsize, double &yo, bool &initflg);
ALGORITHM_EXPORT double DSL_lastvalue(double yi, double &lastv, bool &initflg);
ALGORITHM_EXPORT double DSL_lim(double yi, double min, double max);
ALGORITHM_EXPORT double DSL_limstate(double &yi, double min, double max);
ALGORITHM_EXPORT double DSL_movingavg(double yi, double Tdel, double Tlen, void *buf, double stepSize, bool &initflg);
ALGORITHM_EXPORT bool DSL_picdro(double yi, double Tpick, double Tdrop, bool &state, double &dur, double stepSize, bool &initflg);
ALGORITHM_EXPORT double DSL_select(bool flg, double x, double y);
ALGORITHM_EXPORT double DSL_selfix(bool flg, double x, double y, bool &expr, bool &initflg);
ALGORITHM_EXPORT double DSL_time(double stepSize, double steps);
ALGORITHM_EXPORT void DSL_buf_free(void *buf);