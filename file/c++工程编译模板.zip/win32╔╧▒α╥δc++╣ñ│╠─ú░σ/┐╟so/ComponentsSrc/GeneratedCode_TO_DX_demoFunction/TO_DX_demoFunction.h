#ifndef _CODE_TEMPLATE_H_
#define _CODE_TEMPLATE_H_

#include <string>
#include <vector>
#include <complex>

using std::vector;
using std::complex;
using std::string;

#include "Algorithm.h"
#include "BlockLibCommon.h"
#include "BlockDataType.h"

CE_VarTable *g_ce_var_tab;
CE_Log *g_ce_log;

class Block_TO_DX_demoFunction {
public:
  Block_TO_DX_demoFunction(const char *name, const void * pData) : block_name_(name) ,pData_(pData){
    		// TODO �����ͳ�ʼ�� fp_ = 0;
		// TODO �����ͳ�ʼ�� ode_ = 0;

  }

  ~Block_TO_DX_demoFunction() {}

  bool init(void *var_tab_inst) {
    		INIT_O(y0);
		INIT_O(y1);
		INIT_O(y2);
		INIT_O(y3);
		INIT_O(y4);
		INIT_O(y5);
		INIT_O(y6);
		INIT_P(p0);
		INIT_P(p1);
		INIT_P(p2);
		INIT_P(p3);
		INIT_P(p4);
		INIT_P(p5);
		INIT_P(p6);

    INIT_C(steps);
    INIT_C(step_size);
    INIT_C(total_running_time);
    INIT_C(algtype);
    INIT_C(epsabs);
    INIT_C(epsrel);
    return initInternalVariable();
  }

  bool initInternalVariable();

  void runAlgorithm(void * g=nullptr);

  void destroyInternalVariable();

private:
  	DEFINE_O(double, y0);
	DEFINE_O(double, y1);
	DEFINE_O(double, y2);
	DEFINE_O(double, y3);
	DEFINE_O(double, y4);
	DEFINE_O(double, y5);
	DEFINE_O(double, y6);
	DEFINE_P(string, p0);
	DEFINE_P(int, p1);
	DEFINE_P(string, p2);
	DEFINE_P(int, p3);
	DEFINE_P(string, p4);
	DEFINE_P(int, p5);
	DEFINE_P(int, p6);

  	void* fp_;
	void* ode_;


   DEFINE_C(uint64_t, steps);
   DEFINE_C(double, step_size);
   DEFINE_C(double, total_running_time);
   DEFINE_C(int, algtype);
   DEFINE_C(double, epsabs);
   DEFINE_C(double, epsrel);
   
   const std::string block_name_;
   const void * pData_;
};

static void* Create(const char* name,const void * pData) {
  return new Block_TO_DX_demoFunction(name,pData);
}

static void Destory(void* inst) {
  if (inst != NULL) {
	((Block_TO_DX_demoFunction*)inst)->destroyInternalVariable();
    delete ((Block_TO_DX_demoFunction*)inst);
    inst = NULL;
  }
}

static bool Init(void* inst, void* var_tab) {
  return ((Block_TO_DX_demoFunction*)inst)->init(var_tab);
}

static void Run(void* inst,void * g=nullptr) {
  ((Block_TO_DX_demoFunction*)inst)->runAlgorithm(g);
}

static BL_Instance g_bl_instance = {
    Create,
    Destory,
    Init,
    Run,
};

// ����ӿڣ���������->ģ���
BEGIN_IMPORT_INTERFACE
IMPORT_INTERFACE(g_ce_var_tab, CE_VarTable, CE_VAR_TABLE_INTERFACE)
IMPORT_INTERFACE(g_ce_log, CE_Log, CE_LOG_INTERFACE)
END_IMPORT_INTERFACE

// �����ӿ�, ģ���->��������
BEGIN_EXPORT_INTERFACE
EXPORT_INTERFACE(g_bl_instance, BL_Instance, BL_INSTANCE_INTERFACE)
END_EXPORT_INTERFACE
#endif // _CODE_TEMPLATE_H_
