#ifndef _CODE_TEMPLATE_H_
#define _CODE_TEMPLATE_H_

#include <string>
#include <vector>
#include <complex>

using std::vector;
using std::complex;
using std::string;

#include "Algorithm.h"
#include "BlockLibCommon.h"
#include "BlockDataType.h"

CE_VarTable *g_ce_var_tab;
CE_Log *g_ce_log;

class Block_Engine_Tank {
public:
  Block_Engine_Tank(const char *name, const void * pData) : block_name_(name) ,pData_(pData){
    		// TODO �����ͳ�ʼ�� x0 = 0;
		// TODO �����ͳ�ʼ�� fp_ = 0;
		// TODO �����ͳ�ʼ�� ode_ = 0;

  }

  ~Block_Engine_Tank() {}

  bool init(void *var_tab_inst) {
    		INIT_I(u0);
		INIT_O(y0);
		INIT_P(p0);
		INIT_S(x0);

    INIT_C(steps);
    INIT_C(step_size);
    INIT_C(total_running_time);
    INIT_C(algtype);
    INIT_C(epsabs);
    INIT_C(epsrel);
    return initInternalVariable();
  }

  bool initInternalVariable();

  void runAlgorithm(void * g=nullptr);

  void destroyInternalVariable();

private:
  	DEFINE_I(double, u0);
	DEFINE_O(double, y0);
	DEFINE_P(double, p0);

  	double x0;
	void* fp_;
	void* ode_;


   DEFINE_C(uint64_t, steps);
   DEFINE_C(double, step_size);
   DEFINE_C(double, total_running_time);
   DEFINE_C(int, algtype);
   DEFINE_C(double, epsabs);
   DEFINE_C(double, epsrel);
   
   const std::string block_name_;
   const void * pData_;
};

static void* Create(const char* name,const void * pData) {
  return new Block_Engine_Tank(name,pData);
}

static void Destory(void* inst) {
  if (inst != NULL) {
	((Block_Engine_Tank*)inst)->destroyInternalVariable();
    delete ((Block_Engine_Tank*)inst);
    inst = NULL;
  }
}

static bool Init(void* inst, void* var_tab) {
  return ((Block_Engine_Tank*)inst)->init(var_tab);
}

static void Run(void* inst,void * g=nullptr) {
  ((Block_Engine_Tank*)inst)->runAlgorithm(g);
}

static BL_Instance g_bl_instance = {
    Create,
    Destory,
    Init,
    Run,
};

// ����ӿڣ���������->ģ���
BEGIN_IMPORT_INTERFACE
IMPORT_INTERFACE(g_ce_var_tab, CE_VarTable, CE_VAR_TABLE_INTERFACE)
IMPORT_INTERFACE(g_ce_log, CE_Log, CE_LOG_INTERFACE)
END_IMPORT_INTERFACE

// �����ӿ�, ģ���->��������
BEGIN_EXPORT_INTERFACE
EXPORT_INTERFACE(g_bl_instance, BL_Instance, BL_INSTANCE_INTERFACE)
END_EXPORT_INTERFACE
#endif // _CODE_TEMPLATE_H_
