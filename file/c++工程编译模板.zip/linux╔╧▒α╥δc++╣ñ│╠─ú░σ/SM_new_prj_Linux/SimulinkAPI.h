/********************************************************************
 * 文件名:SimulinkAPI.h
 * 功能：Simulink模型调用API接口
*********************************************************************/
#ifndef SIMULINKAPI_H_
#define SIMULINKAPI_H_
#include <stdint.h>


typedef struct {
  // 模型运行路径
  char szModelPath[1024];
  
  // 参数个数
  uint32_t numParams;

  // 参数基地址
  void *paramBaseAddr;
  
  // 参数映射表
  void **paramAddrMap;

  // 信号个数
  uint32_t numSignals;
  
  // 信号基地址
  void *signalBaseAddr;
} ModelInitParam;

// Simulink 模型初始化
extern  int SL_InitModel(const ModelInitParam *modelInitParam);

// SimuLink模型释放资源
extern int SL_UninitModel();

// 等待条件
extern int SL_WaitRunCond();

// 执行一步前处理
extern void SL_RunOneStepBeforeDeal();

// 执行一步后处理
extern void SL_RunOneStepAfterDeal();

// 执行主计算后处理
extern void SL_RunMajorComputeAfterDeal();

#endif