cd ./temp
make clean
cd ..
