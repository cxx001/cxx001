#include "temp/CtrlSysCore/CtrlSysLib.h"
#ifdef __cplusplus
extern "C" {
#endif
#include "SimulinkAPI.h"
#ifdef __cplusplus
}
#endif
#include <unistd.h>
#include <string.h>
#include <fstream>

#ifdef _WIN32
#include <Windows.h>
#else
#include <dlfcn.h>
#endif


#ifdef _WIN32
#define GHANDLE HINSTANCE 
#else
#define  GHANDLE void* 
#endif


// 判断文件是否存在
static bool IsFileExist(const std::string strFile);

void* handleCtrlSys(nullptr);


bool InitDynamicLib()
{
#ifdef _WIN32
  std::string strPath = "libCtrlSysTest.dll";
#else
  std::string strPath = "libCtrlSysTest.so";
#endif
  if(!IsFileExist(strPath)) {
    printf("so file is not exist!\n");
    return false;
  } 
  return true;
}


bool InitModel(void) {
  bool bInit = InitDynamicLib();
  if(!bInit) {
    printf("InitDynamicLib failed!\n");
    return false;
  }
  handleCtrlSys = getCtrlSys();
  if(handleCtrlSys == nullptr) {
    printf("getCtrlSys call failed!\n");
    return false;
  } 
  return true;
}

void OneStep(void) {
  runOnce(handleCtrlSys, false);
  SL_RunMajorComputeAfterDeal();
}

void TermModel(void) {
    releaseCtrlSys(handleCtrlSys);
    printf("TermModel commpleted!\n");
}

int main()  // main(int argc, char **argv)
{
  ModelInitParam modelInitParam;
  memset(&modelInitParam, 0, sizeof(modelInitParam));
  char szCurDir[1024] = {0};
  #if KLCC_WIN
  strcpy(szCurDir, ".\\");
  #else
  getcwd(modelInitParam.szModelPath, sizeof(modelInitParam.szModelPath));
  #endif


  if(!InitModel()) {
    printf("InitModel failed");
    return -1;
  }
  
  modelInitParam.numParams = getParamsCnt(handleCtrlSys) ;
  modelInitParam.paramBaseAddr =  getParamsBaseAddr(handleCtrlSys);
  modelInitParam.numSignals = getOutputCnt(handleCtrlSys) ; // 信号技术个数
  modelInitParam.signalBaseAddr = getOutputBaseAddr(handleCtrlSys);
  modelInitParam.paramAddrMap = getParamAddrs(handleCtrlSys);

  if (SL_InitModel(&modelInitParam) != 0) {
    printf("SL_InitModel Failed \n");
    return -1;
 }

  while (1) {
    if (SL_WaitRunCond() != 0) {
      break;
    }

    SL_RunOneStepBeforeDeal();
    OneStep();
    SL_RunOneStepAfterDeal();
  }

  TermModel();
  SL_UninitModel();
  return 0;
}


bool IsFileExist(const std::string strFile)
{
    return access(strFile.c_str(), 0) == 0 ? true : false;
}