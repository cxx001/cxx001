#ifndef _rtapi_h_
#define _rtapi_h_

#define RTAPI

#endif
