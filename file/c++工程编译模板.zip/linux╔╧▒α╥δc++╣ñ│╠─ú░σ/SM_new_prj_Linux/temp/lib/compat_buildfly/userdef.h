#ifndef _USERDEF_
#define _USERDEF_

#ifdef _MSC_VER
#ifndef _export
#define _export __declspec(dllexport)
#endif
#else

#ifndef _WIN32
typedef void *HINSTANCE;
typedef void *HDC;
typedef void *RECT;
typedef void *HWND;
#endif

typedef void *LPVOID;
typedef unsigned long DWORD;
typedef const char *LPCSTR;
typedef int BOOL;
typedef unsigned int UINT;
#define _export
#endif

#include <assert.h>
#include <math.h>
#include <string.h>

#include <fstream>
#include <string>
#include <strstream>
#include <iostream>

#include "stdio.h"

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef ASSERT
#define ASSERT assert
#endif

#ifndef dllexport
#define dllexport
#endif

#ifndef __declspec
#define __declspec(x)
#endif

#ifndef VOID
#define VOID void
#endif


#if _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
// 消息类名:	平台消息

// 消息定义模块:	System
// 消息定义注释:	定义平台消息,用户可以作为触发消息
#define PM_START 10000           // 程序启动，平台消息类起点
#define PM_PRE_OPENPRJ 10001     // 将打开工程文件消息
#define PM_PRE_CLOSEPRJ 10002    // 将关闭工程文件消息
#define PM_OPENPRJ 10003         // 已经打开工程文件消息
#define PM_CLOSEPRJ 10004        // 已经关闭工程文件消息
#define PM_READPRJ 10005         // 读取工程文件
#define PM_WRITEPRJ 10006        // 写入工程文件
#define PM_UPDATEPRJ 10007       // 依据工程项目更新配置消息
#define PM_OPENMODEL 10008       // 依据工程项目更新配置消息
#define PM_CLOSEMODEL 10009      // 依据工程项目更新配置消息
#define PM_MODELINFO 10010       // 获取模型信息消息
#define PM_DLLINFO 10011         // 获取DLL信息消息
#define PM_DLLUNLOAD 10012       // DLL卸载消息
#define PM_FCTINFO 10013         // 获取函数信息消息
#define PM_DLLVIEW 10014         // DLL模块预览消息
#define PM_FCTVIEW 10015         // 函数预览消息
#define PM_OUTPUTMSG 10016       // 在输出栏中显示消息
#define PM_BFNOTIFYMSG 10017     // 平台提示消息
#define PM_STARTTIMER 10018      // 平台启动定时器，刷新界面显示
#define PM_UPDATEINFOBAR 10019   // 更新节点信息栏的显示内容
#define PM_STARTINOFTIMER 10020  // 启动信息显示定时器
#define PM_STOPINOFTIMER 10021   // 启动信息显示定时器
#define PM_EXIT 10050            // 程序退出

#define PM_TIME -101010101  // 显示通知消息时不显示时间

// 消息类名:	系统仿真消息

// 消息定义模块:	System
// 消息定义注释:	定义系统仿真消息,用户可以作为触发消息
#define SM_START 10100        // 仿真开始消息,仿真进程消息类起点
#define SM_INFO 10101         // 获得模型信息消息
#define SM_INITIALIZE 10102   // 仿真初始化消息
#define SM_CONTINUE 10103     // 仿真继续消息
#define SM_STEPOVER 10104     // 仿真一步结束消息
#define SM_PAUSE 10105        // 仿真暂停消息
#define SM_STOP 10106         // 仿真结束消息
#define SM_DEBUGMODEL 10107   // 仿真调试消息
#define SM_BULIDMODEL 10108   // 建立分析模型消息
#define SM_STEPCHANGED 10109  // 仿真步长改变消息
#define SM_TIMEALIGN 10110    // 时标对齐消息
#define SM_WRITEDATA 10111    // 写数据文件消息
#define SM_USERMSG 10112      // 用户返回消息
#define SM_BREAKPOINT 10113   // 仿真到达断点
#define SM_ERROR 10114        // 仿真错误消息
#define SM_CREATE 10115       // 用户模块构造消息
#define SM_DESTROY 10116      // 用户模块销毁消息
#define SM_DRAW 10117         // 用户模块绘制消息
#define SM_WRITE 10118        // 用户模块数据存储消息
#define SM_READ 10119         // 用户模块数据读取消息
#define SM_RESTART 10120      // 重新启动一次仿真
#define SM_END 10121          // 一次仿真结束消息
#define SM_MONTE 10122        // 启动蒙特卡罗仿真
#define SM_STOPMODEL 10123    // 模块撤销消息
#define SM_OUTPUT 10124       // 模型输出消息
#define SM_UPDATE 10125       // 仿真完成一步或更新离散状态
#define SM_RENEW 10126        // 更新状态消息
#define SM_SIMUMETHOD 10127   // 仿真积分算法改变消息
#define SM_STOPALL 10128      // 停止全部仿真
#define SM_SAVESNAP 10129     // 通知用户保存当前状态
#define SM_LOADSNAP 10130     // 通知用户加载当前状态
#define SM_NOACT 10150        // 没有进行任何仿真动作

// 消息类名:	分布仿真消息

// 消息定义模块:	System
// 消息定义注释:	定义分布仿真消息,用户可以作为触发消息
#define SM_VSM_START 10200  // 网络启动仿真消息,仿真进程消息类起点
#define SM_VSM_REGISTER 10201     // 网络注册开始注册消息
#define SM_VSM_ENDREGISTER 10202  // 网络注册结束注册消息
#define SM_VSM_READY 10203        // 网络准备好消息
#define SM_VSM_STOP 10204         // 网络停止消息
#define SM_VSM_PAUSE 10205        // 网络暂停状态消息
#define SM_VSM_IDLE 10206         // 网络空闲状态消息
#define SM_VSM_SYNC 10207         // 网络数据同步消息
#define SM_VSM_STEPBEGIN 10208    // 主控节点开始仿真一步
#define SM_VSM_STEPOVER 10209     // 主控节点仿真一步结束

#ifndef MIN
#define ABS(x) ((x) > 0.0 ? (x) : -(x))
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#define SIGN(x) ((x) >= 0.0 ? 1 : -1)
#define SIGN2(x, y) ((x) >= 0.0 ? ABS((y)) : -ABS((y)))
#endif

#ifndef PI
#define PI 3.14159265359
#endif

#define XDIM 50
#define YDIM 50
#define UDIM 50
#define DATADIM 50
#define FILEDIM 30
#define PTRDIM 10
//#define DB  double
//#define PDB double*

// User model information

#define UFI_TEXT 1      // lpText is valid
#define UFI_TITLE 2     // lpTitle is valid
#define UFI_XTEXT 4     // lpXText is valid
#define UFI_YTEXT 8     // lpYText is valid
#define UFI_UTEXT 16    // lpUText is valid
#define UFI_IMAGE 32    // Image is valid
#define UFI_PARAM 64    // fParam is valid
#define UFI_STEP 128    // step is valid
#define UFI_DATA 256    // data is valid
#define UFI_CTRL 512    // data is valid
#define UFI_ALL 0xFFFF  // all are valid

// User model dialog
#define UPS_DEFAULT 0  // data exchange is use common propertypage
#define UPS_DLG 1      // data exchange is a dialog
#define UPS_PAGE 2     // data exchange is propertypage's
#define UPS_ADDPAGE 3  // data exchange is use common propertypage

#define UDLG_BEGIN 1  // system begin dial
#define UDLG_END 2    // system end dial

/*  Simulation method Macros */
#define SIMU_EULER_FIX 0
#define SIMU_SIMPSON_FIX 1
#define SIMU_RK2_FIX 2
#define SIMU_RK3_FIX 3
#define SIMU_RK4_FIX 4
#define SIMU_ADAMS_FIX 5
#define SIMU_DISCRETE 6
#define SIMU_EULER_VAR 7
#define SIMU_RK4_VAR 8
#define SIMU_GILL_ONE 9
#define SIMU_TREANOR_ONE 10

// 参数类型
#define PT_INT 1
#define PT_DB 2
#define PT_STR 3
#define PT_FILE 4
#define PT_OPTION 5
#define PT_TITLE 6
#define PT_BOOL 7
#define PT_PATH 8

#define F_DATA 1
#define F_TABLE 2
#define F_FIG 3
#define F_INI 4
#define F_TMP 5
#define F_OTHER 6

typedef int (*RUNPROC)(int message, int param, double time, double step,
                       double* x, double* u, double* y, double* f);

// callback functions
typedef int (*DRAWPROC)(HDC hdc, RECT rc, void* userdata);
typedef int (*PARAMPROC)(int state, HWND Partent, void* userdata);
typedef int (*WRITEPROC)(std::ofstream out, void* userdata);
typedef int (*READPROC)(std::ifstream in, void* userdata);
typedef int (*WRITEPROCSTR)(std::ostrstream out, void* userdata);
typedef int (*READPROCSTR)(std::strstream in, void* userdata);
typedef int (*CTRLPROC)(HWND parent, RECT rc, void* userdata);
typedef int (*COPYPROC)(void* dest, void* src);
typedef int (*CREATEPROC)(void* userdata);
typedef int (*DESTROYPROC)(void* userdata);

typedef void (*REALCALLPROC)(int, double, double, LPVOID);
typedef bool (*EXTCLOCKTESTPROC)(int*, double*, double*, LPVOID);
typedef bool (*REALTESTCALLPROC)(int*, double*, double*, LPVOID);

typedef double (*SIMUPROC)(int n, double x, double* y, double* f, double h,
                           int (*Fct)(double x, double, double* y, double f));

typedef struct {
  int Select;  // 选择标志
  int xDim;    // 状态维数
  int uDim;    // 输入维数
  int yDim;    // 输出维数
  int bSimu;   // 仿真标志
  int Address;
  double Step;  // 模型仿真步长

  char DllFile[255];   // 动态库文件
  char WorkPath[255];  // 主工作路径
  char Name[40];       // 函数名
  char Text[128];      // 函数描述
  char FctName[30];    // 函数名

  // work data
  int Flag[DATADIM];        // 标志
  int Num[DATADIM];         // Y writting position
  double Data[DATADIM];     // 数据
  char File[FILEDIM][256];  // 数据文件
  void* pPtr[PTRDIM];  // 用来存放其它数据指针，如用户新建的类
  void* ptr;           // 用来存放 CUserfct的指针，系统保留
  void* pMsgParam;     //向接口传递时用来存放消息数据指针
  void* pData;         //用来存放用户自定义datasize的数据指针

  double X0[XDIM];  // 初始状态
  double* X;        // 状态指针
  double* F;        // 状态导数指针
  double* U;        // 输入指针
  double* Y;        // 输出指针

  int bOver;        // 溢出标志
  int SimuMethod;   // 仿真方法
  double Maxfloat;  // 最大浮点

  RUNPROC Fct;  // 函数指针
} MODEL;

typedef struct {
  int mask;
  int xDim;
  int uDim;
  int yDim;
  int image;
  int dlg;
  BOOL bOpen;  // 20180821新加，是否右键激活“打开”菜单项
  char* text;
  char* title;
  char* file;
  char** xText;
  char** uText;
  char** yText;
  double step;
  DRAWPROC fDraw;
  PARAMPROC fParam;
  WRITEPROC fWrite;
  WRITEPROCSTR fWriteStr;
  READPROC fRead;
  READPROCSTR fReadStr;
  COPYPROC fCopy;
  CTRLPROC fCtrl;
  CREATEPROC fCreate;  //模型创建时调用一次，传入data
  DESTROYPROC
      fDestroy;  //模型销毁时调用一次，传入data，自行销毁data时，要将*data=NULL
  int nVerMajor;
  int nVerMinor;
  int nUserDatasize;
  MODEL* model;
  void* pUserData;
} USERINFO;

typedef struct {
  char* title;            //标题
  char* text;             //说明
  int image;              //图片id
  char strPathfile[255];  //路径，传给动态库
  char nodeName[128];
  int nVerMajor;  //主板本号
  int nVerMinor;  //次板本号
  char* company;
  DWORD dwFlag;       //标志或附加数据
  int nReserved;      //保留
  LPVOID lpReserved;  //保留
} DLLINFO;

//仿真过程中平台向用户透明的设置，用户通过api函数可以得到这些设置
typedef struct {
  double StartTime;       //仿真开始时间
  double EndTime;         //仿真结束时间
  double step;            //仿真步长
  int Method;             //仿真方法
  int simuType;           //仿真类型
  int nLoopCount;         //当前循环运行到第几次
  char workPath[255];     //当前工作路径
  char inDataPath[255];   //数据输入路径
  char outDataPath[255];  //数据输出路径
} SIMUSTRUCT;
///////////////////////////////////////////////////////////////////////////////////
// Table data structure
typedef struct {
  char FileName[255];
  int seg;  // block的数量，最大10个
  int col[8];  // col[0]存放几维插值，后面7位存放每一维插值的节点数
  long k;        //节点数据个数和插值数据个数的总和
  int n;         //插值维数的和
  int l[7];      //插值维数，最大7维
  double value;  //插值结果
  double x[7];   //插值的输入数组
  double* z;     //插值数据存放数组，动态分配
} TABLE;

//在定义该数据表后调用该函数予以初始化数据表指针
int _export InitTableBuffer(TABLE* a);
int _export ReadTableData(TABLE* ex);
// TABLE *a: TABLE 指针，n:Block 的序号，
// node: TWO_POINT,THREE_POINT,FOUR_POINT,表示两点、三点、四点插值
// x：插值变量，如二维插值，则x[0]存放第一个插值数，x[1]存放第二个插值数
// flag:0，内插；1，外插
double _export TableLag(TABLE* a, int n, int node, double* x, int flag);
//在仿真停止时调用该函数释放数据表内存
int _export FreeTableBuffer(TABLE* a);
double _export TableLag2(TABLE* a, int node, double* x, int flag);
int _export ReadTableData2(TABLE* ex, char* filename);
/////////////////////////////////////////////////////////////////////////////////////
typedef int (*VPMDLL)(USERINFO* info);
typedef int (*USERDLL)(DLLINFO*);

typedef double (*SIMUMETHOD)(int, double, double*, double*, double,
                             int (*Fct)(double, double, double*, double*));

inline int _export SendUserMessage(double t, UINT msg, LPCSTR text, double data){
    return 0;
}

//获得当前工作路径，返回值为char数组，最大长度255
inline char _export* GetWorkPath(){
    unsigned size = 255;
    char path[255] = {0};
    // Windows
#if _WIN32
    // GetModuleFileName()函数在头文件#include <windows.h>下
    GetModuleFileNameA(nullptr, path, size);
    // Linux
#else
    // readlink()函数在头文件<unistd.h>下
    int n = readlink("/proc/self/exe", path, size);
#endif
    std::string str_path = path;
    if (str_path.find_last_of("\\") != std::string::npos) {
        str_path = str_path.substr(0, str_path.find_last_of("\\")) + "\\Data";
    } else if (str_path.find_last_of("/") != std::string::npos) {
        str_path = str_path.substr(0, str_path.find_last_of("/")) + "/Data";
    }

    char* dataPath = new char[size];
    if (!dataPath) {
        // std::cout << "malloc failed" << std::endl;
        return {};
    }
    memset(dataPath, 0, size);
    memcpy(dataPath, str_path.c_str(), str_path.length());
    return dataPath;
}

inline int AddParam(char* name, int type, int dim, void *data) {
  return 0;
}

inline int AddOption(char* name, char* strOption) {
  return 0;
}

inline void RemoveParam() {
}


//仿真过程中平台向用户透明的设置，用户通过api函数可以得到这些设置
SIMUSTRUCT _export* GetSimuStructPtr();
void _export ErrAdd(LPCSTR err, int type = 0, int bReset = 0);

#endif  //end for _USERDEF_