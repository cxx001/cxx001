#pragma once

#include <type_traits>

#ifdef _WIN32
#ifdef ALG_DLL
#define ALGORITHM_EXPORT extern "C" __declspec(dllexport)
#else
#define ALGORITHM_EXPORT extern "C" __declspec(dllimport)
#endif
#else
#define ALGORITHM_EXPORT
#endif

///GSL错误处理
ALGORITHM_EXPORT void SetGSLErrorHandle();
///GSL错误信息
ALGORITHM_EXPORT const char *StrErrorNo(const int eno);
/// 初始化，type为插值类型，返回值<0失败
ALGORITHM_EXPORT int Interpolation_init(void **vpack, const double *x, const double *y, int size, int type);
/// 2d插值初始化，type为插值类型，返回值<0失败
ALGORITHM_EXPORT int Interpolation2d_init(void **vpack, const double *x, const double *y, const double *z, int xsize, int ysize, int type);
/// 反向查找初始化接口
ALGORITHM_EXPORT int Interpolation_inverse_init(void **vpack, const double *x, const double *y, int size, int type);
/// 插值计算，返回值<0错误
ALGORITHM_EXPORT int Interpolation_run(void *vpack, double x, double *y, bool extType);
ALGORITHM_EXPORT int Interpolation2d_run(void *vpack, double x, double y, double *z, bool extType);
/// 一阶导
ALGORITHM_EXPORT int Interpolation_deriv(void *vpack, double x, double *y, bool extType = true);
/// 二阶导
ALGORITHM_EXPORT int Interpolation_deriv2(void *vpack, double x, double *y, bool extType = true);
/// 释放内存
ALGORITHM_EXPORT void Interpolation_free(void *vpack);
ALGORITHM_EXPORT void Interpolation2d_free(void *vpack);
/// 线性拟合,y = a + b * x
ALGORITHM_EXPORT int Fit_linear_init(const double *x, const double *y, int n, double *a, double *b);
/// 常微分方程
/// 方程组计算公式
typedef int (*pfunc)(double,const double*,double*,void*);
/// 雅可比矩阵
typedef int (*pjac)(double,const double*,double*,double*,void*);
/// 积分算法
enum ODE_ALG
{
	//显式嵌入式Runge-kutta(2,3)
	ODEIV_STEP_RK2,
	//Matlab ode4
	ODEIV_STEP_RK4,
	//显式嵌入式Runge-kutta-Fehlberg(4,5)
	ODEIV_STEP_RKF45,
	//显式嵌入式Runge-kutta Cash-Karp(4,5)
	ODEIV_STEP_RKCK,
	//显式嵌入式Runge-kutta Prince-Dormand(8,9)
	ODEIV_STEP_RK8PD,
	//隐式高斯一阶Runge-kutta，隐式欧拉法（后向欧拉法）
	ODEIV_STEP_RK1IMP,
	//隐式高斯二阶Runge-kutta，隐式中点法
	ODEIV_STEP_RK2IMP,
	//隐式高斯四阶Runge-kutta
	ODEIV_STEP_RK4IMP,
	//隐式Bulirsch-Stoer法
	ODEIV_STEP_BSIMP,
	//变系数线性多步Adams法
	ODEIV_STEP_MSADAMS,
	//变系数线性多步BDF法
	ODEIV_STEP_MSBDF,
	//Matlab ode3
	ODEIV_STEP_RK3,
	//显式四阶Runge-kutta(8)
	ODEIV_STEP_RK48,
	//Matlab ode14x
	ODEIV_STEP_ODE14X
};
/// 初始化
ALGORITHM_EXPORT int Odeiv_init(void **vpack, pfunc pfc, pjac pjc, int dim, void *param, double hstep, int algtype = 0, double epsabs = 1e-3, double epsrel = 1e-3, int extorder = 4, int newtoniter = 1);
/// 计算
ALGORITHM_EXPORT int Odeiv_run(void *vpack, double t, double hstep, double *y);
/// 释放
ALGORITHM_EXPORT void Odeiv_free(void *vpack);

// 简单的算法直接这里声明
ALGORITHM_EXPORT double Ln(double x);
ALGORITHM_EXPORT double Sqr(double x);
ALGORITHM_EXPORT double Mod(double x1, double x2);
ALGORITHM_EXPORT double Frac(double x);
ALGORITHM_EXPORT double PI();
ALGORITHM_EXPORT double TwoPI();
ALGORITHM_EXPORT double E();
ALGORITHM_EXPORT double Gain(double x, double a);
ALGORITHM_EXPORT double SineWave(double amp, double freq, double phase, double bias, double t);
template <typename T>
T Max(T a)
{
    return a;
}

template <typename T>
T Min(T a)
{
    return a;
}
#if __cplusplus >= 201103L
template<typename T, typename... Args>
typename std::common_type<T, Args...>::type Max(T a, Args... args)
{
    auto b = Max(args...);
    return a > b ? a : b;
}

template <typename T, typename... Args>
typename std::common_type<T, Args...>::type Min(T a, Args... args)
{
    auto b = Min(args...);
    return a < b ? a : b;
}
#endif // __cplusplus >= 201103L


/// DSL特殊函数
ALGORITHM_EXPORT double DSL_aflipflop(double yi, double set, double rst, double &yiS, bool &state, bool &initflg);
ALGORITHM_EXPORT double DSL_delay(double yi, double Tdelay, void *buf, double stepSize, bool &initflg);
ALGORITHM_EXPORT bool DSL_flipflop(double set, double rst, bool &state, bool &initflg);
ALGORITHM_EXPORT double DSL_gradlim_const(double yi, double min, double max, double stepsize, double &yo, bool &initflg);
ALGORITHM_EXPORT double DSL_lastvalue(double yi, double &lastv, bool &initflg);
ALGORITHM_EXPORT double DSL_lim(double yi, double min, double max);
ALGORITHM_EXPORT double DSL_limstate(double &yi, double min, double max);
ALGORITHM_EXPORT double DSL_movingavg(double yi, double Tdel, double Tlen, void *buf, double stepSize, bool &initflg);
ALGORITHM_EXPORT bool DSL_picdro(double yi, double Tpick, double Tdrop, bool &state, double &dur, double stepSize, bool &initflg);
ALGORITHM_EXPORT double DSL_select(bool flg, double x, double y);
ALGORITHM_EXPORT double DSL_selfix(bool flg, double x, double y, bool &expr, bool &initflg);
ALGORITHM_EXPORT double DSL_time(double stepSize, double steps);
ALGORITHM_EXPORT void DSL_buf_free(void *buf);