#ifndef _CODE_TEMPLATE_H_
#define _CODE_TEMPLATE_H_

#include <string>
#include <vector>
#include <complex>

using std::vector;
using std::complex;
using std::string;

#include "CtrlEngineInterface.h"
static CE_VarTable *g_ce_var_tab;
static CE_Log *g_ce_log;

#include "Algorithm.h"
#include "BlockLibCommon.h"
#include "BlockDataType.h"


class Block_Engine_Tank {
public:
  Block_Engine_Tank(const char *name, const void * pData) : block_name_(name) ,pData_(pData) ,binit_(false){
    		// TODO 分类型初始化 x0 = 0;
		// TODO 分类型初始化 fp_ =0;
		// TODO 分类型初始化 ode_ =0;

  }

  ~Block_Engine_Tank() {}

  bool init(void *var_tab_inst) {
    		INIT_I(u0);
		INIT_O(y0);
		INIT_P(p0);
		INIT_S(x0);

      
    INIT_I(p_dynamic_Input_);
    INIT_O(p_dynamic_Output_);
    INIT_C(steps);
    INIT_C(step_size);
    INIT_C(total_running_time);
    INIT_C(algtype);
    INIT_C(epsabs);
    INIT_C(epsrel);
    return initInternalVariable();
  }

  bool initInternalVariable();

  void runAlgorithm(void * g=nullptr);

  void destroyInternalVariable();

  int integral(int msg, double t, double *state, double *derivative);

private:
  	DEFINE_I(double, u0);
	DEFINE_O(double, y0);
	DEFINE_P(double, p0);

  	double x0;
	void* fp_;
	void* ode_;
 
    
   DEFINE_I(doublePtrArray, p_dynamic_Input_);
   DEFINE_O(doublePtrArray, p_dynamic_Output_);
   DEFINE_C(uint64_t, steps);
   DEFINE_C(double, step_size);
   DEFINE_C(double, total_running_time);
   DEFINE_C(int, algtype);
   DEFINE_C(double, epsabs);
   DEFINE_C(double, epsrel);
   
   const std::string block_name_;
   const void * pData_;
   bool binit_;
};

static void* Create(const char* name,const void * pData) {
  return new Block_Engine_Tank(name,pData);
}

static void Destory(void* inst) {
  if (inst != NULL) {
	((Block_Engine_Tank*)inst)->destroyInternalVariable();
    delete ((Block_Engine_Tank*)inst);
    inst = NULL;
  }
}

static bool Init(void* inst, void* var_tab) {
  return ((Block_Engine_Tank*)inst)->init(var_tab);
}

static void Run(void* inst,void * g=nullptr) {
  ((Block_Engine_Tank*)inst)->runAlgorithm(g);
}

static BL_Instance g_bl_instance = {
    Create,
    Destory,
    Init,
    Run,
};

static int Integral(void *inst, int msg, double t, double *state, double *derivative)
{
    return ((Block_Engine_Tank *)inst)->integral(msg, t, state, derivative);
}

static BL_Integral g_bl_integral = { Integral };

// 导入接口，控制引擎->模块库
BEGIN_IMPORT_INTERFACE(Engine_Tank)
IMPORT_INTERFACE(g_ce_var_tab, CE_VarTable, CE_VAR_TABLE_INTERFACE)
IMPORT_INTERFACE(g_ce_log, CE_Log, CE_LOG_INTERFACE)
END_IMPORT_INTERFACE

// 导出接口, 模块库->控制引擎
BEGIN_EXPORT_INTERFACE(Engine_Tank)
EXPORT_INTERFACE(g_bl_instance, BL_Instance, BL_INSTANCE_INTERFACE)
EXPORT_INTERFACE(g_bl_integral, BL_Integral, BL_INTEGRAL_INTERFACE)
END_EXPORT_INTERFACE
#endif // _CODE_TEMPLATE_H_
