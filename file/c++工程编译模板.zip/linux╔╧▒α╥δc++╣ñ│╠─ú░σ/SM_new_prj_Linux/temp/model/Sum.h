#ifndef _CODE_TEMPLATE_H_
#define _CODE_TEMPLATE_H_

#include <string>
#include <vector>
#include <complex>

using std::vector;
using std::complex;
using std::string;

#include "CtrlEngineInterface.h"
static CE_VarTable *g_ce_var_tab;
static CE_Log *g_ce_log;

#include "Algorithm.h"
#include "BlockLibCommon.h"
#include "BlockDataType.h"


class Block_Sum {
public:
  Block_Sum(const char *name, const void * pData) : block_name_(name) ,pData_(pData) ,binit_(false){
    
  }

  ~Block_Sum() {}

  bool init(void *var_tab_inst) {
    		INIT_I(yi1);
		INIT_I(yi2);
		INIT_O(yo1);

      
    INIT_I(p_dynamic_Input_);
    INIT_O(p_dynamic_Output_);
    INIT_C(steps);
    INIT_C(step_size);
    INIT_C(total_running_time);
    INIT_C(algtype);
    INIT_C(epsabs);
    INIT_C(epsrel);
    return initInternalVariable();
  }

  bool initInternalVariable();

  void runAlgorithm(void * g=nullptr);

  void destroyInternalVariable();

  int integral(int msg, double t, double *state, double *derivative);

private:
  	DEFINE_I(double, yi1);
	DEFINE_I(double, yi2);
	DEFINE_O(double, yo1);

   
    
   DEFINE_I(doublePtrArray, p_dynamic_Input_);
   DEFINE_O(doublePtrArray, p_dynamic_Output_);
   DEFINE_C(uint64_t, steps);
   DEFINE_C(double, step_size);
   DEFINE_C(double, total_running_time);
   DEFINE_C(int, algtype);
   DEFINE_C(double, epsabs);
   DEFINE_C(double, epsrel);
   
   const std::string block_name_;
   const void * pData_;
   bool binit_;
};

static void* Create(const char* name,const void * pData) {
  return new Block_Sum(name,pData);
}

static void Destory(void* inst) {
  if (inst != NULL) {
	((Block_Sum*)inst)->destroyInternalVariable();
    delete ((Block_Sum*)inst);
    inst = NULL;
  }
}

static bool Init(void* inst, void* var_tab) {
  return ((Block_Sum*)inst)->init(var_tab);
}

static void Run(void* inst,void * g=nullptr) {
  ((Block_Sum*)inst)->runAlgorithm(g);
}

static BL_Instance g_bl_instance = {
    Create,
    Destory,
    Init,
    Run,
};

static int Integral(void *inst, int msg, double t, double *state, double *derivative)
{
    return ((Block_Sum *)inst)->integral(msg, t, state, derivative);
}

static BL_Integral g_bl_integral = { Integral };

// 导入接口，控制引擎->模块库
BEGIN_IMPORT_INTERFACE(Sum)
IMPORT_INTERFACE(g_ce_var_tab, CE_VarTable, CE_VAR_TABLE_INTERFACE)
IMPORT_INTERFACE(g_ce_log, CE_Log, CE_LOG_INTERFACE)
END_IMPORT_INTERFACE

// 导出接口, 模块库->控制引擎
BEGIN_EXPORT_INTERFACE(Sum)
EXPORT_INTERFACE(g_bl_instance, BL_Instance, BL_INSTANCE_INTERFACE)
EXPORT_INTERFACE(g_bl_integral, BL_Integral, BL_INTEGRAL_INTERFACE)
END_EXPORT_INTERFACE
#endif // _CODE_TEMPLATE_H_
