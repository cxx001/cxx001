#include "Sum.h"

enum Function {
    KContinue = 0,
    KOutput = 1
};
/***********************************
	内部变量初始化
	状态变量：
	内部变量：
***********************************/
bool Block_Sum::initInternalVariable()
{
    return true;
}

/**********************************
	在此函数中编写自定义代码
	输入变量：yi1, yi2
	输出变量：yo1
	参数：
	示例：O(输出变量) = I(输入变量) + P(参数)
***********************************/
void Block_Sum::runAlgorithm(void * g)
{

}

/**********************************
在此函数中编写自定义积分函数
***********************************/
int Block_Sum ::integral(int msg, double t, double *state, double *derivative)
{    
    switch (msg) {
	case KContinue: 
		{

		} 
		break;
    case KOutput: 
		{
			//首先根据输入和输出计算维度
			int dimensional = I(p_dynamic_Input_).size_/O(p_dynamic_Output_).size_;
			//计算每个通道的输出
			for(int i=0;i<O(p_dynamic_Output_).size_;i++)
			{
				*O(p_dynamic_Output_).ptr_[i] = 0;
				//计算通道中每个维度的和
				for(int j=0;j< dimensional;j++)
					*O(p_dynamic_Output_).ptr_[i] += *I(p_dynamic_Input_).ptr_[i+j*O(p_dynamic_Output_).size_];
			}
		} 
		break;
    }
	return 0;
}


/**********************************
	在此函数中释放内部变量资源
	状态变量：
	内部变量：
***********************************/
void Block_Sum::destroyInternalVariable()
{

}

REG_BLOCK(Sum);