#include "Trajectory_demoFunction.h"
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#endif
#include "userdef.h"//需要放在windows.h后面，否则会编译不过

typedef int (*GetBuildFlyFunc)(int msg, void *param, double t, double s, double *x, double *u,
                               double *y, double *f);

enum Function {
    KContinue = 0,
    KOutput = 1
};

struct FlyParams
{
    double t; //时间，积分运算回调函数传出的值（积分算法内部会修改t）
    uint64_t step_size; //步长，因为func里面不能使用成员变量，所以外部传进去
    HINSTANCE hDll;
    void *handle; //Linux下动态库open句柄
    GetBuildFlyFunc build_fly_func;
    MODEL *model;
    double x[2];
    double u[2];
    double y[3];
    double f[2];
    FlyParams()
    {
        memset(u, 0, 2);
        memset(y, 0, 3);
        memset(x, 0, 2);
        memset(f, 0, 2);
		build_fly_func = nullptr;
    }
};

class BuildFly {
public:
    BuildFly() {};
    ~BuildFly() {};

    int Continue(FlyParams* fp, double* f)
    {
		if (!fp->build_fly_func){
			return -1;
		}
        return fp->build_fly_func(SM_CONTINUE, fp->model, fp->t, fp->step_size, fp->x, fp->u, fp->y, f);
    }

    int Output(FlyParams* fp, double* f)
    {
        if(!f){
            f = fp->f;
        }
		if (!fp->build_fly_func){
			return -1;
		}		
        return fp->build_fly_func(SM_OUTPUT, fp->model, fp->t, fp->step_size, fp->x, fp->u, fp->y, f);
    }
};

/***********************************
	内部变量初始化
	状态变量：x0, x1
	内部变量：fp_, ode_
***********************************/
bool Block_Trajectory_demoFunction::initInternalVariable()
{
    fp_ = new FlyParams();
    FlyParams *fp = static_cast<FlyParams*>(fp_);
    fp->x[0] = x0;
    fp->x[1] = x1;
    
    fp->model = new MODEL();

#ifdef _WIN32
    const char *func_name = "demoFunction";
    const char *lib_name = "./plugins/ComponentsBin/libTrajectory.dll";
    fp->hDll = LoadLibraryA(lib_name);
    if (!fp->hDll){
        LOG_ERROR("加载模型动态库失败********************");
        return false;
    }
    fp->build_fly_func = (GetBuildFlyFunc)GetProcAddress(fp->hDll, func_name);
#else
    const char *func_name = "demoFunction";
    std::string lib_name = "./libTrajectory.dll";
    lib_name = lib_name.substr(0, lib_name.find_last_of(".")) + ".so";
    fp->handle = dlopen(lib_name.c_str(), RTLD_NOW);
    if (!fp->handle)
    {
        LOG_ERROR("Cannot open library:%s",dlerror());
        return false;
    }

    fp->build_fly_func = (GetBuildFlyFunc)dlsym(fp->handle, func_name);
#endif

    binit_ = true;
    if (!fp->build_fly_func){
        LOG_ERROR("Cannot load symbol********************");
        return false;
    }
        
    
    fp->u[0] = I(u0);
    fp->u[1] = I(u1);
    
    int ret = fp->build_fly_func(SM_INITIALIZE, fp->model, 0, C(step_size), fp->x, fp->u, fp->y, fp->f);
    if (ret != 0) {
        LOG_ERROR("SM_INITIALIZE失败********************");
        return false;
    }
    O(y0) = fp->y[0];
    O(y1) = fp->y[1];
    O(y2) = fp->y[2];
    

    return true;
}

/**********************************
	在此函数中编写自定义代码
	输入变量：u0, u1
	输出变量：y0, y1, y2
	参数：
	示例：O(输出变量) = I(输入变量) + P(参数)
***********************************/
void Block_Trajectory_demoFunction::runAlgorithm(void * g)
{
    FlyParams *fp = static_cast<FlyParams*>(fp_);
    
    fp->u[0] = I(u0);
    fp->u[1] = I(u1);
    
	
	if (!fp->build_fly_func){
        return;
    }
    fp->build_fly_func(SM_WRITEDATA, fp->model, C(steps) * C(step_size), C(step_size), fp->x, fp->u, fp->y, fp->f);
    O(y0) = fp->y[0];
    O(y1) = fp->y[1];
    O(y2) = fp->y[2];
    
}

/**********************************
	在此函数中释放内部变量资源
	状态变量：x0, x1
	内部变量：fp_, ode_
***********************************/
void Block_Trajectory_demoFunction::destroyInternalVariable()
{
    //是否调用了初始化函数，默认为false（控制引擎会出现直接调用destroy的情况，而成员变量fp_未初始化被使用会导致崩溃）
    if(!binit_){
        return;
    }
    FlyParams *fp = static_cast<FlyParams*>(fp_);
    fp->build_fly_func(SM_STOP, fp->model, C(steps) * C(step_size), C(step_size), fp->x, fp->u, fp->y, fp->f);
#ifdef _WIN32
    if (fp->hDll){
        FreeLibrary(fp->hDll);
    }
#else
    if (fp->handle){
        dlclose(fp->handle);
    }
#endif 
    if (fp->model){
        delete fp->model;
    }

	delete fp;
}

/**********************************
	平台积分算法调用的接口
	msg：方法类型，默认从0开始，对应内部枚举。为简化外部使用及灵活度，外部直接按顺序传，由内部自己对应具体的方法
	x：积分算法计算之后的状态变量
    f：状态变量对应导数
    t：小积分步对应的时间，由积分算法内部给出
***********************************/
int Block_Trajectory_demoFunction::integral(int msg, double t, double* x, double* f)
{
    FlyParams *fp = static_cast<FlyParams *>(fp_);
    BuildFly pClass;
    fp->u[0] = I(u0);
    fp->u[1] = I(u1);
    

    fp->x[0] = x[0];
    fp->x[1] = x[1];
    

    fp->t = t;
    fp->step_size = C(step_size);

    switch (msg) {
    case KContinue: {
        pClass.Continue(fp,f);
    } break;
    case KOutput: {
        pClass.Output(fp,f);
        O(y0) = fp->y[0];
    O(y1) = fp->y[1];
    O(y2) = fp->y[2];
    
    } break;
    }
	return 0;
}

REG_BLOCK(Trajectory_demoFunction);