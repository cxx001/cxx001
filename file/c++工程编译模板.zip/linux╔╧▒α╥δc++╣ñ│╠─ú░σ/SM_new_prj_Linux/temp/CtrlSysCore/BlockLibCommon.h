#ifndef BlockLibCommon_h__
#define BlockLibCommon_h__

#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <cstring>
#include <fstream>

#include "CtrlEngineInterface.h"
#include "BlockLibInterface.h"

//extern CE_VarTable * g_ce_var_tab;
//extern CE_Log * g_ce_log;

// 转换GCC的typeid(T).name()由为CLtypeid(T).name()
#define TYPEID_NAME_GCC_2_CL(GCC_VALUE)\
  strcmp(GCC_VALUE,"d")==0 ? "double":\
  strcmp(GCC_VALUE, "i") == 0 ? "int":\
  strcmp(GCC_VALUE,"b")==0 ? "bool":\
  strcmp(GCC_VALUE,"y")==0 ? "unsigned __int64":\
  strstr(GCC_VALUE,"doubleVector") !=NULL ? "class doubleVector":\
  strstr(GCC_VALUE,"doubleComplex") !=NULL ? "class doubleComplex":\
  strstr(GCC_VALUE,"KccString") !=NULL ? "class KccString":\
  strstr(GCC_VALUE, "VoidBuffer") != NULL ? "class VoidBuffer" : \
  strstr(GCC_VALUE, "doublePtrArray") != NULL ? "struct doublePtrArray" :  "error"

// 日志相关宏
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define MAX_LOG_SIZE 1024

// g_ce_log在模块头文件中声明，之所以放这里引用是为了在block类作用域外部也可以调用日志接口。//20220224 add pData_参数（create时传进来的对象指针），用来处理警告和错误的通知
#define LOG_INFO(fmt, ...) CtrlEngineLog(0, pData_, g_ce_log, fmt, ##__VA_ARGS__)
#define LOG_DEBUG(fmt, ...) CtrlEngineLog(1, pData_, g_ce_log, fmt, ##__VA_ARGS__)
#define LOG_WARN(fmt, ...) CtrlEngineLog(-1,  pData_, g_ce_log, fmt, ##__VA_ARGS__)
#define LOG_ERROR(fmt, ...) CtrlEngineLog(-2,  pData_,g_ce_log, fmt, ##__VA_ARGS__)

inline void CtrlEngineLog(int level, const void *pData, CE_Log *ce_log, const char *fmt, ...) {
	assert(ce_log != NULL);
	assert(ce_log->log != NULL);

	char    buf[MAX_LOG_SIZE];
	va_list va;

	va_start(va, fmt);
	int len = vsprintf(buf, fmt, va);
	va_end(va);

	ce_log->log(level,pData, buf);
}

// 操作变量的相关宏
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// 变量通过以下几个宏操作，目的：
// 1.限制用户对输入和参数等不能修改的变量进行修改。
// 2.修改变量名称，不让用户知道真实名字，防止用户意外修改变量值。
// 3.目前所有变量存储的是指针(以后可能换成其它方式)，宏可以屏蔽这些细节，后续更改，用户不需要修改代码。

#define I_REAL_NAME(name) I_##name
#define O_REAL_NAME(name) O_##name
#define P_REAL_NAME(name) P_##name
#define G_REAL_NAME(name) G_##name
#define C_REAL_NAME(name) C_##name

//#define DEFINE_I(type, name) const type *I_REAL_NAME(name)
#define DEFINE_I(type, name) type *I_REAL_NAME(name)
#define DEFINE_O(type, name) type *O_REAL_NAME(name)
//#define DEFINE_P(type, name) const type *P_REAL_NAME(name)
#define DEFINE_P(type, name) type *P_REAL_NAME(name)
#define DEFINE_G(type, name) type *G_REAL_NAME(name)
#define DEFINE_C(type, name) const type *C_REAL_NAME(name)

#define I(name) (*I_REAL_NAME(name))
#define O(name) (*O_REAL_NAME(name))
#define P(name) (*P_REAL_NAME(name))
#define G(name) (*G_REAL_NAME(name))
#define C(name) (*C_REAL_NAME(name))

#define INIT_I(name) INIT_VAR(name, I_REAL_NAME(name), block_name_)
#define INIT_O(name) INIT_VAR(name, O_REAL_NAME(name), block_name_)
#define INIT_P(name) INIT_VAR(name, P_REAL_NAME(name), block_name_)
#define INIT_G(name) INIT_VAR(name, G_REAL_NAME(name), "")
#define INIT_C(name) INIT_VAR(name, C_REAL_NAME(name), "")
//新增成员变量的初始化
#define INIT_S(name) INIT_VAR(name, name, block_name_)

#define INIT_VAR(name, var, block_name)                                          \
  do {                                                                           \
    if (!GetVariableAddr(#name, block_name, &var, pData_, var_tab_inst, g_ce_var_tab)) { \
      return false;                                                              \
    }                                                                            \
  } while (0)

template <typename T>
inline bool GetVariableAddr(const std::string &name, const std::string &block_name,
  T *addr,const void * pData_, void *tab_inst, const CE_VarTable *tab) {
    std::string temp;
    if (!block_name.empty()) {
      temp = block_name + "/";
    }
    temp += name;
    const char *var_name = temp.c_str();

    if ((name == "p_dynamic_Input_" || name == "p_dynamic_Output_") && tab->get_type(tab_inst, var_name) == nullptr ) {
        return true;
    }

    if (strcmp(tab->get_type(tab_inst, var_name), TYPEID_NAME_GCC_2_CL(typeid(T).name())) != 0
      && strcmp(tab->get_type(tab_inst, var_name), typeid(T).name()) != 0) {
      LOG_WARN("Type does not match! variable:%s, %s => %s(%s)",
        var_name, tab->get_type(tab_inst, var_name), typeid(T).name(),TYPEID_NAME_GCC_2_CL(typeid(T).name()));
    }

    *addr = *(static_cast<T *>(tab->get_value(tab_inst, var_name))); 
    return true;
}

template <typename T>
inline bool GetVariableAddr(const std::string &name, const std::string &block_name,
                            T **addr,const void * pData_, void *tab_inst, const CE_VarTable *tab) {
  std::string temp;
  if (!block_name.empty()) {
    temp = block_name + "/";
  }
  temp += name;
  const char *var_name = temp.c_str();
  
    if ((name == "p_dynamic_Input_" || name == "p_dynamic_Output_") && tab->get_type(tab_inst, var_name) == nullptr) {
        return true;
    }

  if (strcmp(tab->get_type(tab_inst, var_name), TYPEID_NAME_GCC_2_CL(typeid(T).name())) != 0
    && strcmp(tab->get_type(tab_inst, var_name), typeid(T).name()) != 0) {
	LOG_WARN("Type does not match! variable:%s, %s => %s(%s)",
		var_name, tab->get_type(tab_inst, var_name), typeid(T).name(),TYPEID_NAME_GCC_2_CL(typeid(T).name()));
  }

  *addr = static_cast<T *>(tab->get_value(tab_inst, var_name));
  if (*addr == NULL) {
	  LOG_ERROR("Get variable fail! variable:%s", var_name);
	  return false;
  } else {
	  return true;
  }
}

// 模块库导出相关的宏
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined(NOT_COMPILE_LIB)
#  define BLOCK_EXPORT
#  define INLINE inline
#else
#  if defined(_WIN32)
#    define BLOCK_EXPORT __declspec(dllexport)
#  else
#    define BLOCK_EXPORT __attribute__((visibility("default")))
#  endif
#  define INLINE
#endif

#define BEGIN_IMPORT_INTERFACE(bn)                         \
  extern "C" INLINE BLOCK_EXPORT int32_t InitBlockLib_##bn( \
      GetInterfaceFunc get_engine_interface) {
#define IMPORT_INTERFACE(inst, type, name)   \
  assert(get_engine_interface != NULL);      \
  inst = (type *)get_engine_interface(name); \
  if (inst == NULL) {                        \
    return -1;                               \
  }

#define END_IMPORT_INTERFACE \
  return 0;                  \
  }

#define BEGIN_EXPORT_INTERFACE(bn) \
  extern "C" INLINE BLOCK_EXPORT void *GetBlockInterface_##bn(const char *interface_name) {
#define EXPORT_INTERFACE(inst, type, name) \
  if (strcmp(interface_name, name) == 0) { \
    return &inst;                          \
  }

#define END_EXPORT_INTERFACE \
  return NULL;               \
  }

#endif  // BlockLibCommon_h__
