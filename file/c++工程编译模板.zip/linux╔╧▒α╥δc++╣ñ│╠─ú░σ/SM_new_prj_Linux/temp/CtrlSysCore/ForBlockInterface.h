#ifndef ForBlockInterface_h__
#define ForBlockInterface_h__

#include "CtrlEngineInterface.h"

extern CE_VarTable g_ce_var_tab;
extern CE_Log g_ce_log;

void* GetEngineInterface(const char* name);

#endif // ForBlockInterface_h__
