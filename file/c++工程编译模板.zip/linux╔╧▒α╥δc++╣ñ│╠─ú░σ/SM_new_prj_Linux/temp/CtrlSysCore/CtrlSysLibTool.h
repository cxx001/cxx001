#pragma once

typedef const char *(*FnPtrGetBuiltinData)();
struct CtrlSysInit {
    CtrlSysInit(FnPtrGetBuiltinData fn);
};
#define INIT_CTRL_SYS(fn) static CtrlSysInit ctrlSysInit(fn);
#define BEGIN_INIT_CTRL_SYS                                                                        \
    "#include \"CtrlSysLibTool.h\"\n                                                               \
    const char* getBuiltinData()\n                                                                 \
    {\n                                                                                            \
        static const unsigned char bd[]={"

#define END_INIT_CTRL_SYS                                                                          \
    "};\n                                                                                          \
    return (const char*)bd;\n                                                                      \
    }\n                                                                                            \
    INIT_CTRL_SYS(getBuiltinData);\n"
