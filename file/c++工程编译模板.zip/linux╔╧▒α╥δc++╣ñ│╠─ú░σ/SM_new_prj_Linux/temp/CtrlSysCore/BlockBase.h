#pragma once

#include <sstream>
#include "server_SimuNPS/CtrlSysEngineServer/BlockDef.h"
#include "server_SimuNPS/CtrlSysEngineServer/Util.h"
#include "server_SimuNPS/CtrlSysEngineServer/VariableTable.h"

namespace Kcc {
namespace CtrlSys {
// 代码型模块和组合型模块的基类
struct BlockBase
{
    const BlockDef* const block;
    const string pid;
    const string gid;
    const string gnm;
    const string protoName;
    const string boardName;
    const string blockName;
    CompileResults CompileResults_;

    BlockBase() : block(nullptr) { }
    BlockBase(PBlockDef b, const string &parentId, const string &parentNm) : block(b), pid(parentId), gnm(parentNm)
    {
        if (!b) {
            return;
        }
        *(string *)(&protoName) = b->protoName;
        *(string *)(&blockName) = b->blockName;
        *(string *)(&gid) = pid.empty() ? b->uuid : pid + "/" + b->uuid;
        *(string *)(&gnm) = gnm.empty() ? b->blockName : gnm + "/" + blockName;
        *(string *)(&boardName) = b->boardBelong->boardName;
        collectWarningInfo();
    }

    bool isOutlier() const{
        if (!block) {
            return true;
        } else {
            auto &br = block->boardBelong->blockRelation[block->uuid];
            bool outlier = (br.connectors[0].empty() && br.connectors[1].empty());
            return outlier;
        }
    }
    bool isStartNode(bool onlyElecContainer) const{
        if (!block) {
            return false;
        } else {
            auto tp = block->getBlockType();
            /*if (tp == BlockDef::BlockCtrlCombined) {
                return false;
            }*/
            auto isElecContainer = (tp == BlockDef::BlockElectricalContainer);
            if (onlyElecContainer && !isElecContainer) {
                return false;
            }
            auto &br = block->boardBelong->blockRelation[block->uuid];
            bool noInput = (br.connectors[0].empty() || isElecContainer);
            bool flag = (noInput && !br.connectors[1].empty());
            return flag;
        }
    }
    void collectWarningInfo()
    {
        if (!block || !block->boardBelong) {
            return;
        }
        auto it = block->boardBelong->blockRelation.find(block->uuid);
        if (it == block->boardBelong->blockRelation.end()) {
            return;
        }
        auto &br = it->second;
        bool outlier = (br.connectors[0].empty() && br.connectors[1].empty());
        if (outlier) {
            CompileResult cr;
            cr.level = BlockDef::StateWarring;
            cr.msg = "模块未连接";
            CompileResults_.push_back(cr);
        } else {
            auto pc = br.getConnectedPorts();
            string pl;
            for (auto it = block->blockPorts.begin(); it != block->blockPorts.end(); it++) { 
                auto &pn = it->second.portName;
                auto cp = pc.find(pn);
                if (cp != pc.end()) {
                    pc.erase(cp);
                }
                else {
                    pl += pl.empty() ? pn : "," + pn;
                }
            }
            if (!pl.empty()) {
                CompileResult cr;
                cr.level = BlockDef::StateWarring;
                cr.msg = "存在悬空的端口:[" + pl + "]";
                CompileResults_.push_back(cr);
            }
        }
    }

    virtual ~BlockBase() { }

    virtual bool load() { return true; }

    virtual bool init(VariableTable &var_tab)
    {
        *(PBlockDef*)(&block) = nullptr;
        return true;
    }

    virtual void runOnce(void *g) {
        if (pid.empty() && protoName == "Out") {
            auto var_tab_ = (VariableTable *)g;
            auto yi = (double*)var_tab_->getValue((gid + "/yi").c_str());
            var_tab_->update<double>(gid + "/yo", *yi);
        }
    };

    virtual int integral(int msg, double t, double *state, double *derivative) { return 0; }
};

typedef shared_ptr<BlockBase> PBlockBase;

}  // namespace CtrlSys
}  // namespace Kcc

