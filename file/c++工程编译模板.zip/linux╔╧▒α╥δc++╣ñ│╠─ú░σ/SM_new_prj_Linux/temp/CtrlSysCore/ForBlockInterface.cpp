#include "ForBlockInterface.h"
#include "server_SimuNPS/CtrlSysEngineServer/VariableTable.h"
#include "BlockBase.h"
using namespace std;

USE_CTRLSYS_LOGOUT("CtrlBlock")

static const char* GetVariableType(void* vt, const char* name) {
  return ((Kcc::CtrlSys::VariableTable*)vt)->getType(name);
}

static void* GetVariableValue(void* vt, const char* name) {
  return ((Kcc::CtrlSys::VariableTable*)vt)->getValue(name);
}

// 给模块库提供的日志接口
static void CtrlBlockLog(int level, const void* pData, const char* log) {
  //20220224 add 新增模块警告和错误的日志通知
  Kcc::CtrlSys::CompileResult cRslt;
  if (level == Kcc::LOG_WARNING) {
    cRslt.level = Kcc::CtrlSys::BlockDef::StateWarring;
    cRslt.msg   = log;
    ((Kcc::CtrlSys::BlockBase*)pData)->CompileResults_.push_back(cRslt);
  } else if (level == Kcc::LOG_ERROR) {
      cRslt.level = Kcc::CtrlSys::BlockDef::StateError;
    cRslt.msg   = log;
      ((Kcc::CtrlSys::BlockBase *)pData)->CompileResults_.push_back(cRslt);
  }
  auto msg = ((Kcc::CtrlSys::BlockBase *)pData)->boardName + ":" + log;
  //模块的日志也添加画板名
  LOGOUT(msg, (Kcc::LOG_LEVEL)level);
}

void* GetEngineInterface(const char* name) {
  assert(name != nullptr);
  if (strcmp(name, CE_VAR_TABLE_INTERFACE) == 0) {
    return &g_ce_var_tab;
  }

  if (strcmp(name, CE_LOG_INTERFACE) == 0) {
    return &g_ce_log;
  }

  return nullptr;
}

CE_VarTable g_ce_var_tab = {
    GetVariableType,
    GetVariableValue,
};

CE_Log g_ce_log = {
    CtrlBlockLog,
};


#ifdef _EXPORT_CTRL_SYS_
#include "BlockLibInterface.h"
static map<string, BL_All_Interface> *libBLInterfaces = nullptr; //以防控制引擎核心导出为dll
const BL_All_Interface *getBLInterface(const char *proto)
{
    if (libBLInterfaces == nullptr) {
        LOGOUT("请确认调用setBLInstances注册了Block原型", Kcc::LOG_ERROR);
        return nullptr;
    }
    auto it = libBLInterfaces->find(proto);
    if (it != libBLInterfaces->end()) {
        return &it->second;
    } else {
        LOGOUT("模块原型" + string(proto) + "未注册", Kcc::LOG_ERROR);
        return nullptr;
    }
}
void setBLInterfaces(void *pInstances)
{
    libBLInterfaces = (map<string, BL_All_Interface> *)pInstances;
}
BlockReg::BlockReg(const char *proto, InitBlockLibFunc fni, GetInterfaceFunc fng)
{
    auto registeredBLInterfaces = (map<string, BL_All_Interface> *)getBLInterfaces();
    if (registeredBLInterfaces->find(proto) != registeredBLInterfaces->end()) {
        LOGOUT("模块原型%" + string(proto) + "已注册", Kcc::LOG_ERROR);
    } else {
        fni(GetEngineInterface);
        auto &ai = (*registeredBLInterfaces)[proto];
        ai.runInterface = (BL_Instance *)fng(BL_INSTANCE_INTERFACE);
        ai.integralInterface = (BL_Integral *)fng(BL_INTEGRAL_INTERFACE);
    }
}
void *BlockReg::getBLInterfaces()
{
    static map<string, BL_All_Interface> registeredBLInterfaces;
    return &registeredBLInterfaces;
}
#endif // _EXPORT_CTRL_SYS_

