#include "BlockDAG.h"

#include <algorithm>
#include <assert.h>
#include <queue>
#include <stack>

#include "server_SimuNPS/CtrlSysEngineServer/Util.h"

namespace Kcc {
namespace CtrlSys {

BlockDAG::BlockDAG() { id_ = 0; }

BlockDAG::~BlockDAG() {}

BlockDAG::PNode BlockDAG::addNode(PBlockBase block)
{
    auto pb = block.get();
    if (block2node_map_.find(pb) == block2node_map_.end()) {
        PNode n(new Node);
        n->block = block;
        n->block_name = block->gid; //容器型模块的name为空，修改为取ID
        n->id = id_;
        block2node_map_[pb] = n;
        nodes_.push_back(n);
        adj_.push_back(std::list<size_t>());
        id_++;
    }
    return block2node_map_[pb];
}

BlockDAG::PNode BlockDAG::addNode(PBlockBase block, PNode &n)
{
    auto pb = block.get();
    if (block2node_map_.find(pb) == block2node_map_.end()) {
        block2node_map_[pb] = n;
        id_++;
    }
    return block2node_map_[pb];
}

void BlockDAG::addEdge(PNode x, PNode y) {
  ASSERT(valid(x) && valid(y));
  adj_[x->id].push_back(y->id);
}

void BlockDAG::removeEdge(const Edge &e) {
  ASSERT(valid(e));

  size_t x = e.x->id;
  size_t y = e.y->id;

  auto it = std::find(adj_[x].begin(), adj_[x].end(), y);
  ASSERT(it != adj_[x].end());
  if (it != adj_[x].end()) {
    adj_[x].erase(it);
  }
}

vector<BlockDAG::PNode> BlockDAG::toplogicalSort(vector<string> &start_nodes,const map<string, PBlockBase> &map,const string& curStartNode) {
  ASSERT(!adj_.empty());

  //排序前需要根据所有起始节点，删除所有环边，因为可能存在多个单独的回环系统，各自未相连，对于其他起始顶点构成的环，也需要删除
  for (size_t i = 0; i < start_nodes.size(); i++) {
    if( curStartNode == start_nodes[i])
      continue;
    // 设置起始顶点
    auto start_node = this->addNode(map.at(start_nodes[i]));

    // 找环边
    auto cycle_edges = this->findCycleEdge(start_node);

    // 删除环边
    for (auto e = cycle_edges.begin(); e != cycle_edges.end(); e++) {
      this->removeEdge(*e);
    }
  }

  // 排序结果
  std::vector<PNode> result;

  // 保存入度，入度表示有多个输入连接到该顶点
  std::vector<size_t> in_degree(adj_.size(), 0);

  // 遍历每个顶点的邻接点，更新邻接点的入度(相当于当前点有输入到邻接点，所以入度+1)
  for (size_t i = 0; i < adj_.size(); i++) {
    for (auto it = adj_[i].begin(); it != adj_[i].end(); it++) {
      in_degree[*it]++;
    }
  }

  // 遍历每个顶点，找到入度为0的顶点，将其放入队列，用于后续遍历的起始点
  // 入度为0，说明其没有任何输入，可以优先执行
  std::queue<size_t> q;
  for (size_t i = 0; i < adj_.size(); i++) {
    if (in_degree[i] == 0) {
      q.push(i);
    }
  }

  while (!q.empty()) {
    size_t v = q.front();
    q.pop();

    // q里面存储的都是入度为0的顶点，按顺序放入结果中。
    result.push_back(nodes_[v]);

    // 将子顶点的入度减去1，相当于断开了和子顶点之间的连线，然后继续遍历有没有入度为0的点，
    for (auto it = adj_[v].begin(); it != adj_[v].end(); it++) {
      if (--in_degree[*it] == 0) {
        q.push(*it);
      }
    }
  }

  // vertex_id_map_是所有连接的点集合
  // adj_.size()是总的点数，包括没有连接的点
  // 如果图中存在环，那么result.size()必然不等于vertex_id_map_.size()
  // 因为存在环路，必然会有顶点的in_degree不能变成0，所以result的个数会少于vertex_id_map_
  /// ASSERT(result.size() == vertex_id_map_.size());

  return result;

}

std::vector<BlockDAG::Edge> BlockDAG::findCycleEdge(PNode start_node) {
  ASSERT(valid(start_node));
  ASSERT(!adj_.empty());

  std::vector<Edge> result;

  // 记录已访问过的点
  std::vector<bool> visited(adj_.size(), false);

  // 记录遍历的轨迹，遍历过程中可能会有分支，可能某些点会出现在两个分支上，如果只用visited，无法判断某个已访问的点是否在一个环上，
  // 所以引入了遍历轨迹，如果某个已访问的点，没有在遍历轨迹里，说明不是环，只是在不同的分支而已。
  std::vector<bool> track(adj_.size(), false);

  findLoopEdgesRecursion(start_node->id, visited, track, result);

  return result;
}

void BlockDAG::clear() {
  adj_.clear();
  block2node_map_.clear();
  nodes_.clear();
  _singleNode.clear();
}

bool BlockDAG::valid(PNode n) const
{
    auto pb = n->block.get();
    return block2node_map_.find(pb) != block2node_map_.end()
            && (n->id < nodes_.size() + _singleNode.size());
}

bool BlockDAG::valid(Edge e) const { return valid(e.x) && valid(e.y); }

int BlockDAG::getEdgeSize() { return adj_.size();}

void BlockDAG::findLoopEdgesRecursion(size_t v, std::vector<bool> &visited,
                                      std::vector<bool>  track,
                                      std::vector<Edge> &result) {
  if (!visited[v]) {
    // 没有访问的点，说在一条新的分支上

    // 在轨迹和已访问的点中标记它
    visited[v] = true;
    track[v]   = true;

    // 继续遍历它的邻接点
    for (auto it = adj_[v].begin(); it != adj_[v].end(); ++it) {
      // src源顶点，dst是src的邻接点，src->dst表示一条边
      size_t src = v;
      size_t dst = *it;

      if (visited[dst]) {
        if (track[dst]) {
          // 如果邻接点遍历过了，且在遍历轨迹里，说明碰到了环，记录环后返回
          result.push_back(Edge(nodes_[src], nodes_[dst]));

          // 这里不返回，还要继续遍历其它邻接点
        } else {
          // 如果邻接点遍历过了，不在遍历轨迹里，继续递归下去
          findLoopEdgesRecursion(dst, visited, track, result);

          // 这里不返回，还要继续遍历其它邻接点
        }
      } else {
        // 邻接点没有遍历过，继续递归下去
        findLoopEdgesRecursion(dst, visited, track, result);

        // 这里不返回，还要继续遍历其它邻接点
      }
    }
  }

  // 该点的遍历已经结束了，在轨迹中去掉它
  track[v] = false;
}

}  // namespace CtrlSys
}  // namespace Kcc