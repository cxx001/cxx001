#include "BoardSerializer.h"
#include "jsoncpp/json/json.h"
#include "server_SimuNPS/CtrlSysEngineServer/BlockDef.h"
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace Json;
using namespace Kcc::CtrlSys;
typedef CtrlBlock *PCtrlBlock;
typedef ContainerBlock *PContainerBlock;
typedef ElecBlock *PElecBlock;
#define CheckFalseReturn(r) if (!r) return false;

struct JsonSerializer {
    template<class T>
    static Value serialize(const T &t);
    template<class T>
    static bool deserialize(const Value &v, T &t);
    template<class T>
    static Value serialize(const vector<T> &t)
    {
        Value v;
        for (size_t i = 0; i < t.size(); i++) {
            v.append(serialize(t[i]));
        }
        return v;
    }
    template<class T>
    static bool deserialize(const Value &v, vector<T> &vt)
    {
        if (!v.isArray()) {
            return false;
        }
        auto n = v.size();
        vt.resize(n);
        for (ArrayIndex i = 0; i < n; i++) {
            deserialize(v[i], vt[i]);
        }
        return true;
    }
    template<class T>
    static Value serialize(const list<T> &vt)
    {
        Value v;
        for (auto it = vt.cbegin(); it != vt.cend(); it++) {
            v.append(serialize(*it));
        }
        return v;
    }
    template<class T>
    static bool deserialize(const Value &v, list<T> &vt)
    {
        if (!v.isArray()) {
            return false;
        }
        auto n = v.size();
        for (ArrayIndex i = 0; i < n; i++) {
            T t;
            deserialize(v[i], t);
            vt.push_back(t);
        }
        return true;
    }
    template<typename V>
    static Value serialize(const map<string, V> &o)
    {
        Value v;
        for (auto it = o.cbegin(); it != o.cend(); it++) {
            v[it->first] = serialize(it->second);
        }
        return v;
    }
    template<typename V>
    static bool deserialize(const Value &v, map<string, V> &o)
    {
        if (v.isNull() || !v.isObject()) {
            return false;
        }
        for (auto it = v.begin(); it != v.end(); it++) {
            auto k = it.key().asString();
            deserialize(v[k], o[k]);
        }
        return true;
    }
};
template<>
Value JsonSerializer::serialize(const string &o)
{
    return o;
}
template<>
bool JsonSerializer::deserialize(const Value &v, string &o)
{
    o = v.asString();
    return true;
}

template<>
Value JsonSerializer::serialize(const Port &o)
{
    Value v;
    v["viewName"] = o.portName;
    v["portType"] = (int)o.portType;
    v["dataType"] = (int)o.dataType;
    return v;
}
template<>
bool JsonSerializer::deserialize(const Value &v, Port &o)
{
    if (v.isNull() || !v.isObject()) {
        return false;
    }
    o.portName = v["viewName"].asCString();
    o.portType = (Port::PortType)v["portType"].asInt();
    o.dataType = (Port::DataType)v["dataType"].asInt();
    return true;
}

template<>
Value JsonSerializer::serialize(const ParamDef &o)
{
    Value v;
    v["paramType"] = o.paramType;
    if (o.paramType == "double") {
        v["value"] = o.value.value<double>();
    } else if (o.paramType == "int") {
        v["value"] = o.value.value<int>();
    } else if (o.paramType == "string") {
        v["value"] = o.value.value<string>();
    }
    else {
        v["value"] = o.value.typeName();
    }
    return v;
}
template<>
bool JsonSerializer::deserialize(const Value &v, ParamDef &o)
{
    if (v.isNull() || !v.isObject()) {
        return false;
    }
    o.paramType = v["paramType"].asCString();
    if (o.paramType == "double") {
        o.value = v["value"].asDouble();
    } else if (o.paramType == "int") {
        o.value = v["value"].asInt();
    } else if (o.paramType == "string") {
        o.value = v["value"].asCString();
    } else {
        return false;
    }
    return true;
}

Value serializeBlock(const PBlockDef &o)
{
    Value v;
    v["protoName"] = o->protoName;
    v["blockName"] = o->blockName;
    v["uuid"] = o->uuid;
    v["blockState"] = (int)o->blockState;
    auto bbn = o->boardBelong ? o->boardBelong->boardName : "";
    v["boardBelong"] = bbn;
    auto dbn = o->boardDefinition ? o->boardDefinition->boardName : "";
    v["boardDefinition"] = dbn;
    v["blockPorts"] = JsonSerializer::serialize(o->blockPorts);
    return v;
}

bool deserializeBlock(const Value &v, PBlockDef o)
{
    if (v.isNull() || !v.isObject()) {
        return false;
    }
    o->protoName = v["protoName"].asCString();
    o->blockName = v["blockName"].asCString();
    o->uuid = v["uuid"].asCString();
    o->blockState = (BlockDef::BlockState)v["blockState"].asInt();
    auto bn = v["boardDefinition"].asString();
    if (!bn.empty()) {
        assert(o->boardBelong);
        o->boardDefinition = o->boardBelong->relatedBoards[bn];
    }
    JsonSerializer::deserialize(v["blockPorts"], o->blockPorts);
    return true;
}

template<>
Value JsonSerializer::serialize(const PCtrlBlock &o)
{
    Value v, b = serializeBlock(static_cast<const PBlockDef &>(o));
    b["blockType"] = "CtrlBlock";
    v["inputVariables"] = serialize(o->inputVariables);
    v["outputVariables"] = serialize(o->outputVariables);
    v["stateVariables"] = serialize(o->stateVariables);
    v["internalVariables"] = serialize(o->internalVariables);
    v["parameters"] = serialize(o->parameters);
    v["codeText"] = o->codeText;
    b["CtrlBlock"] = v;
    return b;
}
template<>
bool JsonSerializer::deserialize(const Value &b, PCtrlBlock &o)
{
    deserializeBlock(b, o);
    auto &v = b["CtrlBlock"];
    if (v.isObject()) {
        deserialize(v["inputVariables"], o->inputVariables);
        deserialize(v["outputVariables"], o->outputVariables);
        deserialize(v["stateVariables"], o->stateVariables);
        deserialize(v["internalVariables"], o->internalVariables);
        deserialize(v["parameters"], o->parameters);
        o->codeText = v["codeText"].asCString();
    }
    return true;
}

template<>
Value JsonSerializer::serialize(const PContainerBlock &o)
{
    Value v, b = serializeBlock(static_cast<const PBlockDef &>(o));
    b["blockType"] = "ContainerBlock";
    v["realBlock"] = o->realBlock->uuid;
    v["inputVariables"] = serialize(o->inputVariables);
    v["outputVariables"] = serialize(o->outputVariables);
    b["ContainerBlock"] = v;
    return b;
}
template<>
bool JsonSerializer::deserialize(const Value &b, PContainerBlock &o)
{
    deserializeBlock(b, o);
    auto &v = b["ContainerBlock"];
    if (v.isObject()) {
        o->realBlock = o->boardBelong->outerBlockMap[v["realBlock"].asCString()];
        deserialize(v["inputVariables"], o->inputVariables);
        deserialize(v["outputVariables"], o->outputVariables);
    }
    return true;
}

template<>
Value JsonSerializer::serialize(const PElecBlock &o)
{
    Value v = serializeBlock(static_cast<const PBlockDef &>(o));
    v["blockType"] = "ElecBlock";
    v["ElecBlock"] = o->T_e2f;
    return v;
}
template<>
bool JsonSerializer::deserialize(const Value &b, PElecBlock &o)
{
    deserializeBlock(b, o);
    o->T_e2f = b["ElecBlock"].asDouble();
    return true;
}

template<>
Value JsonSerializer::serialize(const PBlockDef &pBlock)
{
    auto tp = pBlock->getBlockType();
    Value v;
    switch (tp) {
    case BlockDef::BlockElec:
        v = serialize(dynamic_cast<PElecBlock>(pBlock));
        break;
    case BlockDef::BlockCtrlCode:
    case BlockDef::BlockCtrlCombined:
        v = serialize(dynamic_cast<PCtrlBlock>(pBlock));
        break;
    case BlockDef::BlockElectricalContainer:
        v = serialize(dynamic_cast<PContainerBlock>(pBlock));
        break;
    case BlockDef::BlockGeneric:
    default:
        v = serializeBlock(pBlock);
        v["blockType"] = "Generic";
        break;
    }
    return v;
}

bool deserializeBlockMap(const Value &v, map<string, PBlockDef> &o, PBoard pbb)
{
    if (v.isNull() || !v.isObject()) {
        return false;
    }
    for (auto it = v.begin(); it != v.end(); it++) {
        auto k = it.key().asString();
        auto &b = v[k];
        PBlockDef p;
        bool r = false;
        auto tp = b["blockType"].asString();
        if (tp == "CtrlBlock") {
            auto pcb = new CtrlBlock;
            pcb->boardBelong = pbb;
            r = JsonSerializer::deserialize(b, pcb);
            p = pcb;
        } else if (tp == "ContainerBlock") {
            auto pcb = new ContainerBlock;
            pcb->boardBelong = pbb;
            r = JsonSerializer::deserialize(b, pcb);
            p = pcb;
        } else if (tp == "ElecBlock") {
            auto pcb = new ElecBlock;
            assert(!pbb);
            r = JsonSerializer::deserialize(b, pcb);
            p = pcb;
        } else {
            auto pb = new BlockDef;
            pb->boardBelong = pbb;
            r = deserializeBlock(b, pb);
            p = pb;
        }
        CheckFalseReturn(r);
        o[p->uuid] = p;
    }
    return true;
}

template<>
Value JsonSerializer::serialize(const ConPort &o)
{
    Value v;
    v["block"] = o.block->uuid;
    v["port"] = o.port->portName;
    return v;
}

bool deserialize(const Value &v, ConPort &o, PBoard p)
{
    if (v.isNull() || !v.isObject()) {
        return false;
    }
    auto t1 = v["block"].asCString();
    auto t2 = v["port"].asCString();
    o.block = p->blockMap[v["block"].asCString()];
    o.port = &o.block->blockPorts[v["port"].asCString()];
    return true;
}

template<>
Value JsonSerializer::serialize(const Connector &o)
{
    Value v;
    v["src"] = serialize(o.conPorts[0]);
    v["dst"] = serialize(o.conPorts[1]);
    return v;
}

bool deserialize(const Value &v, Connector &o, PBoard p)
{
    if (v.isNull() || !v.isObject()) {
        return false;
    }
    deserialize(v["src"], o.conPorts[0], p);
    deserialize(v["dst"], o.conPorts[1], p);
    return true;
}

bool deserializeConnectors(const Value &v, list<Connector> &o, PBoard pbb)
{
    if (v.isNull() || !v.isArray()) {
        return false;
    }
    for (unsigned i = 0; i < v.size(); i++) {
        Connector c;
        bool r = deserialize(v[i], c, pbb);
        CheckFalseReturn(r);
        o.push_back(c);
    }
    for (auto it = o.cbegin(); it != o.cend(); it++) {
        auto &c = *it;
        for (int j = 0; j < 2; j++) {
            auto pb = c.conPorts[j].block;
            auto &pcl = pbb->blockRelation[pb->uuid].connectors[1 - j];
            pcl.push_back(&c);
        }
    }
    return true;
}

template<>
Value JsonSerializer::serialize(const PBoard &p)
{
    Value v;
    v["boardName"] = p->boardName;
    v["blockPorts"] = serialize(p->blockPorts);
    v["relatedBoards"] = serialize(p->relatedBoards);
    v["outerBlockMap"] = serialize(p->outerBlockMap);
    v["blockMap"] = serialize(p->blockMap);
    v["blockConnectors"] = serialize(p->blockConnectors);
    v["specialSort"] = serialize(p->specialSort);
    return v;
}
template<>
bool JsonSerializer::deserialize(const Value &v, PBoard &p)
{
    if (!p) {
        p = new Board;
    }
    p->boardName = v["boardName"].asCString();
    deserialize(v["blockPorts"], p->blockPorts);
    deserialize(v["relatedBoards"], p->relatedBoards);
    deserializeBlockMap(v["outerBlockMap"], p->outerBlockMap, nullptr);
    deserializeBlockMap(v["blockMap"], p->blockMap, p);
    deserializeConnectors(v["blockConnectors"], p->blockConnectors, p);
    deserialize(v["specialSort"], p->specialSort);
    return true;
}

string str2Hex(const string &s)
{
    ostringstream ret;
    for (string::size_type i = 0; i < s.length(); ++i) {
        ret << std::hex << "0x" << std::setfill('0') << std::setw(2) << (int)(unsigned char)s[i] << ",";
    }
    return ret.str();
}

class BoardHelper
{
    static PBoard loadBoard(const string &fp)
    {
        PBoard p = 0;
        ifstream f(fp,ios::in);
        if (!f) {
            return p;
        }
        std::istreambuf_iterator<char> eos;
        std::string txt(std::istreambuf_iterator<char>(f), eos);
        f.close();
        Reader rd;
        Value v;
        if (!rd.parse(txt, v)) {
            return p;
        }
        JsonSerializer::deserialize(v, p);
        return p;
    }
    static bool saveBoardFile(const string &fp, PBoard p)
    {
        ofstream f(fp, ios::out);
        if (!f) {
            return false;
        };
        auto txt = JsonSerializer::serialize(p).toStyledString();
        f.write(txt.c_str(), txt.size());
        f.close();
        return true;
    }

public:
    static bool packBoard(PBoard p, string &str)
    {
        Value v = JsonSerializer::serialize(p);
        auto bd = v.toStyledString();
        str = str2Hex(bd);
        return true;
    }
    static bool unpackBoard(const string &str, PBoard p)
    {
        Reader rd;
        Value v;
        if (!rd.parse(str, v)) {
            return false;
        }
        if (v.isObject()) {
            return JsonSerializer::deserialize(v, p);
        }
        return false;
    }
    static void test(const std::string &dir, const std::vector<std::string> &bl)
    {
        vector<PBoard> boards;
        int cnt = bl.size();
        for (int i = 0; i < cnt; i++) {
            boards.push_back(loadBoard(dir + "/" + bl[i].c_str() + ".npsdb"));
        }
        saveBoardFile(dir + "/" + bl[cnt - 1].c_str() + ".npsdb.ymy", boards[cnt - 1]);
        string str;
        auto r1 = packBoard(boards[cnt - 1], str);
        PBoard pb=0;
        auto r2 = unpackBoard(str, pb);
        for (size_t i = 0; i < boards.size(); i++) {
            delete boards[i];
        }
        int n = 0;
    }
};

bool packBoard(PBoard p, string &str)
{
    return BoardHelper::packBoard(p, str);
}
bool unpackBoard(const string &str, PBoard p)
{
    if (!p) {
        return false;
    }
    return BoardHelper::unpackBoard(str, p);
}

void test(const string &dir, const vector<string> &boards)
{
    BoardHelper::test(dir, boards);
}