#pragma once

#include "BlockBase.h"
#include "BlockLibInterface.h"
#include "server_SimuNPS/CtrlSysEngineServer/VariableTable.h"

namespace Kcc {
namespace CtrlSys {

/**
 * @brief 代码型模块，其内部只是封装了模块动态库的接口
 * 
 */
class CodeBlock : public BlockBase
{
public:
    CodeBlock() : block_inst_(nullptr), block_inst_interface_(nullptr), integral_interface_(nullptr)
    {
    }
    CodeBlock(PBlockDef b, const string &pid, const string &pnm)
        : BlockBase(b, pid, pnm),
          block_inst_(nullptr),
          block_inst_interface_(nullptr),
          integral_interface_(nullptr)
    {
    }

    ~CodeBlock(void)
    {
        // 这里要注意，必须要保证lib的生命周期比CodeBlock长，否则调用destory时会崩溃
        // 目前lib是通过BlockLibManager进行管理的，BlockLibManager是一个单例，可以保证其
        // 生命周期比CodeBlock长。

        // ASSERT(block_inst_ != nullptr);
        // ASSERT(block_inst_interface_ != nullptr);
        if (block_inst_interface_ && block_inst_) {
            block_inst_interface_->destory(block_inst_);
            block_inst_ = nullptr;
            block_inst_interface_ = nullptr;
        }
    }

    bool load();

    bool init(VariableTable &var_tab) override
    {
        ASSERT(block_inst_ != nullptr);
        ASSERT(block_inst_interface_ != nullptr);
        return block_inst_interface_->init(block_inst_, &var_tab);
    }

    void runOnce(void *g) override
    {
        ASSERT(block_inst_ != nullptr);
        ASSERT(block_inst_interface_ != nullptr);
        block_inst_interface_->run(block_inst_, g);
    }

    int integral(int msg, double t, double *state, double *derivative) override
    {
        if (integral_interface_ != nullptr && integral_interface_->integral != nullptr) {
            ASSERT(block_inst_ != nullptr);
            integral_interface_->integral(block_inst_, msg, t, state, derivative);
        }
        return 0;
    }

private:
    void *block_inst_;
    BL_Instance *block_inst_interface_;
    BL_Integral *integral_interface_;
};

}  // namespace CtrlSys
}  // namespace Kcc
