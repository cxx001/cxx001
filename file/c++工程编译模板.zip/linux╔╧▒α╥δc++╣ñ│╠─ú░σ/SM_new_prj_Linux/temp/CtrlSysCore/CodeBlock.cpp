#include "CodeBlock.h"

#ifdef _EXPORT_CTRL_SYS_
bool Kcc::CtrlSys::CodeBlock::load()
{
    auto ai = getBLInterface(protoName.c_str());
    if (!ai) {
        return false;
    }
    block_inst_interface_ = ai->runInterface;
    if (!block_inst_interface_) {
        return false;
    }
    integral_interface_ = ai->integralInterface;
    block_inst_ = block_inst_interface_->create(gid.c_str(), this);
    if (block_inst_ == nullptr) {
        return false;
    }
    return true;
}
#else
#include "BlockLibManager.h"
bool Kcc::CtrlSys::CodeBlock::load()
{
    auto lib = BlockLibManager::getInst().getBlockLib(QString::fromStdString(protoName));
    if (!lib) {
        return false;
    }
    integral_interface_ = (BL_Integral *)lib->getBlockInterface(BL_INTEGRAL_INTERFACE);
    block_inst_interface_ = (BL_Instance *)lib->getBlockInterface(BL_INSTANCE_INTERFACE);
    if (block_inst_interface_ == nullptr) {
        return false;
    }
    block_inst_ = block_inst_interface_->create(gid.c_str(), this);
    if (block_inst_ == nullptr) {
        return false;
    }
    return true;
}
#endif // _EXPORT_CTRL_SYS_