#ifndef Any_h__
#define Any_h__

#include <assert.h>
#include <stdint.h>
#include <typeinfo>

// c++版本不支持any，先自己实现一个，以后最好用系统库的。
class Any
{
public:
    Any() : content_(nullptr) { }
    template<typename ValueType>
    Any(const ValueType &value) : content_(new Holder<ValueType>(value))
    {
    }
    Any(const Any &other) : content_(other.content_ ? other.content_->clone() : nullptr) { }
    Any(void *addr, const Any &i) : content_(i.content_ ? i.content_->clone(addr) : nullptr) { }
    ~Any()
    {
        if (content_ != nullptr) {
            delete content_;
            content_ = nullptr;
        }
    }
    Any &operator=(const Any &other)
    {
        if (&other == this) {
            return *this;
        }
        if (content_ != nullptr) {
            if (type() == other.type()) {
                content_->copyValueFrom(other.content_);
                return *this;
            } else {
                if (!content_->ownMemory()) {
                    // Any持有外部内存时，不允许更改类型
                    return *this;
                }
                delete content_;
            }
        }
        content_ = other.content_->clone();
        return *this;
    }
    const std::type_info &type() const { return content_ ? content_->type() : typeid(void); }
    const char *typeName() const { return type().name(); }
    void *dataAddr() { return content_ ? content_->dataAddr() : nullptr; }
    const void *dataAddr() const { return content_ ? content_->dataAddr() : nullptr; }
    size_t getMemSize() const { return content_ ? content_->getMemSize() : 0; }
    bool copyValueFrom(const Any &o) { return content_ ? content_->copyValueFrom(o.content_) : false; }

    template<typename T>
    T &value()
    {
        assert(type() == typeid(T));
        assert(getMemSize() == sizeof(T));
        return *static_cast<T *>(content_->dataAddr());
    }
    template<typename T>
    const T &value() const
    {
        assert(type() == typeid(T));
        assert(getMemSize() == sizeof(T));
        return *static_cast<const T *>(content_->dataAddr());
    }
    template<typename T>
    bool setValue(const T &v)
    {
        if (content_) {
            if (content_->type() == typeid(T)) {
                T *addr = (T *)content_->dataAddr();
                *addr = v;
                return true;
            } else {
                if (!content_->ownMemory()) {
                    // Any持有外部内存时，不允许更改类型
                    return false;
                }
                delete content_;
            }
        }
        content_ = new Holder<T>(v);
        return true;
    }

private:
    // 这里用到类型擦除的技巧
    // 要存放任意类型，需要用到模板，但是Any不能直接用模板，否则就不能存放任意类型了。
    // 所以需要定义一个Holder的模板类，Any持有这个Holder类的基类指针(PlaceHolder)。
    struct PlaceHolder {
        virtual ~PlaceHolder() {};
        virtual const std::type_info &type() const = 0;
        virtual size_t getMemSize() const = 0;
        virtual PlaceHolder *clone(void *p = nullptr) const = 0;
        virtual bool copyValueFrom(const PlaceHolder *o) const = 0;
        bool ownMemory() { return *(bool *)((char *)this + 2 * sizeof(void *)); }
        void *dataAddr() { return *(void **)((char *)this + sizeof(void *)); }
        const void *dataAddr() const { return *(void *const *)((char *)this + +sizeof(void *)); }
    };

    template<typename ValueType>
    class Holder : public PlaceHolder
    {
        ValueType *addr;
        const bool ownMemory;

    public:
        Holder(const ValueType &value) : addr(new ValueType(value)), ownMemory(true) { }
        Holder(ValueType *p) : addr(p), ownMemory(false) { }
        virtual ~Holder()
        {
            if (addr) {
                if (ownMemory) {
                    delete addr;
                } else {
                    addr->~ValueType();
                }
                addr = nullptr;
            }
        }
        virtual const std::type_info &type() const override { return typeid(ValueType); }
        virtual size_t getMemSize() const override { return sizeof(ValueType); };
        virtual PlaceHolder *clone(void *p = nullptr) const override
        {
            if (p) {
                new (p) ValueType(*addr);
                return new Holder((ValueType *)p);
            } else {
                return new Holder(*addr);
            }
        }
        virtual bool copyValueFrom(const PlaceHolder *o) const override
        {
            if (!o) {
                return false;
            }
            auto po = dynamic_cast<const Holder<ValueType> *>(o);
            if (!po) {
                return false;
            }
            *addr = *(po->addr);
            return true;
        }
    };

private:
    PlaceHolder *content_;
};

#endif // Any_h__
