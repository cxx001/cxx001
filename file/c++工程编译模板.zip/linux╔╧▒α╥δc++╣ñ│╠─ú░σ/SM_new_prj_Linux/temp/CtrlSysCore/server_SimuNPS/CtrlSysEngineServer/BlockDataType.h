#ifndef BlockDataType_h__
#define BlockDataType_h__

#include <cstdlib>
#include <cstring>
#include <fstream>
#include <complex>

#pragma pack(push)
#pragma pack(1)

//自己实现double类型vector，只是实现了简单常用的一些函数，后续需要用到其他函数时再优化补充
class doubleVector
{
private:
  double * p_data ;
  unsigned long m_size;
  unsigned long capacity;
public:
  doubleVector(): m_size(0),capacity(0),p_data(nullptr){};

  doubleVector(const doubleVector& vec){
    m_size = vec.m_size;
    capacity = vec.capacity;
    p_data = new double[capacity];
    for(unsigned int i=0;i<m_size;++i){
      p_data[i] = vec.p_data[i];
    }
  }
  doubleVector& operator=(const doubleVector& vec){
    if(this == &vec) return *this;
    double* temp = new double[vec.capacity];
    for(unsigned int i=0;i<vec.m_size;++i){
      temp[i] = vec.p_data[i];
    }
    delete [] p_data;
    p_data = temp;
    m_size = vec.m_size;
    capacity = vec.capacity;
    return *this;
  }

  ~doubleVector() 
  {
    free( p_data );
    p_data = nullptr;
    m_size =0;
    capacity = 0;
  }

  double & operator [](int index) { return p_data[index]; }
  inline double * front() { return &p_data[0]; }
  inline double * back() {  return &p_data[m_size-1];  }
  inline double * begin() { return &p_data[0];  }
  inline double * end()  {   return &p_data[m_size]; }
  inline double * data() { return &p_data[0]; }
  inline bool empty() { return m_size == 0; }
  inline unsigned long size() { return m_size;  }

  inline void push_back(const double _Val)
  {
    if (m_size == capacity)
    {
      _Reserve(1);
    }

    p_data[m_size] = _Val;
    m_size++;
  }

  //一个元素插入到pss指示位置之前，返回x的新位置
  double * insert1(double * position, double x)
  {
    int i=0;
    int n= position - begin();

    if (  position == end())
    {
      push_back(x);
    }
    else
    {
      if (m_size == capacity)
      {
        _Reserve(1);
      }

      //数据从插入位置整体后移
      for (i=m_size-1; i >= n; i--)
      {
        p_data[i+1] = p_data[i];
      }
      p_data[i+1] = x;
      m_size++;
    }
    return begin() + n;
  }

  inline void insert(double * position, double * first, double *last)
  {
    double * pos = position;
    for ( ; first != last; ++first)
    {
      pos = insert1(pos, *first);
      ++pos;
    }
  }

  inline double * erase(double * _First, double * _Last)
  {
    double * _Ptr=nullptr;
    if( _First == _Last)
    {
      if ( _Last < _First || _First< p_data || end()<(_Last))
      {
        exit(-1);
      }
      for (_Ptr=_First; _Ptr < _Last ;_Ptr++)
      {
        if(_Ptr + (_Last -_First) < end())
          *_Ptr=*(_Ptr+(_Last-_First));
        else
          break;
      }
      m_size -= (_Last-_First);
    }
    return (_First);
  }

  inline void clear()
  {
    erase(begin(),end());
  }

  void resize( unsigned int _Newsize)
  {
    if (_Newsize < m_size)
    {
      erase(begin() + _Newsize, end());
    }
    else if (_Newsize>m_size)
    {
      _Reserve(_Newsize-m_size);
      memset(p_data + m_size, 0x0, _Newsize - m_size);
      m_size = _Newsize;
    }
  }
private:
  unsigned int _Grow_to(unsigned int _Count)
  {
    unsigned int _Capacity = capacity;
    _Capacity = _Capacity + _Capacity / 2;
    if (_Capacity < _Count)
    {
      _Capacity = _Count;
    }
    return (_Capacity);
  }

  void reserve(unsigned int _Count)
  {
    double * _Ptr=nullptr;
    if (capacity < _Count)
    {
      _Ptr = (double*) malloc( sizeof(double) * _Count);
    }

    if (_Ptr != nullptr  )
    {
      if (p_data != nullptr)
      {
        memcpy(_Ptr, p_data, sizeof(double)* m_size);
        free( p_data );
      }

      p_data = _Ptr;
      capacity = _Count;
    }
  }

  void _Reserve(unsigned int _Count)
  {
    unsigned int _Size = m_size;
    if ( ( _Size += _Count) > capacity)
    {
      reserve(_Grow_to(_Size));
    }
  }
};

///自己实现string类，只是实现了简单常用的一些成员函数，后续需要用到再补充
class KccString
{
private:
  char * p_data ;
  unsigned long m_size;
  unsigned long capacity;
public:
  KccString(): m_size(0),capacity(0),p_data(nullptr){};

  KccString(const char* str) {
    p_data = new char[strlen(str) + 1];
    strcpy(p_data, str);
    m_size = strlen(p_data);
  }

  KccString(const KccString& str){
    p_data = new char[strlen(str.p_data) + 1];
    strcpy(p_data, str.p_data);
    m_size = strlen(p_data);
  }

  ~KccString() 
  {
    free( p_data );
    p_data = nullptr;
    m_size =0;
    capacity = 0;
  }

  KccString operator+(KccString &str)
  {
    int newsize = this->m_size + str.m_size + 1;
    char *temp = new char[newsize];
    memset(temp, 0, newsize);
    strcat(temp, this->p_data);
    strcat(temp, str.p_data);
    KccString newstring(temp);
    delete[] temp;
    return newstring;
  }

  KccString& operator+(const char* str)
  {
    int newsize = this->m_size + strlen(str) + 1;
    char *temp = new char[newsize];
    memset(temp, 0, newsize);
    strcat(temp, this->p_data);
    strcat(temp, str);
    static KccString newstring(temp);
    if (temp != nullptr)
    {
      delete[] temp;
      temp = nullptr;
    }
    delete[] temp;
    return newstring;

  }
  bool operator==(KccString &str)
  {
    if (strcmp(this->p_data, str.p_data) == 0 && this->m_size == str.m_size)
    {
      return true;
    }
    return false;
  }

  bool operator==(const char* str)
  {
    if (strcmp(this->p_data, str) == 0 && this->m_size == strlen(str))
    {
      return true;
    }
    return false;
  }
  char& operator[](int index)  {  return this->p_data[index]; }
  KccString& operator=(const char* str)
  {
    if (this->p_data != nullptr)
    {
      delete[] this->p_data;
      this->p_data = nullptr;
    }
    this->p_data = new char[strlen(str) + 1];
    strcpy(p_data, str);
    return *this;
  }
  KccString& operator=( const KccString& str)
  {
    if (this->p_data != nullptr)
    {
      delete[] this->p_data;
      this->p_data = nullptr;
    }
    this->p_data = new char[strlen(str.p_data) + 1];
    strcpy(p_data, str.p_data);
    return *this;
  }

  inline const char * c_str() const { return p_data  ;} 

};

//自己实现double类型的complex
class doubleComplex
{
private:
  double m_real;
  double m_imag;

public:
  doubleComplex() {}
  doubleComplex(double r,double i):m_real(r),m_imag(i) {}
  ~doubleComplex() {}

  doubleComplex & operator=(const std::complex<double> v)
  {
    m_real = v.real();
    m_imag = v.imag();
    return *this;
  }
  doubleComplex & operator=(const doubleComplex v)
  {
    m_real = v.m_real;
    m_imag = v.m_imag;
    return *this;
  }

  double real()  {    return m_real;  }
  double imag()  {    return m_imag;  }
  void real(const double val)  {    m_real = val;  }
  void imag(const double val) { m_imag = val; }
};


// 复杂的算法库单独实现
class Buffer
{
private:
  int m_length;//定义缓存区长度
  double* m_point;//定义缓存区动态数组的指针变量
  int m_counter;//定义一个计数器，用于寻找之前存放数据的下标

public:
  // 初始化缓存器
  Buffer(int n)
  {
    m_length = n;
    m_point = new double[m_length];
    m_counter = 0;
    memset(m_point, 0, sizeof(double) * (m_length));//将指针动态数组统一初始化为0
  }

  ~Buffer()
  {
    delete []m_point;
  }

  void  push(double yo)//按顺序往头部放入数据
  {
    m_point[m_counter % m_length] = yo;
    m_counter++;
  }

  double  get(int n)//根据下标获取数组的数据
  {
    return m_point[n];
  }

  double get_backward(int n)//往前寻找数据
  {
    return m_point[(m_counter - n-1) % m_length];
  }

  int  counter()//返回当前动态数组已存的数据个数
  {
    return m_counter;
  }

  //返回缓存区长度
  int  show_length()
  {
    return m_length;
  }

  double  sum()//返回缓存区内的数据求和
  {
    double sum=0;
    for (int i = 0; i < m_length; i++)
    {
      sum +=m_point[i];
    }
    return sum;
  }
};

/// 固定长度的队列
class FixLenQueue
{
private:
  int count, fixLen;
  int beg, end;
  double *buf;

public:
  FixLenQueue() : count(0),fixLen(0),beg(0),end(0),buf(nullptr) {}
  ~FixLenQueue() { }
  //申请内存
  void alloc(int len) 
  {
    count = 0;
    fixLen = 0;
    beg = 0;
    end = 0;
    buf = nullptr;
    if(len < 1) return;
    buf = new double[len];
    fixLen = len;
  }
  //释放内存
  void free() 
  { 
    delete[] buf;
    buf = nullptr;
  }
  //弹出
  void pop()
  {
    if(count == 0) return;
    --count;
    beg = (beg + 1) % fixLen;
  }
  //压入
  void push(double v)
  {
    if(count  == fixLen) pop();
    ++count;
    buf[end] = v;
    end = (end + 1) % fixLen;
  }
  //复制
  int toArr(double *arr)
  {
    for(int i = beg, j = 0; j < count; i = (i + 1) % fixLen)
    {
      arr[j++] = buf[i];
    }
    return count;
  }
  //大小
  int size() { return count; }
  //容量
  int capacity() { return fixLen; }
  //
  double & operator[](const int index)
  {
    return buf[(beg + index) % fixLen];
  }
};

//void内存块操作
class VoidBuffer
{
public:
  void * p_data ;
  unsigned long m_size;
public:
  VoidBuffer(): m_size(0),p_data(nullptr){};

//由于目前控制引擎为cl编译器，模块是g++编译器，控制引擎和模块之间如果存在跨dll的内存释放操作会导致崩溃
//所修改为控制引擎这边不进行内存分配与释放，内存的分配与释放全部由模块dll自己来处理
//析构函数也不进行内存释放，如果控制引擎去释放模块申请的内存会导致崩溃
//备注：如果控制引擎和模块编译器是相同的则不会存在该问题，相同编译器可以跨dll进行内存释放操作
  /*VoidBuffer(int size): m_size(size),p_data(nullptr)
  {
    p_data = malloc( m_size);
    if(p_data)
    {
      memset(p_data, 0, m_size);
    }
  }*/
  
  //为防止控制引擎和模块之间如果存在跨dll的内存释放
  //拷贝构造修改为只生成对象，不分配内存
  VoidBuffer(const VoidBuffer& v){
    p_data = nullptr;
    m_size = 0;
    /*m_size = v.m_size;
    p_data = malloc( v.m_size);

    if(p_data)
    {
      memcpy(p_data, v.p_data, v.m_size);
    }*/

  }
  VoidBuffer& operator=(const VoidBuffer& v){
    if(this == &v) return *this;
    void* temp = malloc( v.m_size);
    if(temp)
    {
      memcpy(temp, v.p_data, v.m_size);
    }
    free( p_data );
    p_data = temp;
    m_size = v.m_size;
    return *this;
  }

  ~VoidBuffer() 
  {
    //为防止控制引擎和模块之间如果存在跨dll的内存释放,析构函数也不进行内存释放
    /*
    free( p_data );
    p_data = nullptr;
    m_size =0;*/
  }

  inline const void * get_point() const { return p_data  ;} 
};

struct doublePtrArray {
    double **ptr_;
    int size_;
    doublePtrArray(int size) : size_(size)
    {
        if (size > 0)
            ptr_ = new double *[size];
        else
            ptr_ = nullptr;
    }
    doublePtrArray(const doublePtrArray &other) : size_(other.size_)
    {
        if (other.size_ > 0)
            ptr_ = new double *[other.size_];
        else
            ptr_ = nullptr;
    }
    ~doublePtrArray()
    {
        if (ptr_) {
            delete[] ptr_;
            ptr_ = nullptr;
        }
    }
};

#pragma pack(pop)

#endif // BlockDataType_h__
