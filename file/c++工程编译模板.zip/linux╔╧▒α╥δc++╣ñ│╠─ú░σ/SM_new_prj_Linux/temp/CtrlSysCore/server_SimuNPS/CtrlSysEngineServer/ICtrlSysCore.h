#pragma once

#include "BlockDef.h"
#include "VariableTable.h"

namespace Kcc {
namespace CtrlSys {
// 步长
static const char* kParamStepSize = "step_size";
// 总运行时间
static const char* kParamTotalRunningTime = "total_running_time";
//磁链方程求解时刻
static const char *kParamT_e2f = "T_e2f";
// 算法类型
static const char *kParamAlgorithm = "algtype";
// 绝对误差
static const char *kParamAbsEps = "epsabs";
// 相对误差
static const char *kParamRelEps = "epsrel";

  // 输出数据结构
struct Output {
    string board_name;
    string block_name;
    string port_name;
    string param_type;
    const double *value;
};

// 控制系统接口
class ICtrlSysCore {
public:

  virtual ~ICtrlSysCore() { }

  // 00 加载画板数据结构，创建控制内部各个模块对象
  virtual bool load(PBoard board) = 0;

  // 01 获取变量表，load之后就创建好变量表了
  virtual const VariableTable& getVariableTable() const = 0;

  // 01 获取输出数据，load之后就可以知道有那些输出数据了
  virtual const std::vector<Output>& getOutput() const = 0;

  // 02 设置引擎参数，init前调用, 设置 kParamStepSize
  virtual void setParam(const string& name, const Any& v) = 0;

  // 03 初始化引擎参数
  virtual bool init() = 0;

  // 04 只运行一次，即运行一个步长
  virtual void runOnce(bool is_print_result = false,void * g = nullptr) = 0;

  // 05 释放资源，每次仿真结束后要释放，否则会导致模块dll一直被占用
  virtual void release() = 0;

  //////////////////////////////////////////////////////////////////////////
  // 以下函数暂时未实现，预留的接口

  // 连续运行，非阻塞，会另外开线程运行
  virtual void start() = 0;

  // 停止运行，会关掉仿真线程
  virtual void stop() = 0;
};
}  // namespace CtrlSys
}  // namespace Kcc
