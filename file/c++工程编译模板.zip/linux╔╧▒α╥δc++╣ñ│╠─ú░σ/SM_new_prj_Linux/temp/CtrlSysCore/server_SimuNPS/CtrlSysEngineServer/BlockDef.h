#pragma once

#include <map>
#include <set>
#include <list>
#include <vector>
#include <string>
#include "Any.h"

namespace Kcc {
namespace CtrlSys {
struct BlockDef;
struct CtrlBlock;
struct Board;
typedef BlockDef *PBlockDef;
typedef Board *PBoard;
using namespace std;

struct Port {
    enum PortType : unsigned char {
        electrical,    //电气，修改为透明背景图片
        ctrlin,        //控制系统输入
        ctrlout,       //控制系统输出
        busbar,        //母线端口，依据连接线动态创建
        electrical_AC, //电气,交流
        electrical_DC  //电气,直流
    };
    enum DataType : unsigned char {
        real,  // 目前仅支持real
        logic, // bool
        vector // 数组
    };
    string portName;  //端口名称
    PortType portType; //端口类型
    DataType dataType; //数据类型
};
typedef Port *PPort;

struct ConPort {
    PBlockDef block;
    PPort port;
    ConPort() : block(0), port(0) { }
};
typedef ConPort *PConPort;

//模块连接线
struct Connector {
    ConPort conPorts[2];
};
typedef Connector *PConnector;
typedef const Connector *CPConnector;

struct BlockRelation {
    list<CPConnector> connectors[2];
    set<string> getConnectedPorts() const
    {
        set<string> ports;
		for (int i = 0; i < 2; i++) {
			for (auto it = connectors[i].cbegin(); it != connectors[i].cend(); it++) {
				ports.insert((*it)->conPorts[1 - i].port->portName);
			}
		}
		return ports;
    }
};

struct BlockDef {
    enum BlockType : unsigned char {
        BlockGeneric = 0, // 标准Block类型，暂时没有此类模块，以后可能会用，预留
        BlockElec,        // 电气模块
        BlockCtrlCode,    // 控制代码型
        BlockCtrlCombined,       // 控制组合型
        BlockSlot,               // 插槽型模块
        BlockComposite,          // 复合模块
        BlockElectricalContainer // 电气接口模块
    };
    enum BlockState : unsigned char {
        StateNormal,  //正常
        StateWarring, //警告
        StateError,   //错误
        StateDisable, //禁用
        StateHangup,  //挂起
    };
    string protoName; //这个模块对应的唯一原型名称（英文），例如：Resistor
    string blockName; //模块名，初始与uuid一致，用户可修改。
    string uuid; // protoName_递增id，不可修改。控制系统不使用，作用是报错时供界面找到出错模块。
    BlockState blockState;  //当前状态
    PBoard boardBelong;     //该模块所属画板
    PBoard boardDefinition; //指针非空表示模块由画板定义
    map<string, Port> blockPorts;
    BlockDef() : blockState(StateNormal), boardBelong(0), boardDefinition(0) { }
    virtual ~BlockDef() { }
    virtual BlockType getBlockType() const { return BlockGeneric; };
    static bool isVirtualBlock(const string &proto)
    {
        static string vbs[] = { "In", "Out", "BusCreator", "BusSelector" };
        for (int i = 0; i < 4; i++) {
            if (proto == vbs[i]) {
                return true;
            }
        }
        return false;
    }
};
typedef map<string, PBlockDef> BlockDefMap;

struct Board {
    string boardName;                 // 名称
    list<Connector> blockConnectors;  // 画板上的连接线
    BlockDefMap blockMap;             // 画板上的所有模块，key是uuid
    map<string, Port> blockPorts;    // 控制系统自定义模块画板包含对外端口信息
    BlockDefMap outerBlockMap; // 画板相关的外部模块，如电气容器模块中的电气模块。
    map<string, PBoard> relatedBoards; //所有模块相关的画板，如组合型控制模块
    map<string, BlockRelation> blockRelation; // 模块及其连接关系
    list<string> specialSort;//画板设置的专用排序
    Board() { }
    ~Board()
    {
		for (auto it = blockMap.cbegin(); it != blockMap.cend(); it++) {
			delete it->second;
		}
        for (auto it = relatedBoards.cbegin(); it != relatedBoards.cend(); it++) {
            delete it->second;
        }
        for (auto it = outerBlockMap.cbegin(); it != outerBlockMap.cend(); it++) {
            delete it->second;
        }
    }
    list<CtrlBlock *> getCodeBlocks() { 
        list<PBoard> bds;
        for (auto it = relatedBoards.cbegin(); it != relatedBoards.cend(); it++) {
            bds.push_back(it->second);
        }
        bds.push_back(this);
        map<string, CtrlBlock *> protosMap;
        for (auto it = bds.cbegin(); it != bds.cend(); it++) {
            for (auto itb = (*it)->blockMap.cbegin(); itb != (*it)->blockMap.cend(); itb++) {
                auto &pb = itb->second;
                auto flag = pb->getBlockType() == BlockDef::BlockCtrlCode
                        && !BlockDef::isVirtualBlock(pb->protoName)
                        && protosMap.find(pb->protoName) == protosMap.end();
                if (flag) {
                    protosMap[pb->protoName] = (CtrlBlock *)(pb);
                }
            }
        }
        list<CtrlBlock*> protos;
        for (auto it = protosMap.cbegin(); it != protosMap.cend(); it++) {
            protos.push_back(it->second);
        }
        return protos;
    }

private:
    Board(const Board &o) { }
};

struct ParamDef {
    string paramName;
    string paramType;
    Any value; //模块原型中保存的数值，就是默认值
};
typedef map<string, ParamDef> ParamDefMap;

struct CtrlBlock : public BlockDef {
    ParamDefMap inputVariables;            //输入变量
    ParamDefMap outputVariables;             //输出变量
    ParamDefMap stateVariables;            //状态变量
    ParamDefMap internalVariables;           //内部变量
    ParamDefMap parameters;                //参数
    string codeText; //控制逻辑代码
    virtual BlockType getBlockType() const override
    {
        return boardDefinition ? BlockCtrlCombined : BlockCtrlCode;
    };
};

struct ElecBlock : public BlockDef {
    double T_e2f;
    virtual BlockType getBlockType() const { return BlockElec; };
};

struct ContainerBlock : public BlockDef {
    PBlockDef realBlock;
    ParamDefMap inputVariables;
    ParamDefMap outputVariables;
    virtual BlockType getBlockType() const { return BlockElectricalContainer; };
};

// 编译结果
struct CompileResult {
    // 错误等级
    BlockDef::BlockState level;
    // 错误或者警告消息
    string msg;
    // 模块名，如果是嵌套模块，会包含所在画板的画板名，用"/"隔开
    string block_id;
};
typedef std::vector<CompileResult> CompileResults;
} // namespace CtrlSys
} // namespace Kcc
