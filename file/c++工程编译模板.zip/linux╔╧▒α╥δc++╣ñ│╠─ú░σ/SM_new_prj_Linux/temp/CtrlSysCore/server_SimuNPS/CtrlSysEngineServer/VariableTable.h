#ifndef VariableTable_h__
#define VariableTable_h__

#include <map>
#include <vector>
#include <string>
#include <complex>
#include <memory>
#include "Any.h"
#include "Util.h"
#include "BlockDataType.h"
#include "MemMgr.h"


namespace Kcc {
namespace CtrlSys {
using namespace std;

class Visitor {
public:
  virtual void visit(const string &name, const Any *v) = 0;
};


typedef shared_ptr<Any> VariableAddr;

// 变量表，管理初始化参数、输入、输出参数
// 不直接把内部数据结构暴露给外面，方便以后扩展
class VariableTable
{
public:
  VariableTable() {}

  virtual ~VariableTable() { clear(); }

  MOCKABLE const char* getType(const char* name) const {
	  if (!exist(name)) {
		  return NULL;
	  }
	  return table_.at(name)->typeName();
  }

  MOCKABLE void *getValue(const char *name) {
    if (!exist(name)) {
      return NULL;
    }
    return table_[name]->dataAddr();
  }

  MOCKABLE size_t size() const { return table_.size(); }

  MOCKABLE bool exist(const string &name) const { return table_.find(name) != table_.end(); }

  MOCKABLE bool replace(const string &name, VariableAddr v)
  {
    CHECK_ERROR(exist(name), "replace: Variable not exist!");
    if (!exist(name)) {
      return false;
    }
    table_[name] = v;
    return true;
  }

  // 创建变量
  template <typename T>
  void create(const string &name, const T &value) {
    // 组合型模块多层嵌套时，父级模块会有一份变量初始值，子模块名也有一份变量初始值，由于
    // 代码采用了递归的结构，会对同一个变量初始化多次。但是模块连接又是在父级模块处理，导
    // 致关联的变量不是我们想要的结果，为了避免这种情况，如果变量已存在就不进行插入了，只
    // 修改变量初始化值，这样保证了底层关联的变量不会改变。

    if (exist(name)) {
        update(name, value);
    } else {
        auto var = VariableAddr(new Any(value));
        table_[name] = var;
    }
  }

  MOCKABLE bool create(const string &name, const string &type, const Any &initial_value)
  {
      if (exist(name)) {
          return table_.at(name)->copyValueFrom(initial_value);
      } else {
          table_[name] = VariableAddr(new Any(initial_value));
      }
      return true;
  }

  bool continuousMemVarExist(const string &name, bool output)
  {
      for (size_t i = 0; i < continuousMemVars[output].size(); i++) {
          if (name == continuousMemVars[output][i]) {
              return true;
          }
      }
      return false;
  }

  void renewVarAddr(bool output)
  {
      auto base = (char *)memMgr[output].getBaseAddr();
      for (size_t i = 0; i < continuousMemVars[output].size(); i++) {
          auto addr = (base + continuousMemOffsets[output][i]);
          auto any = (char *)table_[continuousMemVars[output][i]].get();
          auto data = (void **)(any + sizeof(char *));
          *data = addr;
      }
  }

  MOCKABLE bool createContinuousMemVar(const string &name, const string &type,
                                       const Any &initial_value, bool output)
  {
      if (continuousMemVarExist(name,output)) {
          *table_.at(name).get() = initial_value;
      } else {
          auto sz = initial_value.getMemSize();
          auto r = memMgr[output].allocMem(sz);
          if (MemMgr::allocFail == r) {
              return false;
          } else if (MemMgr::memGrow == r) {
              renewVarAddr(output);
          }
          auto offset = memMgr[output].getCurrentOffset();
          auto addr = (char *)memMgr[output].getBaseAddr() + offset;
          table_[name] = VariableAddr(new Any(addr, initial_value));
          continuousMemVars[output].push_back(name);
          continuousMemOffsets[output].push_back(offset);
      }
      return true;
  }

  const MemMgr *getMemMgrs() { return memMgr; }

  const vector<size_t> *getMemOffsets() { return continuousMemOffsets; }

  // 更新变量值
  template <typename T>
  bool update(const string &name, const T &value)
  {
      ASSERT(exist(name));
      if (exist(name)) {
          return table_[name]->setValue(value);
      } else {
          return false;
      }
  }

  MOCKABLE bool remove(const string &name)
  {
      ASSERT(exist(name));
      auto it = table_.find(name);
      if (it != table_.end()) {
          table_.erase(it);
          return true;
      } else {
          return false;
      }
  }

  MOCKABLE void accept(Visitor &visitor)
  {
      for (auto it = table_.begin(); it != table_.end(); it++) {
          visitor.visit(it->first, it->second.get());
      }
  }

  MOCKABLE VariableAddr getVariable(const string &key)
  {
      ASSERT(exist(key));
      if (!exist(key)) {
          return VariableAddr(nullptr);
      }
      return table_[key];
  }

  MOCKABLE void clear() { table_.clear(); }

private:
  // VariableType不能用QVariant，因为QVariant不能获取数据指针，在赋值的时候会
  // 引入一次拷贝操作，效率会降低
    MemMgr memMgr[2];
    map<string, VariableAddr> table_;
    vector<string> continuousMemVars[2];
    vector<size_t> continuousMemOffsets[2];
};

}  // namespace CtrlSys
}  // namespace Kcc

#endif  // VariableTable_h__
