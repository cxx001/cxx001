#ifndef Util_h__
#define Util_h__

#include <string>
#include <stdint.h>
#include <sstream>
#include <assert.h>


// 方便单元测试
#ifdef _UNITTEST_
#define MOCKABLE virtual
#else
#define MOCKABLE
#endif

#define TR(s) s

#define TOCHAR(s) s.toLocal8Bit().data()

#ifdef _DEBUG
    #define ASSERT(CONDITION) assert(CONDITION)
    #define CHECK_ERROR(CONDITION, DESCRIBE) assert(CONDITION && DESCRIBE)
    #define CHECK_FAIL(DESCRIBE) assert(false && DESCRIBE)
#else
    #define ASSERT(CONDITION)
    #define CHECK_ERROR(cond, desc)
    #define CHECK_FAIL(desc)
#endif

// 静态检查
#define STATIC_ASSERT(expr) {char _[(expr)?1:0];}

#ifndef _CTRL_SYS_CORE_
#include "CoreLib/ServerManager.h"
#define USE_CTRLSYS_LOGOUT(name)                                                                   \
    USE_LOGOUT_(name)                                                                              \
    static void LOGOUT(const std::string &msg, Kcc::LOG_LEVEL level = Kcc::LOG_NORMAL)             \
    {                                                                                              \
        LOGOUT(QString::fromStdString(msg), level);                                                \
    }
#else
namespace Kcc {
enum LOG_LEVEL {
    LOG_ERROR = -2,
    LOG_WARNING = -1,
    LOG_NORMAL = 0,
    LOG_DEBUG = 1,
    LOG_OPERATION_FAILURE = 2,
    LOG_OPERATION_WARNING = 3,
    LOG_OPERATION_SUCCESS = 4,
    LOG_SYSTEM_LEVEL = 100,
    LOG_SYSTEM_SUCCESS,
    LOG_SYSTEM_WARNING,
    LOG_SYSTEM_FAILURE,
    LOG_SYSTEM_DEBUG
};
}
#define USE_CTRLSYS_LOGOUT(name)                                                                   \
    static void LOGOUT(const std::string &msg, Kcc::LOG_LEVEL level = Kcc::LOG_NORMAL)             \
    {                                                                                              \
        static const char *LEVEL[] = { "E", "W", "N" };                                            \
        if (Kcc::LOG_DEBUG > level) {                                                              \
            printf("[%s][%s]%s\n", LEVEL[level + 2], name, msg.c_str());                           \
        }                                                                                          \
    }
#endif // !_CTRL_SYS_CORE_


// 单元测试时，不依赖CoreLib等库
#if _UNITTEST_
    #ifdef USE_LOGOUT_
        #undef USE_LOGOUT_
        #define USE_LOGOUT_(name)
    #endif
    #define LOGOUT
#endif

#define LOG(log, level) LOGOUT(string(__FILE__) + "(" + to_string(__LINE__) + "):" + log, level);
#define LOGEX(log, level)                                                                          \
    LOGOUT(string(__FILE__) + "(" + to_string(__LINE__) + "):" + board_name_ + ":" + log, level);

// 只在Debug模式下打印的日志
#ifdef _DEBUG
#define LOG_DEBUG(log) LOG(log, Kcc::LOG_DEBUG)
#else
#define LOG_DEBUG(log)
#endif

#endif // Util_h__
