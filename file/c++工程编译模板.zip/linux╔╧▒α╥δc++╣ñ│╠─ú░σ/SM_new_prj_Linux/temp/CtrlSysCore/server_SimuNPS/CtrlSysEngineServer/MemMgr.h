#pragma once
class MemMgr
{
    void *memBlock;
    size_t total;
    size_t used;
    size_t offset;
    bool growMem(size_t bytes)
    {
        auto t = total + total / 2;
        if (t < bytes) {
            t = bytes;
        }
        auto p = malloc(t);
        if (!p) {
            return false;
        }
        if (memBlock) {
            memcpy(p, memBlock, used);
            free(memBlock);
        }
        memBlock = p;
        return true;
    }

public:
    MemMgr() : total(8 * 1024), used(0), offset(0) { memBlock = malloc(total); }
    ~MemMgr()
    {
        if (memBlock) {
            free(memBlock);
        }
    }

    enum MemChange { allocFail = -1, noAlloc = 0, memGrow = 1 };
    MemChange allocMem(size_t bytes)
    {
        if (used + bytes > total) {
            if (growMem(used + bytes)) {
                offset = used;
                used += bytes;
                return memGrow;
            } else {
                return allocFail;
            }
        } else {
            offset = used;
            used += bytes;
            return noAlloc;
        }
    }
    size_t getCurrentOffset() const { return offset; }
    void *getBaseAddr() const { return memBlock; }
};