#ifndef Graph_h__
#define Graph_h__

#include <list>
#include <map>
#include <stdint.h>
#include <vector>

#include "BlockBase.h"

namespace Kcc {
namespace CtrlSys {

class BlockDAG {
public:
  struct Node {
    size_t     id;
    string    block_name;
    PBlockBase block;
  };
  typedef shared_ptr<Node> PNode;

  struct Edge {
    PNode x;
    PNode y;
    Edge(PNode _x, PNode _y) {
      x = _x;
      y = _y;
    }
  };

  // 记录游离的模块
  std::vector<PNode> _singleNode;

  BlockDAG();

  ~BlockDAG();

  // 分配一个节点
  PNode addNode(PBlockBase block);

  // 分配一个节点
  PNode addNode(PBlockBase block,PNode & n);
  // 添加边
  void addEdge(PNode x, PNode y);

  void removeEdge(const Edge &edge);

  int getEdgeSize();

  std::vector<PNode> toplogicalSort(std::vector<string> &start_nodes,
                                    const map<string, PBlockBase> &map, const string &curStartNode);

  std::vector<Edge> findCycleEdge(PNode start_node);

  void clear();
  size_t & id()  {return id_;}

private:
  bool valid(PNode n) const;

  bool valid(Edge e) const;

  // 递归查找环路
  void findLoopEdgesRecursion(size_t v, std::vector<bool> &visited,
                              std::vector<bool> track, std::vector<Edge> &result);

  // 采用邻接链表的方式进行存储
  std::vector<std::list<size_t>> adj_;

  size_t id_;

  map<BlockBase *, PNode> block2node_map_;

  std::vector<PNode> nodes_;
};

}  // namespace CtrlSys
}  // namespace Kcc

#endif  // Graph_h__
