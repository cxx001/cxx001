#pragma once

#if defined(_CTRL_SYS_CORE_)
#if defined(_WIN32)
#define LIB_EXPORT extern "C" __declspec(dllexport)
#else
#define LIB_EXPORT extern "C" __attribute__((visibility("default")))
#endif
#else
#define LIB_EXPORT extern "C"
#endif


LIB_EXPORT void *getCtrlSys();
LIB_EXPORT void releaseCtrlSys(void *p);
LIB_EXPORT void runOnce(void *p, bool is_print_result = false);
LIB_EXPORT void start(void *p);
LIB_EXPORT void *getParamsBaseAddr(void *p);
LIB_EXPORT void *getOutputBaseAddr(void *p);
LIB_EXPORT int getParamsCnt(void *p);
LIB_EXPORT int getOutputCnt(void *p);
LIB_EXPORT void **getParamAddrs(void *p);

#ifdef _SUPPORT_SET_PARAMS_
#include "Any.h"
#include <string>
LIB_EXPORT bool setParam(void *p, const std::string &block, const std::string &param, const Any &v);
#endif // _SUPPORT_SET_PARAMS_


