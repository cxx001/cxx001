#ifndef BlockLibInterface_h__
#define BlockLibInterface_h__

/* BL是Block lib的简写 */

/**
 * @brief 模块库实例接口v1.0，用于创建、销毁、初始化、运行控制模块实例
 *
 */
struct BL_Instance_1_0 {
  void* (*create)(const char*,const void *);
  void (*destory)(void* inst);
  bool (*init)(void* inst, void* var_tab);
  void (*run)(void* inst, void * g );
};

typedef struct BL_Instance_1_0 BL_Instance;
#define BL_INSTANCE_INTERFACE "BL_Instance;1.0"

struct BL_Integral_Interface {
    int (*integral)(void *inst, int msg, double t, double *state, double *derivative);
};
typedef struct BL_Integral_Interface BL_Integral;
#define BL_INTEGRAL_INTERFACE "BL_Integral_Interface;1.0"

struct BL_All_Interface {
    BL_Instance *runInterface;
    BL_Integral *integralInterface;
    BL_All_Interface() : runInterface(nullptr), integralInterface(nullptr) { }
};

typedef void *(*GetInterfaceFunc)(const char *name);
typedef int32_t (*InitBlockLibFunc)(GetInterfaceFunc);

#ifdef _EXPORT_CTRL_SYS_
    const BL_All_Interface *getBLInterface(const char *proto);
    void setBLInterfaces(void *pInstances);
    struct BlockReg {
        BlockReg(const char *proto, InitBlockLibFunc fni, GetInterfaceFunc fng);
        static void *getBLInterfaces();
    };
#define REG_BLOCK(name)                                                                            \
    static BlockReg br_##name(#name, InitBlockLib_##name, GetBlockInterface_##name);
#endif // _EXPORT_CTRL_SYS_

#endif  // BlockLibInterface_h__
