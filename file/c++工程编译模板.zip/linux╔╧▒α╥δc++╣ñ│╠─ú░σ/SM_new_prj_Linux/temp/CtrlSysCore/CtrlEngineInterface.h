/**
 * @file CtrlEngineInterface.h
 * @author wzc
 * @brief 定义控制引擎提供给模块库或者算法库的接口
 * @version 1.0
 * @date 2021-12-29
 * 
 * @copyright Copyright (c) 2021
 * 
 */
#ifndef CtrlEngineInterface_h__
#define CtrlEngineInterface_h__

#include <stdint.h>

/* CE是Ctrl Engine简写 */

/**
 * @brief 控制引擎变量表接口v1.0
 * 
 */
struct CE_VarTable_1_0 {
  const char* (*get_type)(void* vt, const char* name);
  void* (*get_value)(void* vt, const char* name);
};

typedef struct CE_VarTable_1_0 CE_VarTable;
#define CE_VAR_TABLE_INTERFACE "CE_VarTable;1.0"

/**
 * @brief 控制引擎日志接口v1.0
 * 
 */
struct CE_Log_1_0 {
  void (*log)(int32_t, const void * pData,const char*);
};

typedef struct CE_Log_1_0 CE_Log;
#define CE_LOG_INTERFACE "CE_Log;1.0"

#endif  // CtrlEngineInterface_h__
