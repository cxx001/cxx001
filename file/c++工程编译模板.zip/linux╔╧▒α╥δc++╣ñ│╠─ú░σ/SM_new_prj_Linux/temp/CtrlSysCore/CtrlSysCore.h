#pragma once
#include "BlockDAG.h"
#include "server_SimuNPS/CtrlSysEngineServer/ICtrlSysCore.h"

namespace Kcc {
namespace CtrlSys {

typedef map<string, PBlockBase> CtrlBlockMap;
typedef std::vector<string> StartNodes;
typedef std::vector<PBlockBase> OrderedBlocks;
typedef std::vector<Kcc::CtrlSys::Output> Outputs;

class BoardVisitor;
class CtrlSysLib;

class CtrlSysCore : public virtual Kcc::CtrlSys::ICtrlSysCore
{
    friend class CtrlSysLib;
    friend int ode_func(double, const double *, double *, CtrlSysCore *);
    friend int jac_func(double, const double *, double *, double *, CtrlSysCore *);

public:
    CtrlSysCore();
    virtual ~CtrlSysCore() { release(); }

    bool loadBoard(PBoard board);
    bool sortBlocks(PBoard board,bool noSort);
    virtual bool load(PBoard board) override;

    virtual bool collectCompileResults(BlockBase *b, bool composite) { return true; }

    virtual bool init() override;

    virtual void runOnce(bool is_print_result = false, void *g = nullptr) override;

    virtual void start() override;

    virtual void stop() override {}

    virtual void setParam(const string &name, const Any &v) override { params_[name] = v; }

    virtual const std::vector<Output> &getOutput() const override { return outputs_; }

    virtual const VariableTable &getVariableTable() const override { return var_tab_; }

    virtual void release() override;

private:

    bool loadBlocks(CtrlBlockMap &map);

    bool blockSort(BlockDAG &dag, StartNodes &start_nodes, CtrlBlockMap &map, vector<OrderedBlocks> &out,
                   size_t &result_index);

    bool traverseBoard(const string &parent_name, const string &parent_nm, const PBoard board);

    bool initGlobalVar();

    bool createVarTable(PBoard board, VariableTable *var_tab);
    //更新动态输入输出端口
    bool updateDynamicInOutput(PBoard board, VariableTable *var_tab);

protected:
    // 引擎对应的画板id
    string board_name_;

    // 已排序的block
    vector<OrderedBlocks> options;
    OrderedBlocks ordered_blocks_;
    vector<int> stateVarOffsets;
    vector<double> stateBuffer;
    int ode_callback_cnt;
    void *ode_;
    shared_ptr<BoardVisitor> visitor;

    // 步长
    double *step_size_;

    // 步数
    uint64_t *steps_;

    // 运行时间，总共需要运行多久
    double *total_running_time_;

    // 磁链方程求解时刻
    double *T_e2f_;

    // 当前运行时间
    double *running_time_;

    // 引擎参数
    map<string, Any> params_;

    // 输出数据
    Outputs outputs_;

    // 变量表
    VariableTable var_tab_;
};

class CtrlSysLib
{
    CtrlSysCore core;
    char *baseAddr[2];
    int varCnt[2];
    vector<void *> paramAddrs;
    bool status;

public:
    CtrlSysLib(PBoard board);
    bool setParam(const string &block, const string &param, const Any &v);
    bool runOnce(bool is_print_result = false);
    bool start();
    inline bool getStatus() const { return status; }
    char *const *getBaseAddr() const { return baseAddr; }
    const int *getVarCnt() const { return varCnt; }
    const vector<void *> &getParamAddrs() const { return paramAddrs; }
};

} // namespace CtrlSys
} // namespace Kcc