#pragma once
#include <string>
#include <vector>
namespace Kcc {
namespace CtrlSys {
struct Board;
}
}

using std::string;
using std::vector;

bool packBoard(Kcc::CtrlSys::Board *p, string &str);
bool unpackBoard(const string &str, Kcc::CtrlSys::Board *p);
void test(const string &dir, const vector<string> &boards);