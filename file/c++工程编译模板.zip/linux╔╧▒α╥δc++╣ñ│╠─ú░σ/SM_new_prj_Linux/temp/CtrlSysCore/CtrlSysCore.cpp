#include "CtrlSysCore.h"
#include "BlockDAG.h"
#include "server_SimuNPS/CtrlSysEngineServer/Util.h"
#include "server_SimuNPS/CtrlSysEngineServer/BlockDataType.h"
#include "CodeBlock.h"
#include <algorithm>
#include "Algorithm.h"

#ifndef _CTRL_SYS_CORE_
#include "BlockLibManager.h"
#else
#include "BoardSerializer.h"
#include "CtrlSysLib.h"
#include "CtrlSysLibTool.h"
#endif // !_CTRL_SYS_CORE_

using namespace std;

ostream &operator<<(ostream &o, const complex<double> &cd)
{
    return o << "complex(" << cd.real() << "," << cd.imag() << ")";
}

template<typename T>
ostream &operator<<(ostream &o, const vector<T> &v)
{
    o << "vector<" << typeid(T).name() << v.size() << ">[";
    for (size_t i = 0; i < v.size(); i++) {
        o << v[i] << (i + 1 == v.size() ? "," : "]");
    }
    return o;
}

template<typename T>
inline string to_string(const T &t)
{
    stringstream ss;
    ss << t;
    return ss.str();
}

template<typename K, typename V>
inline bool contains(const std::map<K, V> &m, const K &k)
{
    return m.find(k) != m.end();
}


namespace Kcc {
namespace CtrlSys {

USE_CTRLSYS_LOGOUT("CtrlSysCore")

inline string AnyToString(const Any &v)
{
    if (v.type() == typeid(double)) {
        return to_string(v.value<double>());
    } else if (v.type() == typeid(int)) {
        return to_string(v.value<int>());
    } else if (v.type() == typeid(bool)) {
        return to_string(v.value<bool>());
    } else if (v.type() == typeid(uint64_t)) {
        return to_string(v.value<uint64_t>());
    } else if (v.type() == typeid(string)) { //新增string类型
        return v.value<string>();
    } else if (v.type() == typeid(complex<double>)) { //新增complex<double>类型，分别打印实部和虚部
        return to_string(v.value<complex<double>>());
    } else if (v.type() == typeid(vector<double>)) { //新增vector<double>类型
        return to_string(v.value<vector<double>>());
    } else {
        //auto msg = string("不支持的类型:") + v.typeName();
        auto msg = string("unsupported Any type:") + v.typeName();
        LOGOUT(msg, LOG_ERROR);
        CHECK_FAIL("unsupported Any type");
        return "";
    }
}

inline static string Concat(const string &s1, const string &s2)
{
    if (s1.empty()) {
        return s2;
    } else {
        return s1 + "/" + s2;
    }
}

inline static bool IsCodeBlock(const PBlockDef pb)
{
    if (pb->getBlockType() == BlockDef::BlockCtrlCode && !BlockDef::isVirtualBlock(pb->protoName)) {
        return true;
    }
    return false;
}

class VariableTableVisitor : public Visitor
{
public:
    virtual void visit(const string &name, const Any *v) override
    {
        stringstream ss;
        //ss << "名称：" << name << "，值：" << AnyToString(*v) << "，地址：" << v;
        ss << "VariableName:" << name << ",Value:" << AnyToString(*v) << ",Addr:" << v;
        LOGOUT(ss.str(), Kcc::LOG_NORMAL);
    }
};

#define CheckReturnFalse(flag) if (!flag) return false;

class BoardVisitor
{
    struct RealPort {
        const ConPort *conPort;
        string pid;
        string bid;
        string vid;
        int depth;
        bool conDst;
        RealPort() : conPort(0), depth(0), conDst(false) { }
        RealPort(const ConPort *p, const string &parent_id, bool needDst) : conPort(p), pid(parent_id), conDst(needDst)
        {
        }
        RealPort(const RealPort &o)
            : conPort(o.conPort), pid(o.pid), bid(o.bid), vid(o.vid), depth(o.depth), conDst(o.conDst)
        {
        }
        void collectRealPorts(list<RealPort> &realPorts)
        {
            int i = conDst;
            const Board *pbd = nullptr;
            if (pbd = conPort->block->boardDefinition) {
                depth++;
                pid = Concat(pid, conPort->block->uuid);
                auto pio = pbd->blockMap.at(conPort->port->portName);
                assert(pio);
                auto &pcl = pbd->blockRelation.at(pio->uuid).connectors[i];
                for (auto it = pcl.cbegin(); it != pcl.cend(); it++) {
                    RealPort cp(*this);
                    cp.conPort = &(*it)->conPorts[i];
                    cp.collectRealPorts(realPorts);
                }
            }
            else {
                bid = Concat(pid, conPort->block->uuid);
                vid = Concat(bid, conPort->port->portName);
                realPorts.push_back(*this);
            }
        }
    };

    typedef vector<string> StrVec;
    bool validate(const CPConnector &pc, bool output, PBlockBase p, StrVec &vids, bool needLog) const
    {
        auto &dcp = pc->conPorts;
        int idx = output;
        assert(dcp[1 - idx].block == p->block);
        auto dp = dcp[idx].block;
        auto sp = Concat(p->gid, dcp[1 - idx].port->portName);
        vector<PBlockDef> vps;
        StrVec vns;
        //BusCreator的输入不能直接连接BusSelector
        if (!output && p->protoName == "BusCreator" && dcp[0].block->protoName == "BusSelector") {
            LOGOUT(string("BusCreator's input can't direct connect from BusSelector"), LOG_ERROR);
            return false;
        }
        if (contains(compositeConPorts, sp)) {
            auto &rps = compositeConPorts.at(sp);
            vps.reserve(rps.size());
            vns.reserve(rps.size());
            vids.reserve(rps.size());
            for (auto it = rps.cbegin(); it != rps.cend(); it++) {
                dp = it->conPort->block;
                vns.push_back(Concat(it->pid, dp->blockName));
                vids.push_back(it->vid);
            }
        } else {
            vns.push_back(Concat(p->pid, dp->blockName));
            auto dn = Concat(p->pid, dp->uuid);
            vids.push_back(Concat(dn, dcp[idx].port->portName));
            vps.push_back(dp);
        }
        auto sname = Concat(p->pid, p->block->blockName);
        for (size_t i = 0; i < vps.size(); i++) {
            if (vps[i]->protoName == p->protoName) {
                if (needLog) {
                    LOGOUT(sname + " cant connect " + vns[i] + " directly", LOG_ERROR);
                }
                return false;
            } else {
                if (output && p->protoName == "BusCreator" && vps[i]->protoName != "BusSelector") {
                    if (needLog) {
                        LOGOUT(string("Block connect to ") + sname + " is " + vns[i] + " which is not BusSelector",
                               LOG_ERROR);
                    }
                    return false;
                }
            }
            if (!var_tab_.exist(vids[i])) {
                if (needLog) {
                    LOGOUT(string("Block[") + vns[i] + "] has no port[" + vids[i] + "]", Kcc::LOG_ERROR);
                }
                return false;
            }
        }
        return true;
    }

    bool handleBusCreator(PBlockBase p, bool needLog)
    {
        auto &bcl = p->block->boardBelong->blockRelation[p->block->uuid].connectors;
        assert(bcl[1].size() == 1);
        StrVec dvids;
        CheckReturnFalse(validate(bcl[1].front(), true, p, dvids, needLog));
        for (auto it = bcl[0].cbegin(); it != bcl[0].cend(); it++) {
            StrVec svids;
            if (!validate(*it, false, p, svids, needLog)) {
                return false;
            }
            assert(svids.size() == 1); //只能存在一根输入连线
            auto var = var_tab_.getVariable(svids[0]);
            auto &pn = (*it)->conPorts[1].port->portName;
            for (size_t i = 0; i < dvids.size(); i++) {
                busSelectorBuffer[dvids[i]][pn] = var;
            }
        }
        return true;
    }

    bool handleBusSelector(PBlockBase p, bool needLog)
    {
        auto &bcl = p->block->boardBelong->blockRelation[p->block->uuid].connectors;
        assert(bcl[0].size() == 1);
        auto dname = Concat(p->pid, p->block->blockName);
        auto ip = Concat(p->gid, "yi");
        if (!contains(busSelectorBuffer, ip)) {
            if (needLog) {
                LOGOUT(string("no BusCreator connected to ") + dname + " ,or block order is not right", LOG_ERROR);
            }
            return false;
        }
        auto &portBuffer = busSelectorBuffer[ip];
        for (auto it = bcl[1].cbegin(); it != bcl[1].cend(); it++) {
            auto pn = (*it)->conPorts[0].port->portName;
            pn.replace(pn.find("yo"), 2, "yi");
            if (!contains(portBuffer, pn)) {
                if (needLog) {
                    LOGOUT(dname + " port " + pn + " is hangup", LOG_ERROR);
                }
                return false;
            }
            StrVec dvids;
            if (!validate(*it, true, p, dvids, needLog)) {
                return false;
            }
            for (size_t i = 0; i < dvids.size(); i++)
            {
                var_tab_.replace(dvids[i], portBuffer[pn]);
            }
        }
        return true;
    }

public:
    BoardVisitor(string boardName, VariableTable &var_tab)
        : board_name_(boardName), var_tab_(var_tab)
    {
    }

    bool handleBlock(const string &parent_id,const string &parent_nm, const PBlockDef pb)
    {
        auto currBoardName = parent_id == "" ? board_name_ : parent_id;
        auto id = Concat(parent_id, pb->uuid);
        auto nm = Concat(parent_nm, pb->blockName);
        if (contains(ctrlBlockMap,id)) {
            //LOGEX(string("程序内部错误，模块(" + id + ")已存在!"), Kcc::LOG_ERROR);
            LOGEX(string("Block(" + id + ")already exists"), Kcc::LOG_ERROR);
            return false;
        }
        if (IsCodeBlock(pb)) {
            auto cb = dynamic_cast<CtrlBlock *>(pb);
            for (auto it = cb->stateVariables.begin(); it != cb->stateVariables.end(); it++) {
                auto vid = Concat(id, it->first);
                stateVarAddrs[id].push_back(var_tab_.getVariable(vid)); //以防模块初始化时更改状态变量值
            }
            PBlockBase pcb(new CodeBlock(pb, parent_id, parent_nm));
            ctrlBlockMap[id] = pcb;
            allBoardBlockMap[currBoardName].ctrlBlockMap[id] = pcb;
        } else {
            if (pb->getBlockType() == BlockDef::BlockElectricalContainer) {
                auto pcb = dynamic_cast<ContainerBlock *>(pb);
                auto peb = dynamic_cast<ElecBlock *>(pcb->realBlock);
                auto p = (double *)var_tab_.getVariable("T_e2f")->dataAddr();
                *p = peb->T_e2f;
            }
            PBlockBase pcb(new BlockBase(pb, parent_id, parent_nm));
            if (pb->boardDefinition) {
                compositeBlockMap[id] = pcb;
                allBoardBlockMap[currBoardName].compositeBlockMap[id] = pcb;
            } else {
                ctrlBlockMap[id] = pcb;
                allBoardBlockMap[currBoardName].ctrlBlockMap[id] = pcb;
            }
        }
        return true;
    }

    bool handleConnector(const string &pid, const Connector &connector)
    {
        CtrlBlockMap *pcm[2];//连接线两端模块所属map
        string currBid[2];//当前画板模块的全路径
        string currVid[2];//当前画板模块端口的全路径
        for (int i = 0; i < 2; i++) {

            currBid[i] = Concat(pid, connector.conPorts[i].block->uuid);
            currVid[i] = Concat(currBid[i], connector.conPorts[i].port->portName);
            if (connector.conPorts[i].block->boardDefinition) {
                pcm[i] = &compositeBlockMap;//如果是构造型，模块在compositeBlockMap
            } else {
                pcm[i] = &ctrlBlockMap;//如果是代码型，模块在compositeBlockMap
                if (!var_tab_.exist(currVid[i])) {
                    LOGEX(string("Block Port[") + currVid[i] + "]does not exisit", Kcc::LOG_ERROR);
                    return false;
                }
            }
            if (!contains(*pcm[i], currBid[i])) {
                LOGEX(string("Block[") + currBid[i] + "]does not exisit", Kcc::LOG_ERROR);
                return false;
            }
        }
        
        //画板对应有向图新增边和顶点
        string boardName = pid == "" ? board_name_ : pid;
        auto currBoardX = dags_[boardName].addNode((*pcm[0])[currBid[0]]);
        auto currBoardY = dags_[boardName].addNode((*pcm[1])[currBid[1]]);
        dags_[boardName].addEdge(currBoardX, currBoardY);
        
        list<RealPort> realPorts[2];
        for (int i = 0; i < 2; i++) {
            auto& rps = realPorts[i];
            RealPort rp(&connector.conPorts[i],pid,i!=0);
            rp.collectRealPorts(rps);
            for (auto it = rps.cbegin(); it != rps.cend(); it++) {
                if (!contains(ctrlBlockMap, it->bid)) {
                    // LOGEX(string("模块[") + it->bid + "]不存在", Kcc::LOG_ERROR);
                    LOGEX(string("Block[") + it->bid + "]does not exisit", Kcc::LOG_ERROR);
                    return false;
                }
                if (!var_tab_.exist(it->vid)) {
                    // LOGEX(string("模块端口[") + it->vid + "]不存在", Kcc::LOG_ERROR);
                    LOGEX(string("Block Port[") + it->vid + "]does not exisit", Kcc::LOG_ERROR);
                    return false;
                }
            }
        }
        assert(realPorts[0].size() == 1); //只能存在一个输入端
        auto& srcPort = realPorts->front();
        bool isComposite = srcPort.depth != 0;
        if (isComposite) {
            compositeConPorts[srcPort.vid] = realPorts[1];
        }
        for (auto it = realPorts[1].cbegin(); it != realPorts[1].cend(); it++) {
            if (isComposite || it->depth != 0) {
                compositeConPorts[it->vid] = realPorts[0];
                if (!isComposite) {
                    compositeConPorts[srcPort.vid].push_back(*it);
                }
            }
            auto addr = var_tab_.getVariable(srcPort.vid);
            var_tab_.replace(it->vid, addr);
            auto x = dag_.addNode(ctrlBlockMap[srcPort.bid]);
            auto y = dag_.addNode(ctrlBlockMap[it->bid]);
            dag_.addEdge(x, y);
        }
        return true;
    }

    bool handleCtrlBus()
    {
        bool needLog = true;
        //首先收集create和select模块，然后先执行create，再执行select
        vector<string> BusCreators;
        vector<string> BusSelectors;
        for (auto it = ctrlBlockMap.begin(); it != ctrlBlockMap.end(); it++) {
            if (it->second->protoName == "BusCreator") {
                BusCreators.push_back(it->first);
            } else if (it->second->protoName == "BusSelector") {
                BusSelectors.push_back(it->first);
            }
        }

        bool ret[2] = {true,true};
        for (size_t i = 0; i < BusCreators.size(); i++) {
            ret[0] &= handleBusCreator(ctrlBlockMap[BusCreators[i]], true);
        }

        if (!ret[0])
            return false;

        for (size_t i = 0; i < BusSelectors.size(); i++) {
            ret[1] &= handleBusSelector(ctrlBlockMap[BusSelectors[i]], true);
        }

        return ret[0] && ret[1];
    }
    CtrlBlockMap compositeBlockMap;
    CtrlBlockMap ctrlBlockMap;
    string board_name_;
    // block有向图
    BlockDAG dag_;
    //每个画板对应的有向图（含子画板）
    map<string, BlockDAG> dags_;
    struct blockMaps {
        CtrlBlockMap compositeBlockMap;
        CtrlBlockMap ctrlBlockMap;
        list<string> specialSort;
    };
    //每个画板对应的模块指针（含子画板）
    map<string, blockMaps> allBoardBlockMap;

    map<string, list<RealPort>> compositeConPorts;
    map<string, map<string, VariableAddr>> busSelectorBuffer;
    map<string, vector<VariableAddr>> stateVarAddrs;
    // 遍历表
    VariableTable &var_tab_;
};

template<typename T>
T getInitialValueFromParam(const map<string, Any> &m, const string &name, T default_value)
{
    if (contains(m,name)) {
        return m.at(name).value<T>();
    } else {
        return default_value;
    }
}

#define INIT_GLOBAL_VAR(name, type, default_value)                                                 \
    var_tab_.create(#name, getInitialValueFromParam<type>(params_, #name, default_value));         \
    name##_ = (type *)var_tab_.getVariable(#name)->dataAddr();


//void print_block_var(string name, const double *v, size_t len, string *blocks)
//{
//    string block;
//    for (size_t i = 0; i < len; i++) {
//        block += blocks[i] + ",";
//        name += to_string(v[i]) + ",";
//    }
//    LOGOUT(block, LOG_ERROR);
//    LOGOUT(name, LOG_ERROR);
//}

int ode_func(double t, const double y[], double f[], CtrlSysCore *core)
{
    double *x_state = const_cast<double *>(y);
    auto &bs = core->ordered_blocks_;
    int N = 2;
    for (int i = 1; i >=0; i--) {
        if (core->ode_callback_cnt == 0 && i == 1) {
            continue;
        }
        for (size_t j = 0; j < bs.size(); j++) {
            auto offset = core->stateVarOffsets[j];
            double *ps = 0, *pf = 0;
            if (offset >= 0) {
                ps = x_state + offset;
                pf = &f[offset];
            }
            auto r = bs[j]->integral(i, t, ps, pf);
        }
    }
    core->ode_callback_cnt++;
    return 0;
}

int jac_func(double t, const double y[], double *dfdy, double dfdt[], CtrlSysCore *core)
{
    return 0;
}



CtrlSysCore::CtrlSysCore()
    : steps_(nullptr),
      running_time_(nullptr),
      total_running_time_(nullptr),
      step_size_(nullptr),
      visitor(nullptr),
      ode_callback_cnt(0),
      ode_(nullptr)
{
    // initGlobalVar();
}

bool CtrlSysCore::initGlobalVar() {
  INIT_GLOBAL_VAR(step_size, double, 0.01);
  INIT_GLOBAL_VAR(total_running_time, double, 1.0);
  INIT_GLOBAL_VAR(running_time, double, 0.0);
  INIT_GLOBAL_VAR(steps, uint64_t, 0);
  //INIT_GLOBAL_VAR(T_e2f, double, 0.0);
  var_tab_.create(kParamAlgorithm, getInitialValueFromParam(params_, kParamAlgorithm, 1));
  var_tab_.create(kParamAbsEps, getInitialValueFromParam(params_, kParamAbsEps, 1e-3));
  var_tab_.create(kParamRelEps, getInitialValueFromParam(params_, kParamRelEps, 1e-3));
  return true;
}

bool CtrlSysCore::init()
{
    if (!initGlobalVar()) {
        return false;
    }
    stateVarOffsets.resize(ordered_blocks_.size(), -1);
    int curOffset = 0;
    // 各个模块初始化，初始化主要工作就是从变量表获取数据指针，后续计算直接用指针计算
    for (size_t i = 0; i < ordered_blocks_.size(); i++) {
        auto &block = ordered_blocks_[i];
        //电气容器型的模块跳过模块加载的步骤
        if (!block->init(var_tab_)) {
            //LOGEX(block->gid + "初始化失败!", Kcc::LOG_ERROR);
            LOGEX(block->gid + " init fail!", Kcc::LOG_ERROR);
            return false;
        }
        auto it = visitor->stateVarAddrs.find(block->gid);
        if (it != visitor->stateVarAddrs.end()) {
            stateVarOffsets[i] = curOffset;
            curOffset += it->second.size();
            for (size_t j = 0; j < it->second.size(); j++) {
                stateBuffer.push_back(it->second[j]->value<double>());
            }
        }
        collectCompileResults(block.get(), false);
    }
    //因为在控制里面组合模块拆分成了单个模块处理，所以在控制的map中没有组合模块，对于组合模块的游离以及悬空端口需要根据composite_blocks_单独判断
    auto &cbm = visitor->compositeBlockMap;
    for (auto it = cbm.begin(); it != cbm.end(); it++) {
        auto cb = it->second.get();
        if (!cb->CompileResults_.empty()) {
            collectCompileResults(cb, true);
        }
    }
    auto algtype = getInitialValueFromParam(params_, kParamAlgorithm, 1);
    auto epsabs = getInitialValueFromParam(params_, kParamAbsEps, 1e-3);
    auto epsrel = getInitialValueFromParam(params_, kParamRelEps, 1e-3);
    if (stateBuffer.empty()) {
        stateBuffer.push_back(0);
    }
    auto r = Odeiv_init(&ode_, (pfunc)ode_func, (pjac)jac_func, stateBuffer.size(), this, *step_size_, algtype, epsabs,
                        epsrel);
    if (r != 0) {
        // LOGOUT(string("积分算法初始化失败"), LOG_ERROR);
        LOGOUT(string("Ode function init fail"), LOG_ERROR);
        return false;
    }
    for (size_t j = 0; j < ordered_blocks_.size(); j++) {
        auto offset = stateVarOffsets[j];
        double *ps = 0;
        if (offset >= 0) {
            ps = stateBuffer.data() + offset;
        }
        auto r = ordered_blocks_[j]->integral(1, 0, ps, 0);
    }
    for (size_t j = 0; j < ordered_blocks_.size(); j++) {
        ordered_blocks_[j]->runOnce(&var_tab_);
    }
    visitor.reset();
    return true;
}

void CtrlSysCore::runOnce(bool is_print_result, void *g)
{
    // steps从0开始
    (*steps_)++;
    auto steps = (*steps_) * (*step_size_);
    if (steps >= (*T_e2f_)) //新增磁链方程求解时刻的控制
    {
        if (ode_) {
            auto p = stateBuffer.data();
            int ret = Odeiv_run(ode_, steps, *step_size_, p);
            ode_callback_cnt = 0;
            for (size_t j = 0; j < ordered_blocks_.size(); j++) {
                auto offset = stateVarOffsets[j];
                double *ps = 0, *pf = 0;
                if (offset >= 0) {
                    ps = p + offset;
                }
                auto r = ordered_blocks_[j]->integral(1, (*steps_) * (*step_size_), ps, pf);
            }
            
        }
        for (size_t i = 0; i < ordered_blocks_.size(); i++) {
            auto &b = ordered_blocks_[i];
            //if (BlockDef::isVirtualBlock(b->protoName)) {
            //    bool needUpdate = b->pid.empty() && b->protoName == "Out";
            //    if (!needUpdate) {
            //        continue;
            //    }
            //}
            ASSERT(b != nullptr);
            b->runOnce(&var_tab_);
        }
    }
    // is_print_result默认false，单步运行时为true
    if (is_print_result) {
        LOGEX(string("all variable detail list as follow:"), Kcc::LOG_NORMAL);
        VariableTableVisitor visitor;
        var_tab_.accept(visitor);
    }
}

/// @brief 创建变量
/// @param block_id 顶层模块的ID
/// @param vars 待生成的变量map
/// @param var_tab 传进来的变量表的指针
/// @param type 变量类型 -2-输入变量，-1-状态变量，0-参数，1-输出变量
/// @return ture-执行成功
static bool CreateVars(const string &block_id, const ParamDefMap &vars, VariableTable *var_tab, int type)
{
    string gid;
    string bid = "";
    string prebid;
    int nNum = 0;
    string dynamicNm;
    for (auto it = vars.begin(); it != vars.end(); it++, nNum++) {
        gid = Concat(block_id, it->first);
        // 0-参数和1-输出变量使用变量表提供的连续内存， 其他则由any申请内存
        if (type < 0) {
            CheckReturnFalse(var_tab->create(gid, it->second.paramType, it->second.value));
        } else {
            CheckReturnFalse(var_tab->createContinuousMemVar(gid, it->second.paramType, it->second.value, type > 0));
        }

        //每个模块输入变量和输出变量，额外生成一个动态指针数值进行保存
        if (type == -2 || type == 1) {
            dynamicNm = type == -2 ? "p_dynamic_Input_" : "p_dynamic_Output_";
            //当模块名称和原来不一样的是说明是另外的模块了
            if (bid != gid.substr(0, gid.find_last_of('/'))) {
                prebid = bid;
                bid = gid.substr(0, gid.find_last_of('/'));
                if (prebid != "") {
                    CheckReturnFalse(var_tab->create(Concat(prebid, dynamicNm), "doublePtrArray", doublePtrArray(nNum)));
                    nNum = 0;
                }
            }
        }
    }
    if ((type == -2 || type == 1) && bid != "")
        CheckReturnFalse( var_tab->create(Concat(bid, dynamicNm), "doublePtrArray", doublePtrArray(nNum)));

    return true;
}

bool CtrlSysCore::createVarTable(PBoard board, VariableTable *var_tab)
{
    size_t stateVarCnt = 0;
    // 注意：board->blockMap的key为uuid
    for (auto it = board->blockMap.cbegin(); it != board->blockMap.cend();it++) {
        auto &b = it->second;
        auto tp = b->getBlockType();
        if (tp == BlockDef::BlockCtrlCode || tp == BlockDef::BlockCtrlCombined) {
            auto cbd = (CtrlBlock *)b;
            CheckReturnFalse(CreateVars(b->uuid, cbd->inputVariables, var_tab, -2));
            if (b->protoName == "Out") {
                ParamDef yo;
                yo.paramName = "yo";
                yo.paramType = "double";
                yo.value = (double)0;
                ParamDefMap temp;
                temp["yo"] = yo;
                CheckReturnFalse(CreateVars(b->uuid, temp, var_tab, 1));
                continue;
            } else {
                CheckReturnFalse(CreateVars(b->uuid, cbd->outputVariables, var_tab, 1));
            }
            CheckReturnFalse(CreateVars(b->uuid, cbd->parameters, var_tab, 0));
            // 20220324 新增把状态变量新增到变量表
            CheckReturnFalse(CreateVars(b->uuid, cbd->stateVariables, var_tab, -1));
            stateVarCnt += cbd->stateVariables.size();
        } else if (tp == BlockDef::BlockElectricalContainer) //电气容器型模块
        {
            auto cbd = (ContainerBlock *)b;
            //电气容器型模块只有输入输出变量
            CheckReturnFalse(CreateVars(b->uuid, cbd->inputVariables, var_tab, -1));
            CheckReturnFalse(CreateVars(b->uuid, cbd->outputVariables, var_tab, 1));
        }
    }
    stateBuffer.reserve(stateVarCnt);
    return true;
}

/// @brief 更新动态端口数组的地址
/// @param block_id 顶层模块的ID
/// @param vars 输入输出的变量map
/// @param var_tab 变量表
/// @param type 变量类型 -2-输入变量，-1-状态变量，0-参数，1-输出变量
/// @return true 更新成功，false 更新失败
static bool updateDynamicVars(const string &block_id, const ParamDefMap &vars,VariableTable *var_tab, int type)
{
    string dynamicNm; //动态变量表名称
    string bid; //模块名称
    if (type == -2 || type == 1)
        dynamicNm = type == -2 ? "p_dynamic_Input_" : "p_dynamic_Output_";
    else
        return false;

    int i = 0;
    doublePtrArray *dPtrArr = nullptr;
    for (auto it = vars.begin(); it != vars.end(); it++) {
        auto gid = Concat(block_id, it->first);
        //当模块名称和原来不一样的是说明是另外的模块了
        if (bid != gid.substr(0, gid.find_last_of('/'))) {
            bid = gid.substr(0, gid.find_last_of('/'));
            dPtrArr = (doublePtrArray *)var_tab->getValue(Concat(bid, dynamicNm).c_str());
            i = 0;
        }
        dPtrArr->ptr_[i] = (double *)var_tab->getValue(gid.c_str());
        i++;
    }
    return true;
}


bool CtrlSysCore::updateDynamicInOutput(PBoard board, VariableTable *var_tab)
{
    for (auto it = board->blockMap.cbegin(); it != board->blockMap.cend(); it++) {
        auto &b = it->second;
        auto tp = b->getBlockType();
        if (tp == BlockDef::BlockCtrlCode || tp == BlockDef::BlockCtrlCombined) {
            auto cbd = (CtrlBlock *)b;
            updateDynamicVars(b->uuid, cbd->inputVariables, var_tab, -2);
            updateDynamicVars(b->uuid, cbd->outputVariables, var_tab, 1);
        }
    }
    return true;
}

bool CtrlSysCore::loadBlocks(CtrlBlockMap &cbm)
{
#ifndef _CTRL_SYS_CORE_
    BlockLibManager::getInst().load();
#endif // !_CTRL_SYS_CORE_
    //加载各个模块
    for (auto it = cbm.begin(); it != cbm.end(); it++) {
        auto b = it->second;
        if (BlockDef::isVirtualBlock(b->protoName))
            continue;

        if (!b->load()) {
            //LOGEX(b->pid + "的模块(" + b->protoName + ")加载失败!", Kcc::LOG_ERROR);
            LOGEX(b->pid + " subblock(" + b->protoName + ") load fail!", Kcc::LOG_ERROR);
            return false;
        }
    }
    return true;
}

/// @brief 有向图排序
/// @param dag 待排序的有向图
/// @param start_nodes 其实顶点
/// @param map 模块map
/// @param out 排序后的模块（目前是所有排序结果都会返回）
/// @param result_index
/// @return 排序结果中环最少的
bool CtrlSysCore::blockSort(BlockDAG &dag, StartNodes &start_nodes, CtrlBlockMap &map, vector<OrderedBlocks> &out,
                            size_t &result_index)
{
  // 记录环最少的结果
  result_index = 0;

  // 多组排序结果最少的环个数
  size_t min_cycles = std::numeric_limits<size_t>::max();

  // 存储所有拓扑排序的结果
  std::vector<std::vector<BlockDAG::PNode>> results;

  // 针对每个节点进行拓扑排序，选出最优的结果(环最少的)
  LOGEX("======================================================", Kcc::LOG_NORMAL);
  for (size_t i = 0, j = 0; i < start_nodes.size(); i++) {
      ASSERT(contains(map, start_nodes[i]));

    // 拓扑排序要先把环边删掉，不能修改原有的有向图，每次排序复制一份副本
    auto dag_temp = dag;

    // 设置起始顶点
    auto start_node = dag_temp.addNode(map[start_nodes[i]]);

    // 找环边
    auto cycle_edges = dag_temp.findCycleEdge(start_node);

    // 删除环边
    for (auto e = cycle_edges.begin(); e != cycle_edges.end(); e++) {
      dag_temp.removeEdge(*e);
    }

    // 拓扑排序
    auto result = dag_temp.toplogicalSort(start_nodes, map, start_nodes[i]);

    if(result.size() + dag._singleNode.size() != map.size()) continue;

    if (cycle_edges.size() < min_cycles) {
      min_cycles   = cycle_edges.size();
      result_index = results.size();
    }

    results.push_back(result);

    //////////////////////////////// 调试信息
    string edges_str;
    for (auto e = cycle_edges.begin(); e != cycle_edges.end(); e++) {
        edges_str += e->x->block->blockName + "->" + e->y->block->blockName + ",";
    }

    string sort_result_str;
    for (auto n = result.begin(); n != result.end(); n++) {
        sort_result_str += (*n)->block->blockName + "->";
    }

    //auto res = string("排序结果") + to_string(++j) + "：起始顶点(" + start_node->block_name + "),环:" + edges_str;
    auto res = string("BlockOrder:") + to_string(++j) + ":StartNode(" + start_node->block->blockName + "),Cycle:" + edges_str;
    LOGEX(res, Kcc::LOG_NORMAL);
    LOGEX(string("BlockOrder:") + sort_result_str, Kcc::LOG_NORMAL);
    LOGEX("=====================================================", Kcc::LOG_NORMAL);
  }

  if (results.size() <= result_index) {
      //LOGEX(string("排序失败"), Kcc::LOG_ERROR);
      LOGEX(string("Block order sort fail"), Kcc::LOG_ERROR);
      return false;
  }

  out.resize(results.size());
  for (size_t r = 0; r < results.size(); r++) {
      // LOGEX(string("选择排序结果:") + to_string(result_index + 1), Kcc::LOG_NORMAL);
      // LOGEX(string("choose block order result:") + to_string(result_index + 1), Kcc::LOG_NORMAL);
      out[r].reserve(results[r].size() + dag._singleNode.size());
      for (size_t i = 0; i < results[r].size(); i++) {
          out[r].push_back(results[r][i]->block);
      }
      //新增把游离模块也要加到排序的map，解决如果游离的模块存在类似VoidBuffer数据结构模块时，会导致没有执行模块的init而直接调用destory，有存在内存泄露或者操作野指针的风险
      for (size_t i = 0; i < dag._singleNode.size(); i++) {
          out[r].push_back(dag._singleNode[i]->block);
      }
  }
  return true;
}

bool CtrlSysCore::traverseBoard(const string &parent_id, const string &parent_nm, const PBoard board)
{
    auto currBoardName = parent_id == "" ? board_name_ : parent_id;
    visitor->allBoardBlockMap[currBoardName].specialSort = board->specialSort;
    for (auto it = board->blockMap.cbegin(); it != board->blockMap.cend();it++) {
        auto pb = it->second;
        if (!visitor->handleBlock(parent_id, parent_nm, pb)) {
            return false;
        }
        if (pb->boardDefinition) {
            auto id = Concat(parent_id, pb->uuid);
            auto nm = Concat(parent_nm, pb->blockName);
            if (!traverseBoard(id, nm, pb->boardDefinition)) {
                return false;
            }
        }
    }
    for (auto it = board->blockConnectors.begin(); it != board->blockConnectors.end(); it++) {
        bool ret = visitor->handleConnector(parent_id, *it);
        CheckReturnFalse(ret);
    };

    return true;
}

bool CtrlSysCore::loadBoard(PBoard board)
{
    board_name_ = board->boardName;

    if (board->blockMap.empty()) {
        //LOGEX(string("空画板!"), Kcc::LOG_ERROR);
        LOGEX(string("empty board!"), Kcc::LOG_ERROR);
        return false;
    }

    // 因为遍历画板时会关联模块变量，所以要在遍历前创建好变量表
    // 1、注意要用顶层模块的blockMap去创建变量，因为画板上只能设置顶层的各个模块参数。
    // 2、board下面可能还有嵌套画板，其内部也有各个模块参数，这个参数是在模块原型中设置，我们目前没有用到。
    if (!createVarTable(board, &var_tab_)) {
        //LOGEX("创建变量表失败", Kcc::LOG_ERROR);
        LOGEX("fail to create variable table", Kcc::LOG_ERROR);
        return false;
    }
    //磁链方程求解时刻是从画板的电气容器获取的，在这里先创建变量，后面遍历的时候进行赋值
    INIT_GLOBAL_VAR(T_e2f, double, 0.0);

    //LOGEX(string("创建变量耗时:%1 ms").arg(t.elapsed()), Kcc::LOG_NORMAL);

    visitor = shared_ptr<BoardVisitor>(new BoardVisitor(board_name_, var_tab_));
    // 因为画板可能嵌套多层画板，所以使用递归遍历所有画板，创建模块和关联变量
    if (!traverseBoard("", "", board)) {
        return false;
    }
    //LOGEX(string("遍历画板耗时:%1 ms").arg(t.elapsed()), Kcc::LOG_NORMAL);
    //遍历完画板后 即可替换总线Bus对应的地址
    bool flag = visitor->handleCtrlBus();
    if (!flag)
        return false;

    updateDynamicInOutput(board, &var_tab_);
    return true;
}

/// @brief 所有画板的排序结果合并
/// @param allOptions 所有排序结果的vector
/// @param allBest 所有排序中的选择的排序结果
/// @param board_name_ 当前排序的画板名称
/// @param allBoardResult 最终排序结果
/// @return 无
inline static void getAllBoardResult(map<string, vector<OrderedBlocks>> &allOptions, map<string, size_t> &allBest,
                                     string board_name_, OrderedBlocks &allBoardResult, int &depth)
{
    auto &currResult = (allOptions[board_name_])[allBest[board_name_]];
    int currDepth = depth;
    for (size_t i = 0; i < currResult.size(); i++) {
        if (currResult[i]->block->getBlockType() == BlockDef::BlockCtrlCombined) {
            string next_board_name_ =currDepth == 0 ? currResult[i]->block->uuid : Concat(board_name_, currResult[i]->block->uuid);
            getAllBoardResult(allOptions, allBest, next_board_name_, allBoardResult, ++depth);
        } else {
            allBoardResult.push_back(currResult[i]);
        }
    }
    string sortResult;
    for (size_t i = 0; i < allBoardResult.size(); i++) {
        //顶级画板则显示模块全路径，否则只显示模块名称
        string blockNm = currDepth == 0 ? allBoardResult[i]->gnm : allBoardResult[i]->blockName;
        sortResult += string(blockNm + "->");
    }
    LOG(board_name_ + string("'s sort: ") + sortResult, Kcc::LOG_NORMAL);
}

/// @brief 获取画板map中每个画板对应的起始顶点
/// @param allBoardBlockMap 画板map
/// @param dags  每个map对应的有向图
/// @param start_nodes 所有代码型模块起始顶点
/// @param composite_start_nodes 所有构造型起始顶点
/// @param all_board_start_nodes 画板map中每个画板对应的所有起始顶点
inline static void getAllBoardStartNode(map<string, Kcc::CtrlSys::BoardVisitor::blockMaps> &allBoardBlockMap,
     map<string, BlockDAG> &dags, StartNodes &start_nodes,
     StartNodes &composite_start_nodes, map<string, StartNodes> &all_board_start_nodes)
{
    for (auto it = allBoardBlockMap.begin(); it != allBoardBlockMap.end(); it++) {
        string currNm = it->first;
        auto boardBlockMap = it->second;
        //该顶点在画板中则认为是起始顶点
        for (size_t i = 0; i < start_nodes.size(); i++) {
            if (contains(boardBlockMap.ctrlBlockMap, start_nodes[i])
                || contains(boardBlockMap.compositeBlockMap, start_nodes[i])) {
                all_board_start_nodes[currNm].push_back(start_nodes[i]);
            }
        }

        for (size_t i = 0; i < composite_start_nodes.size(); i++) {
            if (contains(boardBlockMap.ctrlBlockMap, composite_start_nodes[i])
                || contains(boardBlockMap.compositeBlockMap, composite_start_nodes[i])) {
                all_board_start_nodes[currNm].push_back(composite_start_nodes[i]);
            }
        }

        //如果起始顶点为0，则进行特殊处理，直接用map的第一个点作为起始顶点
        if (all_board_start_nodes[currNm].size() == 0 && dags[currNm].getEdgeSize() > 0) {
            string oneNode;
            if (boardBlockMap.ctrlBlockMap.size() > 0) {
                for (auto it = boardBlockMap.ctrlBlockMap.begin(); it != boardBlockMap.ctrlBlockMap.end(); it++) {
                    if (!it->second->isOutlier()) {
                        oneNode = it->second->gid;
                        break;
                    }
                }
            } else {
                for (auto it = boardBlockMap.compositeBlockMap.begin(); it != boardBlockMap.compositeBlockMap.end(); it++) {
                    if (!it->second->isOutlier()) {
                        oneNode = it->second->gid;
                        break;
                    }
                }
            }
            all_board_start_nodes[currNm].push_back(oneNode);
        }
    }
}

/// @brief 模块排序
/// @param board 待排序的画板
/// @param noConnctor 没有连接线的标志
/// @return ture-排序成功 false-排序失败
bool CtrlSysCore::sortBlocks(PBoard board,bool noConnctor)
{
    auto &ctrl_block_map = visitor->ctrlBlockMap;
    auto &compositeBlockMap = visitor->compositeBlockMap;
    auto &dag = visitor->dag_;
    auto &dags = visitor->dags_;
    auto &allBoardBlockMap = visitor->allBoardBlockMap;

    if (!loadBlocks(ctrl_block_map)) {
        return false;
    }

    //没有任何连接线的情况
    if (noConnctor) {
        for (auto it = ctrl_block_map.begin(); it != ctrl_block_map.end(); it++) {
            ordered_blocks_.push_back(it->second);
        }
    } else {
        StartNodes start_nodes;
        bool foundElec = false;
        for (auto it = ctrl_block_map.begin(); it != ctrl_block_map.end(); it++) {
            auto block = it->second;
            if (block->isOutlier()) {
                BlockDAG::PNode n(new BlockDAG::Node);
                n->block = block;
                n->block_name = block->pid;
                n->id = dag.id();

                dag._singleNode.push_back(n);
                dag.addNode(block, n);

                string relatBoardName = block->pid == "" ? board_name_ : block->pid;
                BlockDAG::PNode n2(new BlockDAG::Node);
                n2->block = block;
                n2->block_name = block->pid;
                n2->id = dags[relatBoardName].id();
                dags[relatBoardName]._singleNode.push_back(n2);
                dags[relatBoardName].addNode(block, n2);
            } else if (block->isStartNode(foundElec)) {
                if (!foundElec&& block->block->getBlockType() == BlockDef::BlockElectricalContainer) {
                    start_nodes.clear();
                    foundElec = true;
                }
                start_nodes.push_back(block->gid);
            }
        }

        //找出构造型模块中的起始顶点
        StartNodes composite_start_nodes;
        bool foundElec2 = false;
        for (auto it = compositeBlockMap.begin(); it != compositeBlockMap.end(); it++) {
            auto block = it->second;
            if (block->isOutlier()) {
                BlockDAG::PNode n(new BlockDAG::Node);
                n->block = block;
                n->block_name = block->pid;
                n->id = dags[block->boardName].id();

                dags[block->boardName]._singleNode.push_back(n);
                dags[block->boardName].addNode(block, n);
            } else if (block->isStartNode(foundElec2)) {
                if (!foundElec2 && block->block->getBlockType() == BlockDef::BlockElectricalContainer) {
                    composite_start_nodes.clear();
                    foundElec2 = true;
                }
                composite_start_nodes.push_back(block->gid);
            }
        }

        //找出每个画板中的起始顶点
        map<string, StartNodes> all_board_start_nodes;
        getAllBoardStartNode(allBoardBlockMap, dags, start_nodes, composite_start_nodes, all_board_start_nodes);
        
        //每个画板都进行当前画板的排序
        map<string, vector<OrderedBlocks>> allOptions;
        map<string, size_t> allBest;
        for (auto it = dags.begin(); it != dags.end(); it++) {
            auto currNm = it->first;
            auto &currdag = it->second;
            auto currCtrlBlockMap = allBoardBlockMap[currNm].ctrlBlockMap;
            currCtrlBlockMap.insert(allBoardBlockMap[currNm].compositeBlockMap.begin(),allBoardBlockMap[currNm].compositeBlockMap.end());
            //如果画板有传入的专用排序则直接使用专用排序
            auto sSize = allBoardBlockMap[currNm].specialSort.size();
            if ( sSize> 0) {
                //如果传入的专用排序的数量和画板模块的数量不一致则进行报错处理
                auto bSize = allBoardBlockMap[currNm].compositeBlockMap.size() + allBoardBlockMap[currNm].ctrlBlockMap.size();
                if (sSize != bSize) {
                    LOGOUT(currNm+string(" SpecialSort's size[")+to_string(sSize)+string("]not equal the Number of module's:"+to_string(bSize)),LOG_ERROR);
                    return false;
                }
                auto &specialSort = allBoardBlockMap[currNm].specialSort;
                vector<PBlockBase> currSpecialSort;
                for (auto it2 = specialSort.cbegin(); it2 != specialSort.cend();it2++) {
                    string absBlockName;
                    if (currNm == board_name_)
                        absBlockName = *it2;
                    else
                        absBlockName = currNm + "/" + *it2;
                    if (!contains(currCtrlBlockMap, absBlockName)) {
                        LOGOUT(string("SpecialSort's block [")+absBlockName+("] not exists"),LOG_ERROR);
                        return false;
                    }
                    currSpecialSort.push_back(currCtrlBlockMap[absBlockName]);
                }
                allOptions[currNm].push_back(currSpecialSort);
                allBest[currNm] = 0;
            }
            //专用排序为空，则采用原有方法排序
            else 
            {
                //如果当前画板只有孤立模块，没有连接线，那么目前的有向图是空的，直接把当前画板的所有孤立模块放入排序数组
                if (currdag.getEdgeSize() == 0) {
                    vector<PBlockBase> singleSort;
                    for (auto it = currCtrlBlockMap.begin(); it != currCtrlBlockMap.end(); it++) {
                        singleSort.push_back(it->second);
                    }
                    allOptions[currNm].push_back(singleSort);
                    allBest[currNm] = 0;
                } else {
                    if (!blockSort(currdag, all_board_start_nodes[currNm], currCtrlBlockMap, allOptions[currNm],allBest[currNm])) {
                        LOGEX(string("currBoard:[") + currNm + string("] sort fail!"), Kcc::LOG_ERROR);
                        return false;
                    }
                }
            }
        }

        //排序后的每个画板的排序组合到一起
        OrderedBlocks allBoardResult;
        int depth = 0;
        //从顶层画板开始递归遍历组合
        getAllBoardResult(allOptions, allBest, board_name_, allBoardResult, depth);
        ordered_blocks_ = allBoardResult;

        options.clear();
        for (auto it = allOptions.begin(); it != allOptions.end(); it++) {
            (it->second).clear();
        }
        return true;
    }
    return true;
}

bool CtrlSysCore::load(PBoard board)
{
    bool ret = loadBoard(board);
    if (!ret) {
        return false;
    }
    return sortBlocks(board ,!visitor->dag_.getEdgeSize());
}

void CtrlSysCore::start() {
  ASSERT(total_running_time_ != nullptr);
  ASSERT(step_size_ != nullptr);
  ASSERT(steps_ != nullptr);
  ASSERT(running_time_ != nullptr);

  uint64_t total_steps = static_cast<uint64_t>((*total_running_time_) / (*step_size_));
  while ((*steps_) < total_steps) {
    runOnce();
  }

  //LOGEX(string("计算结果如下："), Kcc::LOG_NORMAL);
  LOGEX(string("compute result list as follow:"), Kcc::LOG_NORMAL);
  VariableTableVisitor visitor;
  var_tab_.accept(visitor);
}

void CtrlSysCore::release()
{
    visitor.reset();
    ordered_blocks_.clear();
    outputs_.clear();
    var_tab_.clear();
    if (ode_) {
        Odeiv_free(ode_);
    }
#ifndef _CTRL_SYS_CORE_
    BlockLibManager::getInst().unLoad();
#endif // !_CTRL_SYS_CORE_
}

#ifdef _CTRL_SYS_CORE_
CtrlSysLib::CtrlSysLib(PBoard board)
{
    core.loadBoard(board);
    setBLInterfaces(BlockReg::getBLInterfaces());
    core.sortBlocks(board, !core.visitor->dag_.getEdgeSize());
    status = core.init();
    auto mgrs = core.var_tab_.getMemMgrs();
    auto offsets = core.var_tab_.getMemOffsets();
    for (int i = 0; i < 2; i++) {
        baseAddr[i] = (char *)mgrs[i].getBaseAddr();
        varCnt[i] = offsets[i].size();
    }
    paramAddrs.reserve(varCnt[0]);
    for (int i = 0; i < varCnt[0]; i++) {
        paramAddrs.push_back(baseAddr[0] + offsets[0][i]);
    }
}

bool updateVariable(VariableTable &vt, const string &varName, const Any &v)
{
    string type = vt.getType(varName.c_str());
    if (type.empty()) {
        //LOGOUT(string("参数") + varName + "不存在", LOG_ERROR);
        LOGOUT(string("param ") + varName + " does not exisit", LOG_ERROR);
        return false;
    }
    auto tp = v.typeName();
    bool match = (type == tp);
    // if (!match) {
    //     auto cltp = TYPEID_NAME_GCC_2_CL(tp);
    //     match = (type == cltp);
    // };
    if (!match) {
        //LOGOUT(string("不能改变参数") + varName + "的类型" + type + "为" + tp, LOG_ERROR);
        LOGOUT(string("unable to change ") + varName + " variable type " + type + " to " + tp, LOG_ERROR);
        return false;
    } else {
        return vt.create(varName, type, v);
    }
}

bool CtrlSysLib::setParam(const string &block, const string &param, const Any &v)
{
    auto name = block.empty() ? param : block + "/" + param;
    return updateVariable(core.var_tab_, name, v);
}

bool CtrlSysLib::runOnce(bool is_print_result /*= false*/)
{
    if (status) {
        core.runOnce(is_print_result, nullptr);
        return true;
    } else {
        //LOGOUT("控制系统加载错误，无法运行", LOG_ERROR);
        LOGOUT("control system load failure，unable to run", LOG_ERROR);
        return false;
    }
}

bool CtrlSysLib::start()
{
    if (status) {
        core.start();
        return true;
    } else {
        //LOGOUT("控制系统加载错误，无法运行", LOG_ERROR);
        LOGOUT("control system load failure，unable to run", LOG_ERROR);
        return false;
    }
}

#endif // _CTRL_SYS_CORE_
} // namespace CtrlSys
} // namespace Kcc

#ifdef _CTRL_SYS_CORE_
using namespace Kcc::CtrlSys;


PBoard getBuiltinBoard() {
    static Board builtinBoard;
    return &builtinBoard;
}

CtrlSysInit::CtrlSysInit(FnPtrGetBuiltinData fn)
{
    string data = fn();
    auto pb = getBuiltinBoard();
    unpackBoard(data, pb);
}
void *getCtrlSys()
{
    auto builtinBoard = getBuiltinBoard();
    if (builtinBoard->boardName.empty()) {
        //LOGOUT("导出控制系统时必须调用INIT_CTRL_SYS宏");
        LOGOUT("must define macro _EXPORT_CTRL_SYS_ when export control system");
        return nullptr;
    }
    return new CtrlSysLib(builtinBoard);
}
void releaseCtrlSys(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_WARNING);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    delete ctrlSys;
}
bool setParam(void *p, const string &block, const string &param, const Any &v)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return false;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    return ctrlSys->setParam(block, param, v);
}
void runOnce(void *p, bool is_print_result /*= false*/)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    ctrlSys->runOnce(is_print_result);
}
void start(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    ctrlSys->start();
}
void *getParamsBaseAddr(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return 0;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    return ctrlSys->getBaseAddr()[0];
}
void *getOutputBaseAddr(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return 0;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    return ctrlSys->getBaseAddr()[1];
}
int getParamsCnt(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return 0;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    return ctrlSys->getVarCnt()[0];
}
int getOutputCnt(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return 0;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    return ctrlSys->getVarCnt()[1];
}
void **getParamAddrs(void *p)
{
    if (!p) {
        //LOGOUT("控制系统指针为空", Kcc::LOG_ERROR);
        LOGOUT("control system pointer is null", Kcc::LOG_WARNING);
        return 0;
    }
    auto ctrlSys = (CtrlSysLib *)p;
    auto addrs = ctrlSys->getParamAddrs().data();
    return (void **)addrs;
}
#endif // _CTRL_SYS_CORE_

