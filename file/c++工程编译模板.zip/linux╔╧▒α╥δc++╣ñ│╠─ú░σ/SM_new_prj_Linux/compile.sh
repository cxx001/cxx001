
COMMAND="$1"
cd ./temp
echo $COMMAND
make $COMMAND
cd ..
