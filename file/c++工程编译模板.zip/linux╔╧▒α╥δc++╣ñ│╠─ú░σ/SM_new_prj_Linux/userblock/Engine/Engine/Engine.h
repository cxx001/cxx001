#include "FctBase.h"

//ģ�͹��ܺ�����������ƽ̨�еĹ���ģ�飬�̳�CFctBase��

class Engine: public CFctBase  
{
public:
	int Initialize(double t,double step,double* x,double* u,double* y,double* f);
	int Restart(double t,double step,double* x,double* u,double* y,double* f);
	int Continue(double t,double step,double* x,double* u,double* y,double* f);
	int Output(double t,double step,double* x,double* u,double* y,double* f);
	int WriteData(double t,double step,double* x,double* u,double* y,double* f);
	int Stop(double t,double step,double* x,double* u,double* y,double* f);
	int End(double t,double step,double* x,double* u,double* y,double* f);

	Engine();
	virtual ~Engine();

public:

	double Thrust,ThrustTest;
	double flow,flowRating;
};