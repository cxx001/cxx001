//////////////////////////////////////////////////////////////////
//
//	RtxDllDemo.h - header file
//
// This file was generated using the RTX Application Wizard 
// for Visual Studio.  
//////////////////////////////////////////////////////////////////

#include <windows.h>
//#include <wchar.h>
#include <rtapi.h>
//#include <stdio.h>
//#include <string.h>
//#include <ctype.h>
//#include <conio.h>
//#include <stdlib.h>
//#include <math.h>
//#include <errno.h>

#define BUILDFLY_API __declspec(dllexport)

// Add DEFINES Here

//  Add Function prototypes Here
// function prototype for the RTDLL exported function
/*
RtxDllDemo_API
int 
RTAPI
Toggle(
        int argc, 
        wchar_t* argv[]
        );
		*/

