/*
* Copyright (c) 2008-2016 IntervalZero, Inc.  All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that neither the name of the 
* IntervalZero Corporation nor the names of its contributors may be
* used to endorse or promote products derived from this software 
* without specific prior written permission.
*   
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
* 
*
* Module Name:
*    sampleRtdll.c
*
* Abstract:
*
*    Rtdll example -- contains the function "Toggle" which toggles
*    the state of the speaker
*
* Author:
*    IntervalZero
*
* Environment:
*
*    RTX application (Win32 or RTSS).
*
*
* Revision History:
*
*    - converted dll example to use with rtdlls (Terri Hawker)
*    --
*/

//*** DEBUGGER TIP ***
// In order to Debug UsingRtDLL you will need to run the following command on the RtDLL
//		rtssrun.exe /d /f "sampleRtDll.rtdll"
//

#include "windows.h"
#include "rtapi.h"
#include "RtxDllDemo.h"

//DllMain must Explicitly return True
BOOL RTAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	return TRUE;
}