//ģ��ģ��Ļ��࣬����ģ��ģ��̳и��࣬FctBase.h��FctBase.cpp�е����ݲ�Ҫ�Ķ�
#include "FctBase.h"

#ifdef UNDER_RTSS
MESSGE_HANDLE SendUserMessage=NULL;
SHOWMESSAGE_PROC ShowMessage;
#endif


CFctBase::CFctBase()
{
	m_pModel=NULL;
}

CFctBase::~CFctBase()
{

}

void CFctBase::AttachModel(MODEL *pModel)
{

	if (sizeof(*pModel)!=sizeof(MODEL))
	{
		return;
	}
	m_pModel=pModel;
	pModel->pPtr[0]=this;

	Data=pModel->Data;
	Num=pModel->Num;
	Flag=pModel->Flag;
	pPtr=pModel->pPtr;

	int i;
	for (i=0;i<FILEDIM;i++)
	{
		File[i]=pModel->File[i];
	}

	strcpy(workPath,pModel->WorkPath);
	strcpy(dllPath,pModel->DllFile);

	//....
}

CFctBase* CFctBase::GetPtr(void* param)
{

	MODEL* pModel = (MODEL*)param;

	return (CFctBase*)pModel->pPtr[0];

}

int CFctBase::Initialize(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::Restart(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::Continue(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::Output(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::WriteData(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::Stop(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::End(double t, double step,double* x,double* u,double* y,double* f)
{
	return 1;
}

int CFctBase::UserMSG(int msg, int param, double t, double step, double * x, double * u, double * y, double * f)
{
	return 1;
}


void CFctBase::DetachModel()
{
	m_pModel->pPtr[0]=NULL;
}
