#include "RtxDllDemo.h"
#include "TankClass.h"
#include <stdio.h>

#ifndef UNDER_RTSS
#include "userdef.h"
#include "math.h"
#else
#include "RTUserdef.h"
#include "math.h"
extern MESSGE_HANDLE SendUserMessage;
extern SHOWMESSAGE_PROC ShowMessage;
#endif

// ȫ��ָ�룬�û���������ʹ��
static USERINFO *info;

#ifndef UNDER_RTSS
int Tank_Param(int state,void *pages,VOID *data)
{   
	RemoveParam();
	MODEL* pm=(MODEL*)data;

	AddParam("�ܼ�ע��",PT_DB,1,&pm->Data[0]);

	return 0;
}
#endif


char *xTextTank[]={"������(kg)",""};
char *uTextTank[]={"����(kg/s)",""};
char *yTextTank[]={"�ƽ���ʣ������(kg)",""};

extern "C"
	int BUILDFLY_API Tank(int msg, void* param, double t, double s, double* x, double* u, double* y, double* f)
{
	int ret=0;
	switch(msg) {
	case SM_INFO:
		{
			info=(USERINFO*)param;
			info->mask=UFI_ALL;

			info->xDim=1;  //   state
			info->uDim=1;  //   input 
			info->yDim=1;  //   output 

			info->title="����";

			info->text="������ؼ���";

			info->xText=xTextTank;
			info->uText=uTextTank;
			info->yText=yTextTank;

			info->image=-1;

			info->step=1;

#ifndef UNDER_RTSS
			info->fParam=(PARAMPROC)Tank_Param;	
#endif

			info->dlg=UPS_DEFAULT;	     
		}
		break;
	case SM_INITIALIZE:
		{		
			TankClass* pClass=new TankClass;
			pClass->AttachModel((MODEL*)param);
			ret=pClass->Initialize(t,s,x,u,y,f);
		}
		break;
	case SM_RESTART:
		{
			TankClass* pClass=(TankClass*)CFctBase::GetPtr((void*)param);
			ret=pClass->Restart(t,s,x,u,y,f);
		}		
		break;
	case SM_CONTINUE:
		{
			TankClass* pClass=(TankClass*)CFctBase::GetPtr((void*)param);
			ret=pClass->Continue(t,s,x,u,y,f);
		}
		break;
	case SM_OUTPUT:
		{
			TankClass* pClass=(TankClass*)CFctBase::GetPtr((void*)param);
			ret=pClass->Output(t,s,x,u,y,f);
		}
		break;
	case SM_WRITEDATA:		
		{
			TankClass* pClass=(TankClass*)CFctBase::GetPtr((void*)param);
			ret=pClass->WriteData(t,s,x,u,y,f);
		}		
		break;
	case SM_STOP:
		{
			TankClass* pClass=(TankClass*)CFctBase::GetPtr((void*)param);
			ret=pClass->Stop(t,s,x,u,y,f);
			pClass->DetachModel();
		}
		break;
	case SM_END:
		{
			TankClass* pClass=(TankClass*)CFctBase::GetPtr((void*)param);
			ret=pClass->End(t,s,x,u,y,f);
		}
		break;
	}
	return ret;
}