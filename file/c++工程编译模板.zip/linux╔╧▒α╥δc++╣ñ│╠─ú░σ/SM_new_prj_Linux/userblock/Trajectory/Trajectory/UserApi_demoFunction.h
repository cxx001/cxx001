#pragma once

 extern "C" int demoFunction(int msg, int param, double t, double s, double* x, double* u, double* y, double* f); 