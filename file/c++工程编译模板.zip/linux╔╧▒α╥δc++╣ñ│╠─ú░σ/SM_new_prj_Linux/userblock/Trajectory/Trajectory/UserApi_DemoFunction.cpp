#include "RtxDllDemo.h"
#include "DemoFunction.h"
#include <stdio.h>

#ifndef UNDER_RTSS
#include "userdef.h"
#include "math.h"
#else
#include "RTUserdef.h"
#include "math.h"
extern MESSGE_HANDLE SendUserMessage;
extern SHOWMESSAGE_PROC ShowMessage;
#endif

// ȫ��ָ�룬�û���������ʹ��
static USERINFO *info;

#ifndef UNDER_RTSS
int DemoFunction_Param(int state,void *pages,VOID *data)
{   
	RemoveParam();
	MODEL* pm=(MODEL*)data;

	return 0;
}
#endif

//����״̬��������������������������������//ע�⣬��ĳ��һ��������û�У�ҲҪд   char *xTextFunction1[]={""};
char *xTexttest[]={"�ٶ�(m/s)","λ��(m)"};
char *uTexttest[]={"����(kg)","����(N)"};
char *yTexttest[]={"���ٶ�(m/s^2)","�ٶ�(m/s)","λ��(m)"};


extern "C"
	int BUILDFLY_API demoFunction(int msg, void* param, double t, double s, double* x, double* u, double* y, double* f)
{
	int ret=0;
	switch(msg) {
	case SM_INFO:
		{
			info=(USERINFO*)param;
			info->mask=UFI_ALL;

			info->xDim=2; 
			info->uDim=2;
			info->yDim=3;

			info->title="����";

			info->text="����";

			info->xText=xTexttest;
			info->uText=uTexttest;
			info->yText=yTexttest;

			info->image=-1;

			info->step=1;

#ifndef UNDER_RTSS
			info->fParam=(PARAMPROC)DemoFunction_Param;	
#endif

			info->dlg=UPS_DEFAULT;	     
		}
		break;
	case SM_INITIALIZE:
		{		
			CDemoFunction* pClass=new CDemoFunction;
			pClass->AttachModel((MODEL*)param);
			ret=pClass->Initialize(t,s,x,u,y,f);
		}
		break;
	case SM_RESTART:
		{
			CDemoFunction* pClass=(CDemoFunction*)CFctBase::GetPtr((void*)param);
			ret=pClass->Restart(t,s,x,u,y,f);
		}		
		break;
	case SM_CONTINUE:
		{
			CDemoFunction* pClass=(CDemoFunction*)CFctBase::GetPtr((void*)param);
			ret=pClass->Continue(t,s,x,u,y,f);
		}
		break;
	case SM_OUTPUT:
		{
			CDemoFunction* pClass=(CDemoFunction*)CFctBase::GetPtr((void*)param);
			ret=pClass->Output(t,s,x,u,y,f);
		}
		break;
	case SM_WRITEDATA:		
		{
			CDemoFunction* pClass=(CDemoFunction*)CFctBase::GetPtr((void*)param);
			ret=pClass->WriteData(t,s,x,u,y,f);
		}		
		break;
	case SM_STOP:
		{
			CDemoFunction* pClass=(CDemoFunction*)CFctBase::GetPtr((void*)param);
			ret=pClass->Stop(t,s,x,u,y,f);
			pClass->DetachModel();
		}
		break;
	case SM_END:
		{
			CDemoFunction* pClass=(CDemoFunction*)CFctBase::GetPtr((void*)param);
			ret=pClass->End(t,s,x,u,y,f);
		}
		break;
	}
	return ret;
}