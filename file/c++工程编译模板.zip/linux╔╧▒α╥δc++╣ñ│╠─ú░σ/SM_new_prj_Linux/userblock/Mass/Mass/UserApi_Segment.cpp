#include "RtxDllDemo.h"
#include "Segment.h"
#include <stdio.h>

#ifndef UNDER_RTSS
#include "userdef.h"
#include "math.h"
#else
#include "RTUserdef.h"
#include "math.h"
extern MESSGE_HANDLE SendUserMessage;
extern SHOWMESSAGE_PROC ShowMessage;
#endif

// ȫ��ָ�룬�û���������ʹ��
static USERINFO *info;

#ifndef UNDER_RTSS
int Segment_Param(int state,void *pages,VOID *data)
{   
	RemoveParam();
	MODEL* pm=(MODEL*)data;

	AddParam("�ṹ����[kg]",PT_DB,1,&pm->Data[0]);

	return 0;
}
#endif


//����״̬��������������������������������//ע�⣬��ĳ��һ��������û�У�ҲҪд   char *xTextFunction1[]={""};
char *xTextSegment[]={""};    
char *uTextSegment[]={"Һ������(kg)"};
char *yTextSegment[]={"��������(kg)"};


extern "C"
	int BUILDFLY_API SegmentFunction(int msg, void* param, double t, double s, double* x, double* u, double* y, double* f)
{
	int ret=0;
	switch(msg) {
	case SM_INFO:
		{
			info=(USERINFO*)param;
			info->mask=UFI_ALL;

			info->xDim=0;  //   state
			info->uDim=1;  //   input 
			info->yDim=1;  //   output 

			info->title="������������";

			info->text="������������";

			info->xText=xTextSegment;
			info->uText=uTextSegment;
			info->yText=yTextSegment;

			info->image=-1;

			info->step=1;

#ifndef UNDER_RTSS
			info->fParam=(PARAMPROC)Segment_Param;	
#endif

			info->dlg=UPS_DEFAULT;	     
		}
		break;
	case SM_INITIALIZE:
		{		
			Segment* pClass=new Segment;
			pClass->AttachModel((MODEL*)param);
			ret=pClass->Initialize(t,s,x,u,y,f);
		}
		break;
	case SM_RESTART:
		{
			Segment* pClass=(Segment*)CFctBase::GetPtr((void*)param);
			ret=pClass->Restart(t,s,x,u,y,f);
		}		
		break;
	case SM_CONTINUE:
		{
			Segment* pClass=(Segment*)CFctBase::GetPtr((void*)param);
			ret=pClass->Continue(t,s,x,u,y,f);
		}
		break;
	case SM_OUTPUT:
		{
			Segment* pClass=(Segment*)CFctBase::GetPtr((void*)param);
			ret=pClass->Output(t,s,x,u,y,f);
		}
		break;
	case SM_WRITEDATA:		
		{
			Segment* pClass=(Segment*)CFctBase::GetPtr((void*)param);
			ret=pClass->WriteData(t,s,x,u,y,f);
		}		
		break;
	case SM_STOP:
		{
			Segment* pClass=(Segment*)CFctBase::GetPtr((void*)param);
			ret=pClass->Stop(t,s,x,u,y,f);
			pClass->DetachModel();
		}
		break;
	case SM_END:
		{
			Segment* pClass=(Segment*)CFctBase::GetPtr((void*)param);
			ret=pClass->End(t,s,x,u,y,f);
		}
		break;
	}
	return ret;
}